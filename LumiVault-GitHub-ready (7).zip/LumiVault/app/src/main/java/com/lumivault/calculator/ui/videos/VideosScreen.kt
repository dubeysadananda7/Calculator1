package com.lumivault.calculator.ui.videos

import android.app.Application
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import com.lumivault.calculator.ui.components.AccentFab
import com.lumivault.calculator.ui.components.CountChip
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import com.lumivault.calculator.ui.components.ThumbButton
import com.lumivault.calculator.ui.components.ToastBar
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.data.repo.MediaCleaner
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.rememberMediaPermissionGate
import com.lumivault.calculator.ui.components.rememberOriginalsCleanup
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.navigation.Routes
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VideosViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).vault

    val videos: StateFlow<List<VaultItemEntity>> = repo.videos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun import(uris: List<Uri>, onError: (String) -> Unit, onCleanup: (List<Uri>) -> Unit) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val originals = mutableListOf<Uri>()
            var imported = 0
            for (uri in uris) {
                val mediaUri = MediaCleaner.toMediaUri(context, uri, VaultItemType.VIDEO)
                val r = repo.import(uri, VaultItemType.VIDEO)
                if (r.isSuccess) {
                    imported++
                    if (mediaUri != null) originals.add(mediaUri)
                } else onError(r.exceptionOrNull()?.message ?: "Import failed")
            }
            if (imported > originals.size) {
                onError("Hidden, but some originals could not be removed from the gallery. Allow video access and try again.")
            }
            if (originals.isNotEmpty()) onCleanup(originals)
        }
    }

    fun restoreToGallery(item: VaultItemEntity, onResult: (String) -> Unit) = viewModelScope.launch {
        repo.exportToGallery(item)
            .onSuccess { onResult("Restored to gallery (Movies/Restored)") }
            .onFailure { onResult(it.message ?: "Restore failed") }
    }

    suspend fun thumbnail(item: VaultItemEntity): Bitmap? = withContext(Dispatchers.IO) {
        val dir = File(getApplication<Application>().cacheDir, "thumbs").apply { mkdirs() }
        val cached = File(dir, "${item.id}.jpg")
        if (cached.exists() && cached.length() > 0) {
            BitmapFactory.decodeFile(cached.absolutePath)?.let { return@withContext it }
        }
        val decrypted = repo.decryptedFile(item)
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(decrypted.absolutePath)
            val frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            frame?.let { f ->
                val scale = 480f / f.width.coerceAtLeast(1)
                val small = if (scale < 1f) Bitmap.createScaledBitmap(f, 480, (f.height * scale).toInt().coerceAtLeast(1), true) else f
                runCatching { cached.outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, 80, it) } }
                small
            }
        } catch (t: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
            decrypted.delete() // videos are big: do not keep the decrypted copy
        }
    }

    suspend fun playableFile(item: VaultItemEntity): File = repo.decryptedFile(item)

    fun delete(item: VaultItemEntity) = viewModelScope.launch { repo.softDelete(item.id) }
}

@Composable
fun VideosScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { VideosViewModel(app) }
    val videos by vm.videos.collectAsStateWithLifecycle()
    var error by remember { mutableStateOf<String?>(null) }
    val cleanup = rememberOriginalsCleanup()

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris -> if (uris.isNotEmpty()) vm.import(uris, { error = it }, cleanup) }
    val launchPicker = rememberMediaPermissionGate {
        picker.launch(
            androidx.activity.result.PickVisualMediaRequest(
                androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.VideoOnly
            )
        )
    }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(
                title = "Videos",
                onBack = { nav.popBackStack() },
                actions = { if (videos.isNotEmpty()) CountChip("${videos.size} ${if (videos.size == 1) "video" else "videos"}") },
            )
            if (videos.isEmpty()) {
                EmptyState(Icons.Default.Movie, "No private videos", "Tap + to import videos")
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 120.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(videos, key = { it.id }) { item ->
                        VideoCell(item = item, vm = vm, onMessage = { error = it }) {
                            nav.navigate(Routes.videoPlayer(item.id))
                        }
                    }
                }
            }
        }
        AccentFab(
            icon = Icons.Default.Add,
            contentDescription = "Import",
            onClick = launchPicker,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(24.dp),
        )
        error?.let {
            ToastBar(
                it,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .navigationBarsPadding()
                    .padding(end = 100.dp, bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun VideoCell(item: VaultItemEntity, vm: VideosViewModel, onMessage: (String) -> Unit, onClick: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    val thumb by produceState<Bitmap?>(initialValue = null, item.id) { value = vm.thumbnail(item) }

    var menu by remember { mutableStateOf(false) }
    val cellShape = RoundedCornerShape(22.dp)
    Box(
        modifier = Modifier
            .aspectRatio(16f / 9f)
            .clip(cellShape)
            .background(Pal.Card)
            .border(1.dp, Pal.Border, cellShape)
            .clickable(onClick = onClick),
    ) {
        thumb?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = item.displayName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        // dark gradient at the bottom so the title is readable
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(64.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
        )
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp)
                .clip(CircleShape)
                .background(Color(0x99000000)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Text(
            item.displayName,
            color = Color.White,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
        )
        Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
            ThumbButton(Icons.Default.MoreVert, "Options", onClick = { menu = true })
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Restore to gallery") },
                    onClick = { menu = false; confirmRestore = true },
                )
                DropdownMenuItem(
                    text = { Text("Delete") },
                    onClick = { menu = false; confirmDelete = true },
                )
            }
        }
    }

    if (confirmRestore) {
        ConfirmDialog(
            title = "Restore to gallery?",
            text = "\"${item.displayName}\" will be moved back to your phone gallery and removed from the vault.",
            confirmLabel = "Restore",
            onConfirm = { vm.restoreToGallery(item, onMessage); confirmRestore = false },
            onDismiss = { confirmRestore = false },
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "\"${item.displayName}\" will be moved to the recycle bin.",
            confirmLabel = "Move",
            onConfirm = { vm.delete(item); confirmDelete = false },
            onDismiss = { confirmDelete = false },
        )
    }
}
