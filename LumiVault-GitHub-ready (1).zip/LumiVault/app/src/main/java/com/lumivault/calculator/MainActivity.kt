package com.lumivault.calculator

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.lumivault.calculator.data.repo.SettingsRepository
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.navigation.AppNavGraph
import com.lumivault.calculator.ui.theme.LumiVaultTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as LumiVaultApp
        setContent {
            LumiVaultTheme {
                AppNavGraph(app = app)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Auto-lock the vault when the app leaves the foreground.
        val app = application as LumiVaultApp
        lifecycleScope.launch {
            val s = app.settings.settings.first()
            if (SessionManager.unlocked.value && s.autoLockMinutes <= 15) {
                SessionManager.lock()
            }
        }
    }
}
