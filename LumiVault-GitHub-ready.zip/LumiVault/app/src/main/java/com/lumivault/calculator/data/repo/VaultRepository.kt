package com.lumivault.calculator.data.repo

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.lumivault.calculator.data.db.VaultItemDao
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.security.CryptoManager
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VaultRepository(
    private val context: Context,
    private val dao: VaultItemDao,
) {
    fun active(): Flow<List<VaultItemEntity>> = dao.observeActive()
    fun photos(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.PHOTO.name)
    fun videos(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.VIDEO.name)
    fun audios(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.AUDIO.name)
    fun documents(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.DOCUMENT.name)
    fun others(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.OTHER.name)
    fun recycleBin(): Flow<List<VaultItemEntity>> = dao.observeDeleted()

    suspend fun byId(id: String): VaultItemEntity? = dao.byId(id)

    suspend fun import(uri: Uri, type: VaultItemType): Result<VaultItemEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolver = context.contentResolver
                val mime = resolver.getType(uri)
                val name = displayName(resolver, uri) ?: "item_${System.currentTimeMillis()}"
                val dir = File(context.filesDir, "vault/${type.name.lowercase()}").apply { mkdirs() }
                val enc = File(dir, UUID.randomUUID().toString() + ".enc")
                resolver.openInputStream(uri)?.use { input ->
                    CryptoManager.encryptFile(input, enc)
                } ?: error("Could not open selected file")
                val item = VaultItemEntity(
                    type = type.name,
                    displayName = name,
                    mimeType = mime,
                    encryptedPath = enc.absolutePath,
                    sizeBytes = enc.length(),
                )
                dao.upsert(item)
                item
            }
        }

    private fun displayName(resolver: android.content.ContentResolver, uri: Uri): String? =
        resolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        }

    /** Decrypts into the cache. The caller must delete the returned file when finished. */
    suspend fun decryptedFile(item: VaultItemEntity): File = withContext(Dispatchers.IO) {
        val out = File(context.cacheDir, "preview/${item.id}")
        CryptoManager.decryptFile(File(item.encryptedPath), out)
        out
    }

    suspend fun playableFileForPlayback(item: VaultItemEntity): File = decryptedFile(item)

    suspend fun previewFile(itemId: String): File? {
        val item = dao.byId(itemId) ?: return null
        return decryptedFile(item)
    }

    suspend fun softDelete(id: String) = dao.softDelete(id)

    suspend fun restore(id: String) = dao.restore(id)

    suspend fun deletePermanently(item: VaultItemEntity) = withContext(Dispatchers.IO) {
        dao.deletePermanently(item.id)
        File(item.encryptedPath).delete()
    }

    suspend fun emptyRecycleBin(items: List<VaultItemEntity>) {
        items.forEach { deletePermanently(it) }
    }

    fun usedBytes(): Long {
        val vault = File(context.filesDir, "vault")
        return vault.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    fun clearPreviews() {
        File(context.cacheDir, "preview").deleteRecursively()
    }
}
