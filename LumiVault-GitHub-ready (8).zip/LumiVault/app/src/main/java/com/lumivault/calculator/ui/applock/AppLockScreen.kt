package com.lumivault.calculator.ui.applock

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.VaultTopBar
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppLockViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = (app as LumiVaultApp).settings

    val lockedApps = settings.settings.map { it.lockedApps }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    fun installedLaunchers(context: Context): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return context.packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .sortedBy { it.loadLabel(context.packageManager).toString().lowercase() }
    }

    fun setLocked(pkg: String, locked: Boolean) =
        viewModelScope.launch { settings.setAppLocked(pkg, locked) }
}

@Composable
fun AppLockScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { AppLockViewModel(app) }
    val locked by vm.lockedApps.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val apps = remember { vm.installedLaunchers(context) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        VaultTopBar(title = "App lock", onBack = { nav.popBackStack() })
        Text(
            "App lock uses Android's Accessibility API. It cannot protect against uninstall or safe mode. " +
                "Enable the Calculator accessibility service for best results.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        TextButton(onClick = {
            com.lumivault.calculator.security.SessionManager.beginExternal()
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, modifier = Modifier.padding(horizontal = 12.dp)) {
            Text("Open accessibility settings")
        }
        LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
            items(apps, key = { it.activityInfo.packageName }) { info ->
                val pkg = info.activityInfo.packageName
                val label = info.loadLabel(context.packageManager).toString()
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Row(
                        Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                pkg,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = locked.contains(pkg),
                            onCheckedChange = { vm.setLocked(pkg, it) },
                        )
                    }
                }
            }
        }
    }
}
