package com.lumivault.calculator.data.repo

import android.Manifest
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.lumivault.calculator.data.db.VaultItemType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Removes the original file from the phone's gallery after it has been encrypted into the vault.
 * On Android 11+ the system itself asks the user to confirm the delete (one dialog for all items).
 */
object MediaCleaner {

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun collectionFor(type: VaultItemType): Uri? = when (type) {
        VaultItemType.PHOTO -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        VaultItemType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        VaultItemType.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else -> null
    }

    private fun nameAndSize(resolver: ContentResolver, uri: Uri): Pair<String?, Long?>? =
        resolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null, null, null,
        )?.use { c ->
            if (!c.moveToFirst()) return@use null
            val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val s = c.getColumnIndex(OpenableColumns.SIZE)
            val name = if (n >= 0 && !c.isNull(n)) c.getString(n) else null
            val size = if (s >= 0 && !c.isNull(s)) c.getLong(s) else null
            name to size
        }

    private fun idFrom(uri: Uri): Long? {
        val seg = uri.lastPathSegment ?: return null
        return seg.toLongOrNull() ?: seg.substringAfter(':', "").toLongOrNull()
    }

    /** Converts a picked uri (photo picker / documents) into the real MediaStore uri of the original. */
    suspend fun toMediaUri(context: Context, picked: Uri, type: VaultItemType): Uri? =
        withContext(Dispatchers.IO) {
            runCatching {
                val collection = collectionFor(type) ?: return@runCatching null
                val resolver = context.contentResolver
                val (name, size) = nameAndSize(resolver, picked) ?: return@runCatching null
                if (name == null || size == null) return@runCatching null

                // 1) Try the id contained in the picked uri, and verify that it is the same file.
                idFrom(picked)?.let { id ->
                    val candidate = ContentUris.withAppendedId(collection, id)
                    val meta = runCatching { nameAndSize(resolver, candidate) }.getOrNull()
                    if (meta != null && meta.first == name && meta.second == size) return@runCatching candidate
                }

                // 2) Fall back to searching by name + size (only if exactly one file matches).
                resolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.SIZE}=?",
                    arrayOf(name, size.toString()),
                    null,
                )?.use { c ->
                    if (c.count == 1 && c.moveToFirst()) ContentUris.withAppendedId(collection, c.getLong(0)) else null
                }
            }.getOrNull()
        }

    /** Android 11+: system dialog asking the user to confirm deleting these originals. */
    fun deleteIntentSender(context: Context, uris: List<Uri>): IntentSender? =
        if (Build.VERSION.SDK_INT >= 30 && uris.isNotEmpty())
            runCatching { MediaStore.createDeleteRequest(context.contentResolver, uris).intentSender }.getOrNull()
        else null

    /** Android 10 fallback (no confirmation dialog available). */
    fun deleteLegacy(context: Context, uris: List<Uri>) {
        uris.forEach { runCatching { context.contentResolver.delete(it, null, null) } }
    }

    /** Best effort for documents / other files picked through the file picker. */
    fun deleteDocument(context: Context, uri: Uri): Boolean =
        runCatching { DocumentsContract.deleteDocument(context.contentResolver, uri) }.getOrDefault(false)
}
