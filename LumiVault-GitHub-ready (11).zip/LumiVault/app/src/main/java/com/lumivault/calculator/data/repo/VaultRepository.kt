package com.lumivault.calculator.data.repo

import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.provider.OpenableColumns
import com.lumivault.calculator.data.db.VaultItemDao
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.security.CryptoManager
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VaultRepository(
    private val context: Context,
    private val dao: VaultItemDao,
) {
    fun active(): Flow<List<VaultItemEntity>> = dao.observeActive()
    fun photos(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.PHOTO.name)
    fun videos(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.VIDEO.name)
    fun audios(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.AUDIO.name)
    fun documents(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.DOCUMENT.name)
    fun others(): Flow<List<VaultItemEntity>> = dao.observeByType(VaultItemType.OTHER.name)
    fun recycleBin(): Flow<List<VaultItemEntity>> = dao.observeDeleted()

    suspend fun byId(id: String): VaultItemEntity? = dao.byId(id)

    suspend fun import(uri: Uri, type: VaultItemType): Result<VaultItemEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolver = context.contentResolver
                val mime = resolver.getType(uri)
                val name = displayName(resolver, uri) ?: "item_${System.currentTimeMillis()}"
                val dir = File(context.filesDir, "vault/${type.name.lowercase()}").apply { mkdirs() }
                val enc = File(dir, UUID.randomUUID().toString() + ".enc")
                resolver.openInputStream(uri)?.use { input ->
                    CryptoManager.encryptFile(input, enc)
                } ?: error("Could not open selected file")
                val item = VaultItemEntity(
                    type = type.name,
                    displayName = name,
                    mimeType = mime,
                    encryptedPath = enc.absolutePath,
                    sizeBytes = enc.length(),
                )
                dao.upsert(item)
                item
            }
        }

    private fun displayName(resolver: android.content.ContentResolver, uri: Uri): String? =
        resolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        }

    /** Decrypts into the cache. The caller must delete the returned file when finished. */
    suspend fun decryptedFile(item: VaultItemEntity): File = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "preview").apply { mkdirs() }
        val out = File(dir, item.id)
        // Already decrypted earlier in this unlocked session: reuse it (decrypting big files is slow).
        if (out.exists() && out.length() > 0) return@withContext out
        // Decrypt into a temp file first, so another reader never sees a half-written file.
        val tmp = File(dir, "${item.id}.${System.nanoTime()}.tmp")
        try {
            CryptoManager.decryptFile(File(item.encryptedPath), tmp)
            if (!tmp.renameTo(out)) tmp.copyTo(out, overwrite = true)
        } finally {
            tmp.delete()
        }
        out
    }

    /** Wipes every decrypted preview/thumbnail. Called whenever the vault locks and on app start. */
    fun clearPreviewCache() {
        File(context.cacheDir, "preview").deleteRecursively()
        File(context.cacheDir, "thumbs").deleteRecursively()
    }

    suspend fun playableFileForPlayback(item: VaultItemEntity): File = decryptedFile(item)

    suspend fun previewFile(itemId: String): File? {
        val item = dao.byId(itemId) ?: return null
        return decryptedFile(item)
    }

    /**
     * Moves an item back to the public gallery/downloads (decrypts it) and removes it from the vault.
     * Photos -> Pictures/Restored, videos -> Movies/Restored, audio -> Music/Restored, others -> Download/Restored.
     */
    suspend fun exportToGallery(item: VaultItemEntity): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val name = item.displayName
            val mime = item.mimeType
                ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
                ?: "application/octet-stream"
            val volume = MediaStore.VOLUME_EXTERNAL_PRIMARY
            val (collection, folder) = when (item.type) {
                VaultItemType.PHOTO.name -> MediaStore.Images.Media.getContentUri(volume) to Environment.DIRECTORY_PICTURES
                VaultItemType.VIDEO.name -> MediaStore.Video.Media.getContentUri(volume) to Environment.DIRECTORY_MOVIES
                VaultItemType.AUDIO.name -> MediaStore.Audio.Media.getContentUri(volume) to Environment.DIRECTORY_MUSIC
                else -> MediaStore.Downloads.getContentUri(volume) to Environment.DIRECTORY_DOWNLOADS
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/Restored")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val target = resolver.insert(collection, values) ?: error("Could not create the file in gallery")
            val plain = decryptedFile(item)
            try {
                resolver.openOutputStream(target)?.use { out -> plain.inputStream().use { it.copyTo(out) } }
                    ?: error("Could not write the file in gallery")
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(target, values, null, null)
            } catch (t: Throwable) {
                runCatching { resolver.delete(target, null, null) }
                throw t
            } finally {
                plain.delete()
            }
            // Only after the gallery copy is complete, remove it from the vault.
            dao.deletePermanently(item.id)
            File(item.encryptedPath).delete()
            target
        }
    }

    suspend fun softDelete(id: String) = dao.softDelete(id)

    suspend fun restore(id: String) = dao.restore(id)

    suspend fun deletePermanently(item: VaultItemEntity) = withContext(Dispatchers.IO) {
        dao.deletePermanently(item.id)
        File(item.encryptedPath).delete()
    }

    suspend fun emptyRecycleBin(items: List<VaultItemEntity>) {
        items.forEach { deletePermanently(it) }
    }

    fun usedBytes(): Long {
        val vault = File(context.filesDir, "vault")
        return vault.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    fun clearPreviews() {
        File(context.cacheDir, "preview").deleteRecursively()
    }
}
