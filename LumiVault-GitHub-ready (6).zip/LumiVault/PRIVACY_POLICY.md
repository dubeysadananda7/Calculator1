# LumiVault Privacy Policy

**Effective date:** 2026-11-15

LumiVault does not collect, transmit, or share personal data.

## What is stored

- Your secret code is **never stored**. Only a salted PBKDF2 verifier is kept on-device.
- Photos, videos, files, and notes are stored **encrypted** (AES-256-GCM with a
  Keystore-backed key) inside the app's private storage.
- The optional intruder-selfie photo is stored only on-device, inside the app's
  private storage, and only when you explicitly enabled the feature.

## What is never done

- No account registration
- No analytics or tracking SDKs
- No advertising SDKs
- No background uploads
- No browsing history storage (the browser keeps no history)

## Permissions

- Camera: used only if you enable intruder detection.
- Internet: used only by the in-app browser.
- Biometrics: used only to unlock your vault on your device.

## Contact

Replace this line with your support email before publishing.
