package com.lumivault.calculator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.lumivault.calculator.data.repo.SettingsRepository
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.navigation.AppNavGraph
import com.lumivault.calculator.ui.theme.LumiVaultTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private val runtimeLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { /* next step runs in onResume */ }

    private val setupPrefs by lazy { getSharedPreferences("setup", MODE_PRIVATE) }

    private fun runtimePermissions(): Array<String> = buildList {
        if (Build.VERSION.SDK_INT >= 33) {
            add(Manifest.permission.READ_MEDIA_IMAGES)
            add(Manifest.permission.READ_MEDIA_VIDEO)
            add(Manifest.permission.READ_MEDIA_AUDIO)
            add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        add(Manifest.permission.ACCESS_MEDIA_LOCATION)
        add(Manifest.permission.CAMERA)
    }.toTypedArray()

    private fun markAsked(key: String) = setupPrefs.edit().putBoolean(key, true).apply()

    /** Asks for every permission once, one step at a time (runs again after each system screen closes). */
    private fun nextPermissionStep() {
        val missing = runtimePermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty() && !setupPrefs.getBoolean("asked_runtime", false)) {
            markAsked("asked_runtime")
            runtimeLauncher.launch(missing.toTypedArray())
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager() &&
            !setupPrefs.getBoolean("asked_allfiles", false)
        ) {
            markAsked("asked_allfiles")
            val pkg = Uri.parse("package:$packageName")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg))
            } catch (e: Exception) {
                runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }
            return
        }
        if (Build.VERSION.SDK_INT >= 31 && !MediaStore.canManageMedia(this) &&
            !setupPrefs.getBoolean("asked_managemedia", false)
        ) {
            markAsked("asked_managemedia")
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_MANAGE_MEDIA, Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        nextPermissionStep()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as LumiVaultApp
        setContent {
            LumiVaultTheme {
                AppNavGraph(app = app)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Auto-lock the vault when the app leaves the foreground.
        val app = application as LumiVaultApp
        lifecycleScope.launch {
            val s = app.settings.settings.first()
            if (SessionManager.unlocked.value && s.autoLockMinutes <= 15) {
                SessionManager.lock()
            }
        }
    }
}
