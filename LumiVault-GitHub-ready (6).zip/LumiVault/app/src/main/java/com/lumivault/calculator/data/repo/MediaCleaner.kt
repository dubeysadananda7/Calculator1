package com.lumivault.calculator.data.repo

import android.Manifest
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.lumivault.calculator.data.db.VaultItemType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Removes the original file from the phone's gallery after it has been encrypted into the vault.
 * On Android 11+ the system itself asks the user to confirm the delete (one dialog for all items).
 */
object MediaCleaner {

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO,
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun collectionFor(type: VaultItemType): Uri? = when (type) {
        VaultItemType.PHOTO -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        VaultItemType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        VaultItemType.AUDIO -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else -> null
    }

    private fun nameAndSize(resolver: ContentResolver, uri: Uri): Pair<String?, Long?>? =
        resolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null, null, null,
        )?.use { c ->
            if (!c.moveToFirst()) return@use null
            val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val s = c.getColumnIndex(OpenableColumns.SIZE)
            val name = if (n >= 0 && !c.isNull(n)) c.getString(n) else null
            val size = if (s >= 0 && !c.isNull(s)) c.getLong(s) else null
            name to size
        }

    private fun idFrom(uri: Uri): Long? {
        val seg = uri.lastPathSegment ?: return null
        return seg.toLongOrNull() ?: seg.substringAfter(':', "").toLongOrNull()
    }

    /** Converts a picked uri (photo picker / documents) into the real MediaStore uri of the original. */
    suspend fun toMediaUri(context: Context, picked: Uri, type: VaultItemType): Uri? =
        withContext(Dispatchers.IO) {
            runCatching {
                val collection = collectionFor(type) ?: return@runCatching null
                val resolver = context.contentResolver
                val (name, size) = nameAndSize(resolver, picked) ?: return@runCatching null
                if (name == null) return@runCatching null

                // 1) Try the id contained in the picked uri; the file name must match.
                //    (The size can differ because pickers strip location data, so it is not compared.)
                idFrom(picked)?.let { id ->
                    val candidate = ContentUris.withAppendedId(collection, id)
                    val meta = runCatching { nameAndSize(resolver, candidate) }.getOrNull()
                    if (meta != null && meta.first == name) return@runCatching candidate
                }

                // 2) Search by file name. One match -> use it. Several -> use the one with the same size.
                resolver.query(
                    collection,
                    arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.SIZE),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                    arrayOf(name),
                    null,
                )?.use { c ->
                    val rows = mutableListOf<Pair<Long, Long>>()
                    while (c.moveToNext()) rows.add(c.getLong(0) to c.getLong(1))
                    val pick = if (rows.size == 1) rows[0] else rows.filter { it.second == size }.singleOrNull()
                    pick?.let { ContentUris.withAppendedId(collection, it.first) }
                }
            }.getOrNull()
        }

    /** True when the user granted "All files access" (Android 11+). */
    fun hasAllFilesAccess(): Boolean = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    /** Deletes directly (no dialog). Returns the uris that could NOT be deleted. */
    fun deleteDirect(context: Context, uris: List<Uri>): List<Uri> =
        uris.filterNot { u ->
            runCatching { context.contentResolver.delete(u, null, null) > 0 }.getOrDefault(false)
        }

    /** Android 11+: system dialog asking the user to confirm deleting these originals. */
    fun deleteIntentSender(context: Context, uris: List<Uri>): IntentSender? =
        if (Build.VERSION.SDK_INT >= 30 && uris.isNotEmpty())
            runCatching { MediaStore.createDeleteRequest(context.contentResolver, uris).intentSender }.getOrNull()
        else null

    /** Android 10 fallback (no confirmation dialog available). */
    fun deleteLegacy(context: Context, uris: List<Uri>) {
        uris.forEach { runCatching { context.contentResolver.delete(it, null, null) } }
    }

    /** Best effort for documents / other files picked through the file picker. */
    fun deleteDocument(context: Context, uri: Uri): Boolean =
        runCatching { DocumentsContract.deleteDocument(context.contentResolver, uri) }.getOrDefault(false)
}
