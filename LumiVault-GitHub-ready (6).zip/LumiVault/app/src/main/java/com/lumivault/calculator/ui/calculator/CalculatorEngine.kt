package com.lumivault.calculator.ui.calculator

import kotlin.math.abs
import kotlin.math.floor

/**
 * Recursive-descent calculator parser.
 * Supports +, -, x, /, percent (postfix) and decimal numbers.
 */
object CalculatorEngine {

    class ParseError(message: String) : Exception(message)

    fun evaluate(expression: String): String {
        val tokens = Lexer(expression).tokens()
        if (tokens.isEmpty()) return ""
        val value = Parser(tokens).parseExpression()
        return format(value)
    }

    private fun format(v: Double): String {
        if (v.isNaN() || v.isInfinite()) throw ParseError("Can't divide by 0")
        val rounded = floor(v + 0.5)
        return if (abs(v - rounded) < 1e-9 && abs(v) < 1e15) {
            rounded.toLong().toString()
        } else {
            val s = String.format("%.10f", v).trimEnd('0').trimEnd('.')
            s
        }
    }

    private sealed class Tok {
        data class Num(val value: Double) : Tok()
        object Plus : Tok()
        object Minus : Tok()
        object Mul : Tok()
        object Div : Tok()
        object Percent : Tok()
        object LParen : Tok()
        object RParen : Tok()
    }

    private class Lexer(private val input: String) {
        fun tokens(): List<Tok> {
            val out = mutableListOf<Tok>()
            var i = 0
            while (i < input.length) {
                when (val c = input[i]) {
                    ' ' -> i++
                    '+' -> { out += Tok.Plus; i++ }
                    '-' -> { out += Tok.Minus; i++ }
                    'x', 'X', '*' -> { out += Tok.Mul; i++ }
                    '/', '÷' -> { out += Tok.Div; i++ }
                    '%' -> { out += Tok.Percent; i++ }
                    '(' -> { out += Tok.LParen; i++ }
                    ')' -> { out += Tok.RParen; i++ }
                    '.', in '0'..'9' -> {
                        val start = i
                        while (i < input.length && (input[i].isDigit() || input[i] == '.')) i++
                        out += Tok.Num(input.substring(start, i).toDouble())
                    }
                    else -> throw ParseError("Invalid input: $c")
                }
            }
            return out
        }
    }

    private class Parser(private val tokens: List<Tok>) {
        private var pos = 0

        fun parseExpression(): Double {
            var value = parseTerm()
            while (true) {
                when {
                    match(Tok.Plus) -> value += parseTerm()
                    match(Tok.Minus) -> value -= parseTerm()
                    else -> return value
                }
            }
        }

        private fun parseTerm(): Double {
            var value = parseUnary()
            while (true) {
                when {
                    match(Tok.Mul) -> value *= parseUnary()
                    match(Tok.Div) -> {
                        val divisor = parseUnary()
                        if (divisor == 0.0) throw ParseError("Can't divide by 0")
                        value /= divisor
                    }
                    else -> return value
                }
            }
        }

        private fun parseUnary(): Double {
            if (match(Tok.Minus)) return -parseUnary()
            var value = parsePrimary()
            while (match(Tok.Percent)) value /= 100.0
            return value
        }

        private fun parsePrimary(): Double {
            val t = peek()
            return when (t) {
                is Tok.Num -> { pos++; t.value }
                Tok.LParen -> {
                    pos++
                    val v = parseExpression()
                    if (!match(Tok.RParen)) throw ParseError("Missing )")
                    v
                }
                else -> throw ParseError("Invalid expression")
            }
        }

        private fun peek(): Tok? = tokens.getOrNull(pos)
        private fun match(tok: Tok): Boolean {
            if (peek() == tok) { pos++; return true }
            return false
        }
    }
}
