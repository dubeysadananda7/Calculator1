package com.lumivault.calculator.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color(0xFF1B1533),
    primaryContainer = Color(0xFF3B2E8F),
    secondary = Color(0xFF64D8CB),
    background = Color(0xFF0E0C22),
    surface = Color(0xFF16142E),
    surfaceVariant = Color(0xFF232048),
    onBackground = Color(0xFFECEAFF),
    onSurface = Color(0xFFECEAFF),
    onSurfaceVariant = Color(0xFFB9B4E0),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5A48D6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3DEFF),
    secondary = Color(0xFF00897B),
    background = Color(0xFFF6F5FF),
    surface = Color.White,
    surfaceVariant = Color(0xFFE9E6F8),
    onBackground = Color(0xFF1B1533),
    onSurface = Color(0xFF1B1533),
    onSurfaceVariant = Color(0xFF57527A),
)

@Composable
fun LumiVaultTheme(
    themePref: String = "SYSTEM",
    content: @Composable () -> Unit,
) {
    val dark = when (themePref) {
        "LIGHT" -> false
        "DARK" -> true
        else -> isSystemInDarkTheme()
    }
    val context = LocalContext.current
    val colors = when {
        dark && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S ->
            dynamicDarkColorScheme(context)
        !dark && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S ->
            dynamicLightColorScheme(context)
        dark -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = colors, content = content)
}
