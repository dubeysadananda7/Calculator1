package com.lumivault.calculator.data.repo

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.lumivault.calculator.security.PinHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore("lumivault_settings")

data class VaultSettings(
    val pinSaltB64: String? = null,
    val pinHashB64: String? = null,
    val biometricEnabled: Boolean = false,
    val intruderEnabled: Boolean = false,
    val recoveryQuestion: String = "",
    val recoveryAnswerSaltB64: String? = null,
    val recoveryAnswerHashB64: String? = null,
    val recoveryEmail: String = "",
    val theme: String = "SYSTEM", // SYSTEM / LIGHT / DARK
    val autoLockMinutes: Int = 2,
    val lockedApps: Set<String> = emptySet(),
) {
    val pinSet: Boolean get() = pinSaltB64 != null && pinHashB64 != null
}

class SettingsRepository(private val context: Context) {

    private object K {
        val PIN_SALT = stringPreferencesKey("pin_salt")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val BIOMETRIC = booleanPreferencesKey("biometric_enabled")
        val INTRUDER = booleanPreferencesKey("intruder_enabled")
        val REC_Q = stringPreferencesKey("recovery_question")
        val REC_A_SALT = stringPreferencesKey("recovery_answer_salt")
        val REC_A_HASH = stringPreferencesKey("recovery_answer_hash")
        val REC_EMAIL = stringPreferencesKey("recovery_email")
        val THEME = stringPreferencesKey("theme")
        val AUTO_LOCK = intPreferencesKey("auto_lock_minutes")
        val LOCKED_APPS = stringSetPreferencesKey("locked_apps")
    }

    val settings: Flow<VaultSettings> = context.settingsStore.data.map { p ->
        VaultSettings(
            pinSaltB64 = p[K.PIN_SALT],
            pinHashB64 = p[K.PIN_HASH],
            biometricEnabled = p[K.BIOMETRIC] ?: false,
            intruderEnabled = p[K.INTRUDER] ?: false,
            recoveryQuestion = p[K.REC_Q] ?: "",
            recoveryAnswerSaltB64 = p[K.REC_A_SALT],
            recoveryAnswerHashB64 = p[K.REC_A_HASH],
            recoveryEmail = p[K.REC_EMAIL] ?: "",
            theme = p[K.THEME] ?: "SYSTEM",
            autoLockMinutes = p[K.AUTO_LOCK] ?: 2,
            lockedApps = p[K.LOCKED_APPS] ?: emptySet(),
        )
    }

    suspend fun setPin(pin: String) {
        val salt = PinHasher.saltB64()
        context.settingsStore.edit {
            it[K.PIN_SALT] = salt
            it[K.PIN_HASH] = PinHasher.hashB64(pin, salt)
        }
    }

    suspend fun verifyPin(pin: String, s: VaultSettings): Boolean =
        s.pinSaltB64 != null && s.pinHashB64 != null &&
            PinHasher.verify(pin, s.pinSaltB64, s.pinHashB64)

    suspend fun setBiometric(enabled: Boolean) =
        context.settingsStore.edit { it[K.BIOMETRIC] = enabled }

    suspend fun setIntruder(enabled: Boolean) =
        context.settingsStore.edit { it[K.INTRUDER] = enabled }

    suspend fun setRecovery(question: String, answer: String, email: String) {
        val salt = PinHasher.saltB64()
        context.settingsStore.edit {
            it[K.REC_Q] = question
            it[K.REC_A_SALT] = salt
            it[K.REC_A_HASH] = PinHasher.hashAnswer(answer, salt)
            it[K.REC_EMAIL] = email
        }
    }

    suspend fun verifyRecoveryAnswer(answer: String, s: VaultSettings): Boolean =
        s.recoveryAnswerSaltB64 != null && s.recoveryAnswerHashB64 != null &&
            PinHasher.hashAnswer(answer, s.recoveryAnswerSaltB64) == s.recoveryAnswerHashB64

    suspend fun setTheme(theme: String) =
        context.settingsStore.edit { it[K.THEME] = theme }

    suspend fun setAutoLock(minutes: Int) =
        context.settingsStore.edit { it[K.AUTO_LOCK] = minutes }

    suspend fun setAppLocked(packageName: String, locked: Boolean) =
        context.settingsStore.edit { prefs ->
            val current = prefs[K.LOCKED_APPS] ?: emptySet()
            prefs[K.LOCKED_APPS] = if (locked) current + packageName else current - packageName
        }
}
