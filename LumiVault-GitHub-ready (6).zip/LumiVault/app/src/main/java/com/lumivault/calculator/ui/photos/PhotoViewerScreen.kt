package com.lumivault.calculator.ui.photos

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.ConfirmDialog
import java.io.File

@Composable
fun PhotoViewerScreen(app: LumiVaultApp, itemId: String, nav: NavHostController) {
    val vm = remember(app) { PhotosViewModel(app) }
    val photos by vm.photos.collectAsStateWithLifecycle()
    val startIndex = photos.indexOfFirst { it.id == itemId }.coerceAtLeast(0)
    val pager = rememberPagerState(initialPage = startIndex) { photos.size }
    var confirmDelete by remember { mutableStateOf(false) }
    val current = photos.getOrNull(pager.currentPage)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        if (photos.isEmpty()) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        } else {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                val item = photos[page]
                val file by produceState<File?>(initialValue = null, item.id) {
                    value = vm.preview(item)
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    file?.let {
                        AsyncImage(
                            model = it,
                            contentDescription = item.displayName,
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.Fit,
                        )
                    } ?: CircularProgressIndicator()
                }
            }
        }
        Column(Modifier.align(Alignment.TopStart)) {
            com.lumivault.calculator.ui.components.VaultTopBar(
                title = current?.displayName ?: "Photo",
                onBack = { nav.popBackStack() },
                actions = {
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.White)
                    }
                },
            )
        }
    }

    if (confirmDelete && current != null) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "You can restore it later from the recycle bin.",
            confirmLabel = "Move",
            onConfirm = {
                vm.delete(current)
                confirmDelete = false
                nav.popBackStack()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
