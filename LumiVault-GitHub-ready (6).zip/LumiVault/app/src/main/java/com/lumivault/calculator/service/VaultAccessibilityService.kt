package com.lumivault.calculator.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.security.SessionManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Best-effort app lock. When a locked app comes to the foreground, LumiVault
 * brings itself forward so the secret code is required again.
 * Limitations: cannot survive uninstall, safe mode, or the service being disabled.
 */
class VaultAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == this.packageName) return

        val app = application as LumiVaultApp
        val locked = runBlocking { app.settings.settings.first().lockedApps }
        if (locked.contains(packageName) && !SessionManager.unlocked.value) {
            val intent = Intent(this, com.lumivault.calculator.MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            runCatching { startActivity(intent) }
        }
    }

    override fun onInterrupt() = Unit
}
