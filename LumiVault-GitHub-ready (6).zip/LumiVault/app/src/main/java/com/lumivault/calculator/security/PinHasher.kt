package com.lumivault.calculator.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PinHasher {
    private const val ALGO = "PBKDF2WithHmacSHA256"
    private const val ITERATIONS = 120_000
    private const val KEY_BITS = 256

    fun newSalt(): ByteArray = SecureRandom().generateSeed(16)

    fun hash(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_BITS)
        return SecretKeyFactory.getInstance(ALGO).generateSecret(spec).encoded
    }

    fun hashB64(pin: String, saltB64: String): String =
        Base64.encodeToString(hash(pin, Base64.decode(saltB64, Base64.NO_WRAP)), Base64.NO_WRAP)

    fun saltB64(): String = Base64.encodeToString(newSalt(), Base64.NO_WRAP)

    fun verify(pin: String, saltB64: String, expectedB64: String): Boolean {
        val actual = hash(pin, Base64.decode(saltB64, Base64.NO_WRAP))
        val expected = Base64.decode(expectedB64, Base64.NO_WRAP)
        return actual.size == expected.size && MessageDigest.isEqual(actual, expected)
    }

    fun hashAnswer(answer: String, saltB64: String): String =
        hashB64(answer.trim().lowercase(), saltB64)
}
