package com.lumivault.calculator.ui.calculator

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumivault.calculator.LumiVaultApp

private val BgColor = Color(0xFF070707)
private val FnColor = Color(0xFF221F1E)     // AC, %, operators
private val DigitColor = Color(0xFF24252F)  // 0-9 and .
private val Accent = Color(0xFFFF6A00)      // =, backspace icon

@Composable
fun CalculatorScreen(app: LumiVaultApp, onUnlock: () -> Unit) {
    val vm: CalculatorViewModel = viewModel(
        factory = remember(app) {
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
        }
    )

    LaunchedEffect(Unit) {
        vm.unlockEvent.collect { onUnlock() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .systemBarsPadding(),
    ) {
        // ---- Display ----
        val shown = vm.expression.replace("x", "×").replace("/", "÷")
        val shownSize = when {
            shown.length <= 7 -> 68.sp
            shown.length <= 11 -> 52.sp
            else -> 38.sp
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.Bottom,
        ) {
            if (shown.isNotEmpty()) {
                Text(
                    shown,
                    fontSize = shownSize,
                    fontWeight = FontWeight.Light,
                    color = Color.White,
                    textAlign = TextAlign.End,
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            val secondary = when {
                vm.error != null -> vm.error!!
                vm.result.isNotEmpty() && vm.result != vm.expression -> vm.result
                else -> ""
            }
            if (secondary.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    secondary,
                    fontSize = 28.sp,
                    color = if (vm.error != null) Color(0xFFFF8A80) else Color(0xFF9E9E9E),
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        // ---- Keypad ----
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 20.dp),
        ) {
            val gap = 12.dp
            val size: Dp = (maxWidth - gap * 3) / 4

            Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key(icon = Icons.Outlined.Backspace, iconTint = Accent, size = size, bg = FnColor) { vm.onDelete() }
                    Key("AC", size = size, bg = FnColor) { vm.onClear() }
                    Key("%", size = size, bg = FnColor) { vm.onPercent() }
                    Key("÷", size = size, bg = FnColor) { vm.onOperator("/") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("7", size = size) { vm.onDigit("7") }
                    Key("8", size = size) { vm.onDigit("8") }
                    Key("9", size = size) { vm.onDigit("9") }
                    Key("×", size = size, bg = FnColor) { vm.onOperator("x") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("4", size = size) { vm.onDigit("4") }
                    Key("5", size = size) { vm.onDigit("5") }
                    Key("6", size = size) { vm.onDigit("6") }
                    Key("−", size = size, bg = FnColor) { vm.onOperator("-") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("1", size = size) { vm.onDigit("1") }
                    Key("2", size = size) { vm.onDigit("2") }
                    Key("3", size = size) { vm.onDigit("3") }
                    Key("+", size = size, bg = FnColor) { vm.onOperator("+") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("0", size = size) { vm.onDigit("0") }
                    Key(".", size = size) { vm.onDigit(".") }
                    Key("=", size = size, wide = true, bg = Accent) { vm.onEquals() }
                }
            }
        }
    }
}

@Composable
private fun Key(
    label: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = Color.White,
    size: Dp,
    wide: Boolean = false,
    bg: Color = DigitColor,
    onClick: () -> Unit,
) {
    val gap = 12.dp
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = bg,
        modifier = if (wide) Modifier.size(width = size * 2 + gap, height = size) else Modifier.size(size),
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (icon != null) {
                Icon(icon, contentDescription = "Delete", tint = iconTint)
            } else {
                Text(
                    label.orEmpty(),
                    fontSize = if (label == "AC") 34.sp else 40.sp,
                    fontWeight = FontWeight.Light,
                    color = Color.White,
                )
            }
        }
    }
}
