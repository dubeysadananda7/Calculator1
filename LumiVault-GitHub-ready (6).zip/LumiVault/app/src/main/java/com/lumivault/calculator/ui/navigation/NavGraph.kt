package com.lumivault.calculator.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.browser.BrowserScreen
import com.lumivault.calculator.ui.calculator.CalculatorScreen
import com.lumivault.calculator.ui.files.FilesScreen
import com.lumivault.calculator.ui.intruder.IntruderScreen
import com.lumivault.calculator.ui.notes.NoteEditScreen
import com.lumivault.calculator.ui.notes.NotesScreen
import com.lumivault.calculator.ui.photos.PhotoViewerScreen
import com.lumivault.calculator.ui.photos.PhotosScreen
import com.lumivault.calculator.ui.pin.PinScreen
import com.lumivault.calculator.ui.pin.PinMode
import com.lumivault.calculator.ui.recyclebin.RecycleBinScreen
import com.lumivault.calculator.ui.settings.SettingsScreen
import com.lumivault.calculator.ui.vault.VaultHomeScreen
import com.lumivault.calculator.ui.videos.VideoPlayerScreen
import com.lumivault.calculator.ui.videos.VideosScreen
import com.lumivault.calculator.ui.applock.AppLockScreen
import kotlinx.coroutines.flow.first

@Composable
fun AppNavGraph(app: LumiVaultApp) {
    val nav = rememberNavController()

    // Decide start destination once based on whether a PIN exists.
    val start by produceState<String?>(initialValue = null) {
        val s = app.settings.settings.first()
        value = if (s.pinSet) Routes.CALCULATOR else Routes.PIN_SETUP
    }

    val startRoute = start ?: return

    NavHost(navController = nav, startDestination = startRoute) {
        composable(Routes.CALCULATOR) {
            CalculatorScreen(app = app, onUnlock = {
                nav.navigate(Routes.VAULT) { popUpTo(Routes.CALCULATOR) }
            })
        }
        composable(Routes.PIN_SETUP) {
            PinScreen(app = app, mode = PinMode.SETUP, onDone = {
                nav.navigate(Routes.CALCULATOR) { popUpTo(0) }
            })
        }
        composable(Routes.PIN_CHANGE) {
            PinScreen(app = app, mode = PinMode.CHANGE, onDone = { nav.popBackStack() })
        }
        composable(Routes.VAULT) {
            VaultHomeScreen(app = app, nav = nav)
        }
        composable(Routes.PHOTOS) {
            PhotosScreen(app = app, nav = nav)
        }
        composable(Routes.PHOTO_VIEWER) { entry ->
            PhotoViewerScreen(app = app, itemId = entry.arguments?.getString("id").orEmpty(), nav = nav)
        }
        composable(Routes.VIDEOS) {
            VideosScreen(app = app, nav = nav)
        }
        composable(Routes.VIDEO_PLAYER) { entry ->
            VideoPlayerScreen(app = app, itemId = entry.arguments?.getString("id").orEmpty(), nav = nav)
        }
        composable(Routes.FILES) {
            FilesScreen(app = app, nav = nav)
        }
        composable(Routes.NOTES) {
            NotesScreen(app = app, nav = nav)
        }
        composable(Routes.NOTE_EDIT) { entry ->
            NoteEditScreen(app = app, noteId = entry.arguments?.getString("id"), nav = nav)
        }
        composable(Routes.BROWSER) {
            BrowserScreen(nav = nav)
        }
        composable(Routes.RECYCLE_BIN) {
            RecycleBinScreen(app = app, nav = nav)
        }
        composable(Routes.INTRUDER) {
            IntruderScreen(app = app, nav = nav)
        }
        composable(Routes.APP_LOCK) {
            AppLockScreen(app = app, nav = nav)
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(app = app, nav = nav)
        }
    }
}
