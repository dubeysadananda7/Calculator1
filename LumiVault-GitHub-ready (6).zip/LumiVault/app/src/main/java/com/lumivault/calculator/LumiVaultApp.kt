package com.lumivault.calculator

import android.app.Application
import com.lumivault.calculator.data.db.VaultDatabase
import com.lumivault.calculator.data.repo.NotesRepository
import com.lumivault.calculator.data.repo.SecurityRepository
import com.lumivault.calculator.data.repo.SettingsRepository
import com.lumivault.calculator.data.repo.VaultRepository

class LumiVaultApp : Application() {

    lateinit var settings: SettingsRepository
        private set
    lateinit var vault: VaultRepository
        private set
    lateinit var notes: NotesRepository
        private set
    lateinit var security: SecurityRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = VaultDatabase.get(this)
        settings = SettingsRepository(this)
        vault = VaultRepository(this, db.vaultItemDao())
        notes = NotesRepository(db.noteDao())
        security = SecurityRepository(this, db.securityEventDao())
    }
}
