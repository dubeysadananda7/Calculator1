package com.lumivault.calculator.ui.recyclebin

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.files.formatSize
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RecycleBinViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).vault
    val items = repo.recycleBin().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    fun restore(id: String) = viewModelScope.launch { repo.restore(id) }
    fun deleteForever(item: VaultItemEntity) = viewModelScope.launch { repo.deletePermanently(item) }
    fun emptyAll(items: List<VaultItemEntity>) = viewModelScope.launch { repo.emptyRecycleBin(items) }
}

@Composable
fun RecycleBinScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { RecycleBinViewModel(app) }
    val items by vm.items.collectAsStateWithLifecycle()
    var confirmEmpty by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<VaultItemEntity?>(null) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            VaultTopBar(
                title = "Recycle bin",
                onBack = { nav.popBackStack() },
                actions = {
                    if (items.isNotEmpty()) {
                        IconButton(onClick = { confirmEmpty = true }) {
                            Icon(Icons.Default.DeleteForever, contentDescription = "Empty bin")
                        }
                    }
                },
            )
            if (items.isEmpty()) {
                EmptyState(Icons.Default.DeleteOutline, "Recycle bin is empty", "Deleted items will appear here")
            } else {
                LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
                    items(items, key = { it.id }) { item ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(
                                Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(item.displayName, style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        "${item.type.lowercase()} · ${formatSize(item.sizeBytes)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(onClick = { vm.restore(item.id) }) {
                                    Icon(Icons.Default.Restore, contentDescription = "Restore")
                                }
                                Spacer(Modifier.width(2.dp))
                                IconButton(onClick = { toDelete = item }) {
                                    Icon(
                                        Icons.Default.DeleteForever,
                                        contentDescription = "Delete forever",
                                        tint = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmEmpty) {
        ConfirmDialog(
            title = "Empty recycle bin?",
            text = "All ${items.size} item(s) will be permanently deleted.",
            confirmLabel = "Delete all",
            onConfirm = { vm.emptyAll(items); confirmEmpty = false },
            onDismiss = { confirmEmpty = false },
        )
    }
    toDelete?.let { item ->
        ConfirmDialog(
            title = "Delete forever?",
            text = "\"${item.displayName}\" will be permanently deleted. This cannot be undone.",
            confirmLabel = "Delete",
            onConfirm = { vm.deleteForever(item); toDelete = null },
            onDismiss = { toDelete = null },
        )
    }
}
