package com.lumivault.calculator.security

import androidx.compose.runtime.mutableStateOf

/** In-memory vault session. Cleared on process death; auto-lock re-locks in the background. */
object SessionManager {
    val unlocked = mutableStateOf(false)
    @Volatile private var lastInteraction: Long = System.currentTimeMillis()

    fun touch() { lastInteraction = System.currentTimeMillis() }

    fun unlock() {
        unlocked.value = true
        touch()
    }

    fun lock() { unlocked.value = false }

    fun isStale(autoLockMinutes: Int): Boolean =
        unlocked.value && System.currentTimeMillis() - lastInteraction > autoLockMinutes * 60_000L
}
