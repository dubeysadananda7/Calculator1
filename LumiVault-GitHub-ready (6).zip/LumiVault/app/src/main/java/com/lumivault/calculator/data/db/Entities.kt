package com.lumivault.calculator.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class VaultItemType { PHOTO, VIDEO, AUDIO, DOCUMENT, OTHER }

enum class SecurityEventKind { PIN_FAIL, INTRUDER_SELFIE, UNLOCK }

@Entity(tableName = "vault_items")
data class VaultItemEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val type: String,
    val displayName: String,
    val mimeType: String?,
    val encryptedPath: String,
    val sizeBytes: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val deleted: Boolean = false,
    val deletedAt: Long? = null,
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val bodyEncrypted: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "security_events")
data class SecurityEventEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val kind: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val photoPath: String? = null,
)
