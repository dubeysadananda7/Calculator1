package com.lumivault.calculator.ui.vault

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumivault.calculator.ui.wallpaper.Wallpapers
import kotlinx.coroutines.flow.map
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.navigation.Routes

/** A launcher-style tile. [route] == null means the feature isn't built yet. */
private class Tile(
    val label: String,
    val icon: ImageVector,
    val top: Color,
    val bottom: Color,
    val route: String?,
    val iconTint: Color = Color.White,
)

private val TopRow = listOf(
    Tile("Hide contacts", Icons.Filled.Person, Color(0xFF3D7BFF), Color(0xFF1D34D6), Routes.CONTACTS),
    Tile("File transfer", Icons.Filled.SwapHoriz, Color(0xFF3FE6B4), Color(0xFF1790EA), null),
)

private val GridRows = listOf(
    listOf(
        Tile("File manager", Icons.Filled.Folder, Color(0xFFF2604B), Color(0xFFD62F22), Routes.FILES),
        Tile("Notes", Icons.Filled.Notes, Color(0xFFFFD83A), Color(0xFFFF9F0A), Routes.NOTES),
        Tile("App lock", Icons.Filled.Lock, Color(0xFF1FE05A), Color(0xFF0AA13A), Routes.APP_LOCK),
        Tile("Browser", Icons.Filled.Public, Color(0xFF3AC3FF), Color(0xFF1B5CF2), Routes.BROWSER),
    ),
    listOf(
        Tile("Hide apps", Icons.Filled.VisibilityOff, Color(0xFF45EBC0), Color(0xFF1BAE7C), Routes.HIDE_APPS),
        Tile("Wallpaper", Icons.Filled.FormatPaint, Color(0xFFF063F0), Color(0xFF2D4BF0), Routes.WALLPAPER),
        Tile("Trash", Icons.Filled.Delete, Color(0xFFFFB347), Color(0xFFE8731A), Routes.RECYCLE_BIN),
        Tile("Intruder camera", Icons.Filled.Face, Color(0xFF6B7BFF), Color(0xFF4A3FE0), Routes.INTRUDER),
    ),
)

private val Dock = listOf(
    Tile("Photos", Icons.Filled.PhotoLibrary, Color(0xFFFF5A8A), Color(0xFFFF8A3D), Routes.PHOTOS),
    Tile("Videos", Icons.Filled.Videocam, Color(0xFFFF9A4D), Color(0xFFFF5A1F), Routes.VIDEOS),
    Tile("Add", Icons.Filled.Add, Color.White, Color.White, Routes.FILES, iconTint = Color(0xFFFF6A00)),
    Tile("Camera", Icons.Filled.CameraAlt, Color(0xFFF2F2F5), Color(0xFFC9CAD2), Routes.CAMERA, iconTint = Color(0xFF2A2A30)),
    Tile("Settings", Icons.Filled.Settings, Color(0xFF9A9CA6), Color(0xFF5E6068), Routes.SETTINGS),
)

@Composable
fun VaultHomeScreen(app: LumiVaultApp, nav: NavHostController) {
    var soon by remember { mutableStateOf<String?>(null) }
    val open: (Tile) -> Unit = { t ->
        if (t.route != null) nav.navigate(t.route) else soon = t.label
    }

    // Back = lock the vault and return to the calculator.
    BackHandler {
        SessionManager.lock()
        nav.navigate(Routes.CALCULATOR) { popUpTo(0) }
    }

    Box(Modifier.fillMaxSize()) {
        val wallpaperId by remember(app) { app.settings.settings.map { it.wallpaper } }
            .collectAsStateWithLifecycle(initialValue = "")
        val chosen = Wallpapers.byId(wallpaperId)
        if (chosen != null) {
            Image(
                painter = painterResource(chosen.full),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
            // soft dark fade so icon names stay readable on any picture
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color(0x66000000),
                            0.35f to Color(0x14000000),
                            0.62f to Color(0x55000000),
                            1f to Color(0xCC000000),
                        )
                    )
            )
        } else {
            Wallpaper()
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 12.dp),
        ) {
            Spacer(Modifier.height(48.dp))
            SearchPill(onClick = { nav.navigate(Routes.BROWSER) })
            Spacer(Modifier.height(36.dp))
            IconRow(TopRow, open)

            // The free space between the top icons and the grid holds the native ad.
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(top = 18.dp, bottom = 8.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                com.lumivault.calculator.ui.ads.NativeAdCard()
            }

            GridRows.forEach { row ->
                IconRow(row, open)
                Spacer(Modifier.height(26.dp))
            }

            Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color.White))
            }
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(34.dp))
                    .background(Color(0xFF2D2D30))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Dock.forEach { t ->
                    IconBox(t, round = t.label == "Add", onClick = { open(t) })
                }
            }
        }
    }

    soon?.let { name ->
        AlertDialog(
            onDismissRequest = { soon = null },
            title = { Text(name) },
            text = { Text("This feature isn’t available yet.") },
            confirmButton = { TextButton(onClick = { soon = null }) { Text("OK") } },
        )
    }
}

@Composable
private fun Wallpaper() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            Brush.verticalGradient(
                0f to Color(0xFF151A3E),
                0.28f to Color(0xFF343A78),
                0.40f to Color(0xFF6A5B8E),
                0.47f to Color(0xFFB07A78),
                0.50f to Color(0xFF2A2230),
                1f to Color(0xFF000000),
            )
        )
        val ridge = Path().apply {
            moveTo(0f, h * 0.49f)
            lineTo(w * 0.10f, h * 0.505f)
            lineTo(w * 0.22f, h * 0.490f)
            lineTo(w * 0.34f, h * 0.500f)
            lineTo(w * 0.46f, h * 0.465f)
            lineTo(w * 0.50f, h * 0.458f)
            lineTo(w * 0.60f, h * 0.468f)
            lineTo(w * 0.72f, h * 0.488f)
            lineTo(w * 0.85f, h * 0.500f)
            lineTo(w, h * 0.490f)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(ridge, Color(0xFF040408))
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(CircleShape)
            .background(Color(0xFF6B779C).copy(alpha = 0.9f))
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.size(16.dp))
        Text("Search or enter URL", color = Color.White, fontSize = 18.sp)
    }
}

@Composable
private fun IconRow(tiles: List<Tile>, onOpen: (Tile) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        repeat(4) { i ->
            val t = tiles.getOrNull(i)
            if (t != null) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    IconBox(t, round = false, onClick = { onOpen(t) })
                    Spacer(Modifier.height(8.dp))
                    Text(
                        t.label,
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable { onOpen(t) },
                    )
                }
            } else {
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun IconBox(t: Tile, round: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(58.dp)
            .clip(if (round) CircleShape else RoundedCornerShape(19.dp))
            .background(Brush.verticalGradient(listOf(t.top, t.bottom)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(t.icon, contentDescription = t.label, tint = t.iconTint, modifier = Modifier.size(30.dp))
    }
}
