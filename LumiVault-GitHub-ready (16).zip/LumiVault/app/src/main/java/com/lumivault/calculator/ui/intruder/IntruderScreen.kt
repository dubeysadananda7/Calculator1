package com.lumivault.calculator.ui.intruder

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.SecurityEventEntity
import com.lumivault.calculator.security.CryptoManager
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class IntruderViewModel(app: Application) : AndroidViewModel(app) {
    private val vaultApp = app as LumiVaultApp
    private val repo = vaultApp.security

    val events = repo.events.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val enabled = vaultApp.settings.settings.map { it.intruderEnabled }
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    fun setEnabled(v: Boolean) = viewModelScope.launch { vaultApp.settings.setIntruder(v) }

    fun delete(e: SecurityEventEntity) = viewModelScope.launch {
        e.photoPath?.let { withContext(Dispatchers.IO) { File(it).delete() } }
        repo.delete(e.id)
    }

    fun clear() = viewModelScope.launch {
        withContext(Dispatchers.IO) { repo.intruderDir().listFiles()?.forEach { it.delete() } }
        repo.clear()
    }

    fun format(ts: Long) = repo.formatTime(ts)
}

@Composable
fun IntruderScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { IntruderViewModel(app) }
    val events by vm.events.collectAsStateWithLifecycle()
    val enabled by vm.enabled.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun switchTo(on: Boolean) {
        vm.setEnabled(on)
        if (on && ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            SessionManager.beginExternal()
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(
                title = "Intruder camera",
                onBack = { nav.popBackStack() },
                actions = {
                    if (events.isNotEmpty()) {
                        IconButton(onClick = { vm.clear() }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Clear all", tint = Color(0xFFFF8A80))
                        }
                    }
                },
            )
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item { StatusCard(enabled) { switchTo(it) } }
                if (events.isEmpty()) {
                    item {
                        Column(
                            Modifier.fillMaxWidth().padding(top = 36.dp, start = 12.dp, end = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Icon(Icons.Filled.Face, contentDescription = null, tint = Pal.Muted, modifier = Modifier.size(52.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("No intruders so far", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "If someone types a wrong secret code in the calculator, their photo will appear here.",
                                color = Pal.Muted, fontSize = 14.sp,
                            )
                        }
                    }
                } else {
                    items(events, key = { it.id }) { e -> EventCard(e, vm.format(e.timestamp)) { vm.delete(e) } }
                }
            }
        }
    }
}

@Composable
private fun StatusCard(enabled: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
            .border(1.dp, if (enabled) Color(0x5531D07A) else Pal.Border, shape)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                if (enabled) "Intruder camera is ON" else "Intruder camera is OFF",
                color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "A wrong secret code silently takes a front-camera photo. It is saved only here, encrypted, never in the gallery.",
                color = Pal.Muted, fontSize = 13.sp,
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = enabled,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = Pal.Orange,
                uncheckedThumbColor = Pal.Muted, uncheckedTrackColor = Pal.CardHi, uncheckedBorderColor = Pal.Border,
            ),
        )
    }
}

@Composable
private fun EventCard(event: SecurityEventEntity, time: String, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
            .border(1.dp, Pal.Border, shape),
    ) {
        event.photoPath?.let { path ->
            // Photos are stored encrypted; decrypt to the (auto-cleared) preview cache only for display.
            val file by produceState<File?>(initialValue = null, path) {
                value = withContext(Dispatchers.IO) {
                    runCatching {
                        val out = File(context.cacheDir, "preview/intr_${File(path).name}.jpg")
                        out.parentFile?.mkdirs()
                        if (!out.exists() || out.length() == 0L) CryptoManager.decryptFile(File(path), out)
                        out
                    }.getOrNull()
                }
            }
            Box(
                Modifier.fillMaxWidth().aspectRatio(4f / 3f).background(Pal.Bg),
                contentAlignment = Alignment.Center,
            ) {
                file?.let {
                    AsyncImage(
                        model = it,
                        contentDescription = "Intruder photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = Pal.Orange)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (event.photoPath != null) "Wrong code · photo taken" else event.message,
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                )
                Text(time, color = Pal.Muted, fontSize = 13.sp)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete", tint = Pal.Muted)
            }
        }
    }
}
