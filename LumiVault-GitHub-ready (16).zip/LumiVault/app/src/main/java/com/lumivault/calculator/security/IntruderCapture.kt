package com.lumivault.calculator.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.lumivault.calculator.data.repo.SecurityRepository
import java.io.File
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * Silent front-camera photo when a wrong secret code is entered.
 * The photo is written to a temporary private file, encrypted into the vault and the temporary file is deleted,
 * so it never appears in the gallery.
 */
object IntruderCapture {

    private const val TAG = "IntruderCapture"

    /** Takes the photo and records the event. Falls back to a plain "wrong code" event if no photo is possible. */
    suspend fun captureAndRecord(context: Context, owner: LifecycleOwner, security: SecurityRepository) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        val photo = if (granted) takeSelfie(context, owner) else null
        if (photo != null) security.storeIntruderPhoto(photo) else security.recordPinFail()
    }

    private suspend fun takeSelfie(context: Context, owner: LifecycleOwner): File? =
        suspendCancellableCoroutine { cont ->
            val dir = File(context.cacheDir, "capture").apply { mkdirs() }
            val out = File(dir, "selfie_${System.currentTimeMillis()}.jpg")
            val future = ProcessCameraProvider.getInstance(context)
            future.addListener({
                try {
                    val provider = future.get()
                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build()
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, capture)
                    // Give auto-exposure a moment, otherwise the first frame is often black.
                    Handler(Looper.getMainLooper()).postDelayed({
                        capture.takePicture(
                            ImageCapture.OutputFileOptions.Builder(out).build(),
                            ContextCompat.getMainExecutor(context),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                    runCatching { provider.unbindAll() }
                                    if (cont.isActive) cont.resume(out)
                                }

                                override fun onError(exception: ImageCaptureException) {
                                    Log.w(TAG, "Selfie capture failed", exception)
                                    runCatching { provider.unbindAll() }
                                    if (cont.isActive) cont.resume(null)
                                }
                            }
                        )
                    }, 700)
                } catch (t: Throwable) {
                    Log.w(TAG, "Selfie capture unavailable", t)
                    if (cont.isActive) cont.resume(null)
                }
            }, ContextCompat.getMainExecutor(context))
        }
}
