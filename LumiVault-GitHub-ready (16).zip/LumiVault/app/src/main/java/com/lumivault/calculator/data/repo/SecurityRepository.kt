package com.lumivault.calculator.data.repo

import android.content.Context
import com.lumivault.calculator.data.db.SecurityEventDao
import com.lumivault.calculator.data.db.SecurityEventEntity
import com.lumivault.calculator.data.db.SecurityEventKind
import com.lumivault.calculator.security.CryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.Flow

class SecurityRepository(
    private val context: Context,
    private val dao: SecurityEventDao,
) {
    val events: Flow<List<SecurityEventEntity>> = dao.observeAll()

    suspend fun recordPinFail() = dao.insert(
        SecurityEventEntity(kind = SecurityEventKind.PIN_FAIL.name, message = "Wrong secret code entered")
    )

    suspend fun recordUnlock() = dao.insert(
        SecurityEventEntity(kind = SecurityEventKind.UNLOCK.name, message = "Vault unlocked")
    )

    suspend fun recordIntruder(photoPath: String?) = dao.insert(
        SecurityEventEntity(
            kind = SecurityEventKind.INTRUDER_SELFIE.name,
            message = "Intruder attempt recorded",
            photoPath = photoPath,
        )
    )

    /** Encrypts the selfie into the vault, deletes the plain temp file and records the event. */
    suspend fun storeIntruderPhoto(plain: File) = withContext(Dispatchers.IO) {
        val enc = File(intruderDir(), plain.name + ".enc")
        val ok = runCatching {
            plain.inputStream().use { CryptoManager.encryptFile(it, enc) }
        }.isSuccess
        plain.delete()
        if (ok) recordIntruder(enc.absolutePath) else recordPinFail()
    }

    fun intruderDir(): File = File(context.filesDir, "intruder").apply { mkdirs() }

    suspend fun clear() = dao.clear()
    suspend fun delete(id: String) = dao.delete(id)

    fun formatTime(ts: Long): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ts))
}
