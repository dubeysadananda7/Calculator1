package com.lumivault.calculator.ui.calculator

import java.math.BigDecimal
import java.math.MathContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Small recursive-descent calculator.
 * Supports + - x / ^ ! %, brackets, π, e, √, sin cos tan (and their inverses), ln and log.
 * Brackets may be left open (they are closed automatically) and 2(3+4), 2π, 3sin(30) mean multiplication.
 * Trigonometry works in degrees or radians ([degrees]).
 */
object CalculatorEngine {

    class ParseError(message: String) : Exception(message)

    fun evaluate(expression: String, degrees: Boolean = true): String {
        var e = expression
        val open = e.count { it == '(' }
        val close = e.count { it == ')' }
        if (open > close) e += ")".repeat(open - close)   // "(2+3" works like "(2+3)"

        val tokens = Lexer(e).tokens()
        if (tokens.isEmpty()) return ""
        val parser = Parser(tokens, degrees)
        val value = parser.parseExpression()
        if (!parser.atEnd()) throw ParseError("Invalid expression")   // e.g. an extra ")"
        return format(value)
    }

    private fun format(v: Double): String {
        if (v.isNaN() || v.isInfinite()) throw ParseError("Can't calculate")
        val rounded = floor(v + 0.5)
        if (abs(v - rounded) < 1e-9 && abs(v) < 1e15) return rounded.toLong().toString()
        if (abs(v) >= 1e15) return BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toString()
        return String.format(Locale.US, "%.10f", v).trimEnd('0').trimEnd('.')
    }

    // ---------------------------------------------------------------- tokens

    private sealed class Tok {
        data class Num(val value: Double) : Tok()
        data class Const(val value: Double) : Tok()
        data class Func(val name: String) : Tok()
        object Plus : Tok()
        object Minus : Tok()
        object Mul : Tok()
        object Div : Tok()
        object Percent : Tok()
        object Pow : Tok()
        object Fact : Tok()
        object LParen : Tok()
        object RParen : Tok()
    }

    private val FUNCS = listOf(
        "sin⁻¹" to "asin", "cos⁻¹" to "acos", "tan⁻¹" to "atan",
        "sin" to "sin", "cos" to "cos", "tan" to "tan",
        "log" to "log", "ln" to "ln",
    )

    private class Lexer(private val input: String) {
        fun tokens(): List<Tok> {
            val out = mutableListOf<Tok>()
            var i = 0
            while (i < input.length) {
                val c = input[i]
                when {
                    c == ' ' -> i++
                    c == '+' -> { out.add(Tok.Plus); i++ }
                    c == '-' || c == '−' -> { out.add(Tok.Minus); i++ }
                    c == 'x' || c == 'X' || c == '*' || c == '×' -> { out.add(Tok.Mul); i++ }
                    c == '/' || c == '÷' -> { out.add(Tok.Div); i++ }
                    c == '%' -> { out.add(Tok.Percent); i++ }
                    c == '^' -> { out.add(Tok.Pow); i++ }
                    c == '!' -> { out.add(Tok.Fact); i++ }
                    c == '(' -> { out.add(Tok.LParen); i++ }
                    c == ')' -> { out.add(Tok.RParen); i++ }
                    c == 'π' -> { out.add(Tok.Const(Math.PI)); i++ }
                    c == '√' -> { out.add(Tok.Func("sqrt")); i++ }
                    c.isDigit() || c == '.' -> {
                        var j = i
                        while (j < input.length && (input[j].isDigit() || input[j] == '.')) j++
                        val n = input.substring(i, j).toDoubleOrNull() ?: throw ParseError("Invalid number")
                        out.add(Tok.Num(n))
                        i = j
                    }
                    else -> {
                        val f = FUNCS.firstOrNull { input.startsWith(it.first, i) }
                        when {
                            f != null -> { out.add(Tok.Func(f.second)); i += f.first.length }
                            c == 'e' -> { out.add(Tok.Const(Math.E)); i++ }
                            else -> throw ParseError("Invalid expression")
                        }
                    }
                }
            }
            return out
        }
    }

    // ---------------------------------------------------------------- parser

    private class Parser(private val tokens: List<Tok>, private val useDeg: Boolean) {
        private var pos = 0

        fun atEnd(): Boolean = pos >= tokens.size

        private fun peek(): Tok? = tokens.getOrNull(pos)

        private fun match(t: Tok): Boolean {
            if (peek() == t) { pos++; return true }
            return false
        }

        fun parseExpression(): Double {
            var value = parseTerm()
            while (true) {
                when {
                    match(Tok.Plus) -> value += parseTerm()
                    match(Tok.Minus) -> value -= parseTerm()
                    else -> return value
                }
            }
        }

        private fun startsOperand(t: Tok?): Boolean =
            t is Tok.LParen || t is Tok.Num || t is Tok.Const || t is Tok.Func

        private fun parseTerm(): Double {
            var value = parseUnary()
            while (true) {
                when {
                    match(Tok.Mul) -> value *= parseUnary()
                    match(Tok.Div) -> {
                        val d = parseUnary()
                        if (d == 0.0) throw ParseError("Can't divide by 0")
                        value /= d
                    }
                    // implicit multiplication: 2(3+4), (1+2)3, 2π, 3sin(30)
                    startsOperand(peek()) -> value *= parseUnary()
                    else -> return value
                }
            }
        }

        private fun parseUnary(): Double {
            if (match(Tok.Minus)) return -parseUnary()
            if (match(Tok.Plus)) return parseUnary()
            return parsePower()
        }

        private fun parsePower(): Double {
            val base = parsePostfix()
            if (match(Tok.Pow)) {
                val exponent = parseUnary()          // right-associative, and 2^-3 works
                val r = base.pow(exponent)
                if (r.isNaN()) throw ParseError("Invalid input")
                return r
            }
            return base
        }

        private fun parsePostfix(): Double {
            var v = parsePrimary()
            while (true) {
                when {
                    match(Tok.Percent) -> v /= 100.0
                    match(Tok.Fact) -> v = factorial(v)
                    else -> return v
                }
            }
        }

        private fun parsePrimary(): Double {
            val t = peek()
            return when (t) {
                is Tok.Num -> { pos++; t.value }
                is Tok.Const -> { pos++; t.value }
                is Tok.Func -> { pos++; applyFunc(t.name, parseArgument()) }
                Tok.LParen -> {
                    pos++
                    val v = parseExpression()
                    if (!match(Tok.RParen)) throw ParseError("Missing )")
                    v
                }
                else -> throw ParseError("Invalid expression")
            }
        }

        private fun parseArgument(): Double {
            if (match(Tok.LParen)) {
                val v = parseExpression()
                if (!match(Tok.RParen)) throw ParseError("Missing )")
                return v
            }
            return parsePower()   // sin30, √9
        }

        private fun factorial(v: Double): Double {
            if (v < 0 || v != floor(v) || v > 170) throw ParseError("Invalid input")
            var r = 1.0
            for (i in 2..v.toInt()) r *= i
            return r
        }

        private fun applyFunc(name: String, x: Double): Double {
            fun toRad(v: Double) = if (useDeg) Math.toRadians(v) else v
            fun fromRad(v: Double) = if (useDeg) Math.toDegrees(v) else v
            return when (name) {
                "sin" -> sin(toRad(x))
                "cos" -> cos(toRad(x))
                "tan" -> {
                    val r = toRad(x)
                    if (abs(cos(r)) < 1e-12) throw ParseError("Can't calculate")
                    tan(r)
                }
                "asin" -> { if (x < -1 || x > 1) throw ParseError("Invalid input"); fromRad(asin(x)) }
                "acos" -> { if (x < -1 || x > 1) throw ParseError("Invalid input"); fromRad(acos(x)) }
                "atan" -> fromRad(atan(x))
                "ln" -> { if (x <= 0) throw ParseError("Invalid input"); ln(x) }
                "log" -> { if (x <= 0) throw ParseError("Invalid input"); log10(x) }
                "sqrt" -> { if (x < 0) throw ParseError("Invalid input"); sqrt(x) }
                else -> throw ParseError("Invalid input")
            }
        }
    }
}
