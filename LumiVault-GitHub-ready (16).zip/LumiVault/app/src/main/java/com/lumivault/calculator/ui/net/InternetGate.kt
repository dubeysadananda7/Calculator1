package com.lumivault.calculator.ui.net

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumivault.calculator.net.NetworkMonitor
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.components.AccentBrush
import com.lumivault.calculator.ui.components.Pal

/**
 * The calculator works offline, but the vault needs the internet (ads).
 * When the vault is unlocked and there is no working connection, this popup covers the screen.
 * It disappears by itself the moment the connection is back, whoever turned it on.
 */
@Composable
fun InternetGate() {
    val online by NetworkMonitor.online.collectAsStateWithLifecycle()
    val unlocked by SessionManager.unlocked
    val show = unlocked && !online
    val context = LocalContext.current

    fun backToCalculator() { SessionManager.lock() }

    BackHandler(enabled = show) { backToCalculator() }

    AnimatedVisibility(visible = show, enter = fadeIn(tween(220)), exit = fadeOut(tween(260))) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xEB070707))
                .pointerInput(Unit) { detectTapGestures { } }, // blocks touches on the vault underneath
            contentAlignment = Alignment.Center,
        ) {
            val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
                initialValue = 0.35f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
                label = "pulseAlpha",
            )
            val shape = RoundedCornerShape(32.dp)
            Column(
                modifier = Modifier
                    .padding(horizontal = 26.dp)
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
                    .border(1.dp, Brush.verticalGradient(listOf(Color(0x66FF8F3D), Color(0x14FFFFFF))), shape)
                    .padding(horizontal = 24.dp, vertical = 30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .size(96.dp)
                            .alpha(pulse * 0.35f)
                            .clip(CircleShape)
                            .background(Pal.Orange)
                    )
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(AccentBrush),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Filled.WifiOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("Internet required", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Please turn on your internet to continue. The vault can’t be used while you are offline.",
                    color = Pal.Muted, fontSize = 15.sp, textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(24.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(50))
                        .background(AccentBrush)
                        .clickable {
                            SessionManager.beginExternal()
                            // Quick panel with Wi‑Fi / mobile data switches; falls back to the full settings page.
                            runCatching { context.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
                                .onFailure {
                                    runCatching { context.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
                                }
                        }
                        .padding(vertical = 15.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("Turn on internet", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator(Modifier.size(14.dp), color = Pal.OrangeHi, strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Waiting for a connection…", color = Pal.Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Back to calculator",
                    color = Pal.Muted,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { backToCalculator() }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }
    }
}
