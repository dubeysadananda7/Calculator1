package com.lumivault.calculator.ui.photos

import android.app.Application
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import com.lumivault.calculator.ui.components.AccentFab
import com.lumivault.calculator.ui.components.CountChip
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import com.lumivault.calculator.ui.components.ThumbButton
import com.lumivault.calculator.ui.components.ToastBar
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import com.lumivault.calculator.R
import com.lumivault.calculator.ui.ads.AnchoredAdaptiveBanner
import com.lumivault.calculator.ui.ads.InlineAdaptiveBanner
import com.lumivault.calculator.ui.ads.rememberAdViewCache
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.data.repo.MediaCleaner
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.rememberMediaPermissionGate
import com.lumivault.calculator.ui.components.rememberOriginalsCleanup
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.navigation.Routes
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PhotosViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).vault

    val photos: StateFlow<List<VaultItemEntity>> = repo.photos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun import(uris: List<Uri>, onError: (String) -> Unit, onCleanup: (List<Uri>) -> Unit) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val originals = mutableListOf<Uri>()
            var imported = 0
            var removedOther = 0
            for (uri in uris) {
                val mediaUri = MediaCleaner.toMediaUri(context, uri, VaultItemType.PHOTO)
                val r = repo.import(uri, VaultItemType.PHOTO)
                if (r.isSuccess) {
                    imported++
                    if (mediaUri != null) originals.add(mediaUri)
                    else if (kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { MediaCleaner.deleteDocument(context, uri) }) removedOther++
                } else onError(r.exceptionOrNull()?.message ?: "Import failed")
            }
            if (imported > originals.size + removedOther) {
                onError("Hidden, but some originals could not be removed from the gallery. Allow photo access and try again.")
            }
            if (originals.isNotEmpty()) onCleanup(originals)
        }
    }

    fun restoreToGallery(item: VaultItemEntity, onResult: (String) -> Unit) = viewModelScope.launch {
        repo.exportToGallery(item)
            .onSuccess { onResult("Restored to gallery (Pictures/Restored)") }
            .onFailure { onResult(it.message ?: "Restore failed") }
    }

    suspend fun preview(item: VaultItemEntity): File? = runCatching { repo.decryptedFile(item) }.getOrNull()

    fun delete(item: VaultItemEntity) = viewModelScope.launch { repo.softDelete(item.id) }
}

@Composable
fun PhotosScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm: PhotosViewModel = viewModel(factory = remember(app) {
        androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
    })
    val photos by vm.photos.collectAsStateWithLifecycle()
    val adCache = rememberAdViewCache()

    // One inline ad after every 4 photos (only when more photos follow). 4 columns = exactly one row per ad.
    val entries = remember(photos) {
        buildList<PhotoGridEntry> {
            photos.forEachIndexed { i, p ->
                add(PhotoGridEntry.PhotoEntry(p))
                if ((i + 1) % 4 == 0 && i + 1 < photos.size) add(PhotoGridEntry.AdEntry((i + 1) / 4))
            }
        }
    }

    var error by remember { mutableStateOf<String?>(null) }
    val cleanup = rememberOriginalsCleanup()

    // Same picker as the File manager "+": it hands over the real gallery file, so the original can be removed.
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.import(uris, { error = it }, cleanup) }
    val launchPicker = rememberMediaPermissionGate { picker.launch(arrayOf("image/*")) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Pal.Bg),
    ) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(
                title = "Photos",
                onBack = { nav.popBackStack() },
                actions = { if (photos.isNotEmpty()) CountChip("${photos.size} ${if (photos.size == 1) "photo" else "photos"}") },
            )
            // Anchored banner: fixed under the title, it does not scroll with the photos.
            AnchoredAdaptiveBanner(R.string.admob_anchor_banner_photos_unit_id)
            if (photos.isEmpty()) {
                EmptyState(
                    icon = Icons.Default.BrokenImage,
                    title = "No private photos yet",
                    subtitle = "Tap + to import photos from your device",
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 120.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(
                        entries,
                        key = { e ->
                            when (e) {
                                is PhotoGridEntry.PhotoEntry -> e.item.id
                                is PhotoGridEntry.AdEntry -> "ad_${e.slot}"
                            }
                        },
                        span = { e -> GridItemSpan(if (e is PhotoGridEntry.AdEntry) maxLineSpan else 1) },
                    ) { e ->
                        when (e) {
                            is PhotoGridEntry.PhotoEntry -> PhotoCell(
                                item = e.item, vm = vm, onMessage = { error = it },
                                onClick = { nav.navigate(Routes.photoViewer(e.item.id)) },
                            )
                            is PhotoGridEntry.AdEntry -> InlineAdaptiveBanner(
                                unitIdRes = R.string.admob_inline_banner_photos_unit_id,
                                cache = adCache,
                                cacheKey = "photos_slot_${e.slot}",
                            )
                        }
                    }
                }
            }
        }
        AccentFab(
            icon = Icons.Default.Add,
            contentDescription = "Import",
            onClick = launchPicker,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(24.dp),
        )
        error?.let {
            ToastBar(
                it,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .navigationBarsPadding()
                    .padding(end = 100.dp, bottom = 8.dp),
            )
        }
    }

}

private sealed interface PhotoGridEntry {
    class PhotoEntry(val item: VaultItemEntity) : PhotoGridEntry
    class AdEntry(val slot: Int) : PhotoGridEntry
}

@Composable
private fun PhotoCell(
    item: VaultItemEntity,
    vm: PhotosViewModel,
    onMessage: (String) -> Unit,
    onClick: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    val preview by produceState<File?>(initialValue = null, item.id) {
        value = vm.preview(item)
    }
    val cellShape = RoundedCornerShape(14.dp)
    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .clip(cellShape)
            .background(Pal.Card)
            .border(1.dp, Pal.Border, cellShape)
            .clickable(onClick = onClick),
    ) {
        preview?.let {
            AsyncImage(
                model = it,
                contentDescription = item.displayName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Box(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
            ThumbButton(Icons.Default.MoreVert, "Options", onClick = { menu = true }, size = 26.dp)
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Restore to gallery") },
                    onClick = { menu = false; confirmRestore = true },
                )
                DropdownMenuItem(
                    text = { Text("Delete") },
                    onClick = { menu = false; confirmDelete = true },
                )
            }
        }
    }
    if (confirmRestore) {
        ConfirmDialog(
            title = "Restore to gallery?",
            text = "\"${item.displayName}\" will be moved back to your phone gallery and removed from the vault.",
            confirmLabel = "Restore",
            onConfirm = { vm.restoreToGallery(item, onMessage); confirmRestore = false },
            onDismiss = { confirmRestore = false },
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "\"${item.displayName}\" will be moved to the recycle bin.",
            confirmLabel = "Move",
            onConfirm = { vm.delete(item); confirmDelete = false },
            onDismiss = { confirmDelete = false },
        )
    }
}
