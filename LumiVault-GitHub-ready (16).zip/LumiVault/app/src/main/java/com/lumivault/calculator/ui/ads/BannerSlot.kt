package com.lumivault.calculator.ui.ads

import android.content.Context
import android.util.Log
import android.view.ViewGroup
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.lumivault.calculator.net.NetworkMonitor
import com.lumivault.calculator.ui.components.Pal
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val TAG = "BannerSlot"
private const val MAX_RETRIES = 2
private const val RETRY_DELAY_MS = 15_000L

/** One banner ad: queues its request through [AdThrottle] and retries a couple of times if no ad was returned. */
class BannerHolder(context: Context, unitId: String, adSize: AdSize) {
    val view = AdView(context)
    var loaded by mutableStateOf(false)
        private set
    var failed by mutableStateOf(false)
        private set

    private var attempts = 0
    private var started = false
    private var destroyed = false

    init {
        view.setAdSize(adSize)
        view.adUnitId = unitId
        view.adListener = object : AdListener() {
            override fun onAdLoaded() {
                loaded = true
                failed = false
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                Log.w(TAG, "Banner failed: ${error.code} ${error.message}")
                attempts++
                if (attempts <= MAX_RETRIES) {
                    AdThrottle.scope.launch {
                        delay(RETRY_DELAY_MS * attempts)
                        request()
                    }
                } else {
                    failed = true
                }
            }
        }
    }

    fun start() {
        if (started) return
        started = true
        request()
    }

    private fun request() {
        AdThrottle.scope.launch {
            AdThrottle.acquire()
            if (!destroyed) view.loadAd(AdRequest.Builder().build())
        }
    }

    fun destroy() {
        destroyed = true
        view.destroy()
    }
}

/** Keeps banner views alive while a screen is open, so ads that scroll out and back in are not requested again. */
class AdViewCache {
    private val map = HashMap<String, BannerHolder>()
    fun getOrCreate(key: String, create: () -> BannerHolder): BannerHolder = map.getOrPut(key, create)
    fun destroyAll() {
        map.values.forEach { it.destroy() }
        map.clear()
    }
}

@Composable
fun rememberAdViewCache(): AdViewCache {
    val cache = remember { AdViewCache() }
    DisposableEffect(cache) { onDispose { cache.destroyAll() } }
    return cache
}

/**
 * Shows a banner once it has loaded (zero height until then, and nothing at all if it never loads).
 * [cardStyle] draws the dark rounded card used for inline ads.
 */
@Composable
fun BannerSlot(
    @StringRes unitIdRes: Int,
    adSize: AdSize,
    modifier: Modifier = Modifier,
    cache: AdViewCache? = null,
    cacheKey: String? = null,
    cardStyle: Boolean = false,
) {
    val context = LocalContext.current
    val online by NetworkMonitor.online.collectAsStateWithLifecycle()

    val holder = remember(unitIdRes, adSize, online, cacheKey) {
        val create = { BannerHolder(context, context.getString(unitIdRes), adSize) }
        if (cache != null && cacheKey != null) {
            cache.getOrCreate("$cacheKey|${adSize.width}x${adSize.height}|$online", create)
        } else {
            create()
        }
    }
    DisposableEffect(holder) {
        onDispose { if (cache == null) holder.destroy() }
    }
    LaunchedEffect(holder, online) { if (online) holder.start() }

    if (holder.failed) return

    var m = modifier.fillMaxWidth()
    if (!holder.loaded) {
        m = m.height(0.dp)
    } else if (cardStyle) {
        m = m.background(Pal.Card, RoundedCornerShape(18.dp)).padding(vertical = 6.dp)
    }
    AndroidView(
        factory = {
            (holder.view.parent as? ViewGroup)?.removeView(holder.view)
            holder.view
        },
        modifier = m,
    )
}
