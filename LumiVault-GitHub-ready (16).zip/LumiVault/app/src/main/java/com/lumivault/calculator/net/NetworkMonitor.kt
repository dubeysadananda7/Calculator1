package com.lumivault.calculator.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Live "is the internet really working" state (connected AND validated by Android). */
object NetworkMonitor {
    private val _online = MutableStateFlow(true)
    val online: StateFlow<Boolean> = _online

    private fun hasInternet(caps: NetworkCapabilities?): Boolean =
        caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

    fun init(context: Context) {
        val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return
        _online.value = hasInternet(cm.activeNetwork?.let { cm.getNetworkCapabilities(it) })
        runCatching {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    _online.value = hasInternet(caps)
                }

                override fun onLost(network: Network) {
                    _online.value = false
                }
            })
        }
    }
}
