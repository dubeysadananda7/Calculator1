package com.lumivault.calculator.ui.calculator

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.UnfoldLess
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import kotlinx.coroutines.launch

/** All the colors/brushes for one calculator theme (Light or Dark). */
private class CalcPalette(
    val pageBg: Brush,
    val displayText: Color,
    val previewText: Color,
    val errorText: Color,
    val digitBg: Brush,
    val digitText: Color,
    val keyBorder: Color?,
    val opBg: Brush,
    val opText: Color,
    val fnBg: Brush,
    val fnText: Color,
    val acBg: Brush,
    val acText: Color,
    val activeBg: Brush,
    val activeText: Color,
    val equalsBg: Brush,
    val equalsText: Color,
    val glowColor: Color,
    val iconMuted: Color,
    val historyMuted: Color,
)

private fun darkPalette() = CalcPalette(
    pageBg = Brush.verticalGradient(listOf(Color(0xFF0C0C0E), Color(0xFF040404))),
    displayText = Color.White,
    previewText = Color(0xFFABABB4),
    errorText = Color(0xFFFF8A80),
    digitBg = Brush.verticalGradient(listOf(Color(0xFF32333E), Color(0xFF1D1E26))),
    digitText = Color.White,
    keyBorder = null,
    opBg = Brush.verticalGradient(listOf(Color(0xFFFFB15C), Color(0xFFFF7A1F))),
    opText = Color.White,
    fnBg = Brush.verticalGradient(listOf(Color(0xFF3C404C), Color(0xFF262A34))),
    fnText = Color.White,
    acBg = Brush.verticalGradient(listOf(Color(0xFF4A2024), Color(0xFF301015))),
    acText = Color(0xFFFF7A7A),
    activeBg = Brush.verticalGradient(listOf(Color(0xFF5A3514), Color(0xFF3A200A))),
    activeText = Color(0xFFFFB15C),
    equalsBg = Brush.verticalGradient(listOf(Color(0xFFFF9248), Color(0xFFFF3D7A))),
    equalsText = Color.White,
    glowColor = Color(0xFFFF6A3D),
    iconMuted = Color(0xFF9E9E9E),
    historyMuted = Color(0xFF8A8A8A),
)

private fun lightPalette() = CalcPalette(
    pageBg = Brush.verticalGradient(listOf(Color(0xFFFFFDF8), Color(0xFFF3EEE4))),
    displayText = Color(0xFF2B2A28),
    previewText = Color(0xFF8D877B),
    errorText = Color(0xFFD1453D),
    digitBg = Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFF1EDE3))),
    digitText = Color(0xFF2B2A28),
    keyBorder = Color(0x14000000),
    opBg = Brush.verticalGradient(listOf(Color(0xFFFFCA8A), Color(0xFFFF9A3D))),
    opText = Color.White,
    fnBg = Brush.verticalGradient(listOf(Color(0xFFEFEAE0), Color(0xFFE2DBCC))),
    fnText = Color(0xFF2B2A28),
    acBg = Brush.verticalGradient(listOf(Color(0xFFFBE1DE), Color(0xFFF5CBC6))),
    acText = Color(0xFFCB3B33),
    activeBg = Brush.verticalGradient(listOf(Color(0xFFFFE3BA), Color(0xFFFFC988))),
    activeText = Color(0xFF9A4B00),
    equalsBg = Brush.verticalGradient(listOf(Color(0xFFFF9A62), Color(0xFFFF4D7D))),
    equalsText = Color.White,
    glowColor = Color(0xFFFF8A5A),
    iconMuted = Color(0xFF8D877B),
    historyMuted = Color(0xFF9A948A),
)

@Composable
fun CalculatorScreen(app: LumiVaultApp, onUnlock: () -> Unit) {
    val vm: CalculatorViewModel = viewModel(
        factory = remember(app) {
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
        }
    )

    LaunchedEffect(Unit) {
        vm.unlockEvent.collect { onUnlock() }
    }

    // Wrong secret code: silent front-camera photo, stored encrypted inside the vault.
    val appContext = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = remember(appContext) {
        var c: android.content.Context = appContext
        var owner: androidx.lifecycle.LifecycleOwner? = null
        while (owner == null) {
            if (c is androidx.lifecycle.LifecycleOwner) owner = c
            else if (c is android.content.ContextWrapper) c = c.baseContext
            else break
        }
        owner
    }
    LaunchedEffect(Unit) {
        vm.wrongPin.collect {
            val owner = lifecycleOwner
            if (owner != null) {
                com.lumivault.calculator.security.IntruderCapture.captureAndRecord(appContext, owner, app.security)
            } else {
                app.security.recordPinFail()
            }
        }
    }

    // ---- Theme: Light / Dark, shared with the rest of the vault (Settings -> Theme) ----
    val scope = rememberCoroutineScope()
    val settingsState by app.settings.settings.collectAsState(initial = VaultSettings())
    val systemDark = isSystemInDarkTheme()
    val isDark = when (settingsState.theme) {
        "LIGHT" -> false
        "DARK" -> true
        else -> systemDark
    }
    val pal = remember(isDark) { if (isDark) darkPalette() else lightPalette() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(pal.pageBg)
            .systemBarsPadding(),
    ) {
        // ---- Display ----
        var showHistory by remember { mutableStateOf(false) }
        var sciOpen by rememberSaveable { mutableStateOf(false) }
        BackHandler(enabled = showHistory) { showHistory = false }
        val shown = vm.expression.replace("x", "×").replace("/", "÷")
        val shownSize = when {
            shown.length <= 7 -> 68.sp
            shown.length <= 11 -> 52.sp
            else -> 38.sp
        }
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            if (showHistory) {
                HistoryPanel(
                    entries = vm.history,
                    pal = pal,
                    onUse = { vm.useHistory(it); showHistory = false },
                    onClear = { vm.clearHistory() },
                    onClose = { showHistory = false },
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    if (shown.isNotEmpty()) {
                        Text(
                            shown,
                            fontSize = shownSize,
                            fontWeight = FontWeight.Light,
                            color = pal.displayText,
                            textAlign = TextAlign.End,
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    // Error, or the live answer while typing (no need to press "=").
                    val secondary = when {
                        vm.error != null -> vm.error!!
                        vm.preview.isNotEmpty() -> "= " + vm.preview
                        else -> ""
                    }
                    if (secondary.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            secondary,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Light,
                            color = if (vm.error != null) pal.errorText else pal.previewText,
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Row(
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = {
                        scope.launch { app.settings.setTheme(if (isDark) "LIGHT" else "DARK") }
                    }) {
                        Icon(
                            if (isDark) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = if (isDark) "Switch to light theme" else "Switch to dark theme",
                            tint = pal.iconMuted,
                        )
                    }
                    IconButton(onClick = { showHistory = true }) {
                        Icon(Icons.Filled.History, contentDescription = "History", tint = pal.iconMuted)
                    }
                }
            }
        }

        // ---- Scientific panel switch (the two little arrows) ----
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { sciOpen = !sciOpen }) {
                Icon(
                    if (sciOpen) Icons.Filled.UnfoldLess else Icons.Filled.UnfoldMore,
                    contentDescription = if (sciOpen) "Hide scientific keys" else "Show scientific keys",
                    tint = pal.iconMuted,
                )
            }
        }

        // ---- Keypad ----
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 20.dp),
        ) {
            val gap = 12.dp
            val size: Dp = (maxWidth - gap * 3) / 4
            // Opening the scientific panel makes every key a flatter pill, so everything still fits.
            val keyH by animateDpAsState(if (sciOpen) size * 0.62f else size, label = "keyHeight")
            val rowGap by animateDpAsState(if (sciOpen) 8.dp else gap, label = "rowGap")
            val inv = vm.inverse

            Column {
                // Reshuffled from the usual layout: mode keys first, trig together, logs + root, constants last.
                AnimatedVisibility(
                    visible = sciOpen,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut(),
                ) {
                    Column(
                        modifier = Modifier.padding(bottom = rowGap),
                        verticalArrangement = Arrangement.spacedBy(rowGap),
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            Key(
                                if (vm.degrees) "Deg" else "Rad", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.toggleDegrees() }
                            Key(
                                "Inv", width = size, height = keyH,
                                bg = if (inv) pal.activeBg else pal.fnBg,
                                textColor = if (inv) pal.activeText else pal.fnText,
                            ) { vm.toggleInverse() }
                            Key(
                                if (inv) "sin⁻¹" else "sin", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.onFunction("sin") }
                            Key(
                                if (inv) "cos⁻¹" else "cos", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.onFunction("cos") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            Key(
                                if (inv) "tan⁻¹" else "tan", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.onFunction("tan") }
                            Key(
                                if (inv) "eˣ" else "ln", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.onFunction("ln") }
                            Key(
                                if (inv) "10ˣ" else "log", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.onFunction("log") }
                            Key(
                                if (inv) "x²" else "√", width = size, height = keyH,
                                bg = pal.fnBg, textColor = pal.fnText,
                            ) { vm.onFunction("sqrt") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            Key("π", width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText) { vm.onConstant("π") }
                            Key("e", width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText) { vm.onConstant("e") }
                            Key("^", width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText) { vm.onPower() }
                            Key("!", width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText) { vm.onFactorial() }
                        }
                    }
                }
                // Main pad mirrored from the common layout: the function column sits on the left,
                // digits fill the right three columns, and the operators share one row of their own.
                Column(verticalArrangement = Arrangement.spacedBy(rowGap)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("AC", width = size, height = keyH, bg = pal.acBg, textColor = pal.acText) { vm.onClear() }
                        Key("7", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("7") }
                        Key("8", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("8") }
                        Key("9", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("9") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("( )", width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText) { vm.onParen() }
                        Key("4", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("4") }
                        Key("5", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("5") }
                        Key("6", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("6") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("%", width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText) { vm.onPercent() }
                        Key("1", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("1") }
                        Key("2", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("2") }
                        Key("3", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("3") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("÷", width = size, height = keyH, bg = pal.opBg, textColor = pal.opText) { vm.onOperator("/") }
                        Key("×", width = size, height = keyH, bg = pal.opBg, textColor = pal.opText) { vm.onOperator("x") }
                        Key("−", width = size, height = keyH, bg = pal.opBg, textColor = pal.opText) { vm.onOperator("-") }
                        Key("+", width = size, height = keyH, bg = pal.opBg, textColor = pal.opText) { vm.onOperator("+") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key(
                            icon = Icons.Outlined.Backspace, iconTint = pal.glowColor,
                            width = size, height = keyH, bg = pal.fnBg, textColor = pal.fnText,
                        ) { vm.onDelete() }
                        Key("0", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit("0") }
                        Key(".", width = size, height = keyH, bg = pal.digitBg, textColor = pal.digitText, border = pal.keyBorder) { vm.onDigit(".") }
                        Key(
                            "=", width = size, height = keyH, bg = pal.equalsBg, textColor = pal.equalsText,
                            glow = pal.glowColor,
                        ) { vm.onEquals() }
                    }
                }
            }
        }
    }
}

@Composable
private fun Key(
    label: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = Color.White,
    width: Dp,
    height: Dp,
    bg: Brush,
    textColor: Color,
    border: Color? = null,
    glow: Color? = null,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(width = width, height = height)
            .let { if (glow != null) it.shadow(10.dp, CircleShape, ambientColor = glow, spotColor = glow) else it }
            .clip(CircleShape)
            .background(bg)
            .let { if (border != null) it.border(1.dp, border, CircleShape) else it }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        // A soft highlight across the top gives every key a glossy, premium feel.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.10f),
                        0.5f to Color.Transparent,
                    )
                )
        )
        if (icon != null) {
            Icon(icon, contentDescription = "Delete", tint = iconTint, modifier = Modifier.size(height * 0.32f))
        } else {
            val text = label.orEmpty()
            val factor = when {
                text.length >= 4 -> 0.30f
                text.length >= 2 -> 0.38f
                else -> 0.47f
            }
            Text(
                text,
                fontSize = (height.value * factor).sp,
                fontWeight = FontWeight.Light,
                color = textColor,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun HistoryPanel(
    entries: List<HistoryEntry>,
    pal: CalcPalette,
    onUse: (HistoryEntry) -> Unit,
    onClear: () -> Unit,
    onClose: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("History", color = pal.iconMuted, fontSize = 18.sp, modifier = Modifier.weight(1f))
            if (entries.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Clear history", tint = pal.iconMuted)
                }
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Close", tint = pal.displayText)
            }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No calculations yet", color = pal.historyMuted, fontSize = 16.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(entries) { e ->
                    Column(
                        modifier = Modifier.fillMaxWidth().clickable { onUse(e) },
                        horizontalAlignment = Alignment.End,
                    ) {
                        Text(
                            e.expression.replace("x", "×").replace("/", "÷"),
                            color = pal.historyMuted,
                            fontSize = 18.sp,
                        )
                        Text("= " + e.result, color = pal.displayText, fontSize = 30.sp, fontWeight = FontWeight.Light)
                    }
                }
            }
        }
    }
}
