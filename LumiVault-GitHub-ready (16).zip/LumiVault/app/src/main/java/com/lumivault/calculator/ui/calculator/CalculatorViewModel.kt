package com.lumivault.calculator.ui.calculator

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import com.lumivault.calculator.security.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class CalculatorViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = (app as LumiVaultApp).settings
    private val security = (app as LumiVaultApp).security

    var expression by mutableStateOf("")
        private set
    var result by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private val _unlockEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val unlockEvent: SharedFlow<Unit> = _unlockEvent

    var settingsSnapshot by mutableStateOf<VaultSettings?>(null)
        private set

    /** Trigonometry in degrees (true) or radians (false). */
    var degrees by mutableStateOf(true)
        private set

    /** "Inv" key: sin/cos/tan become their inverses, ln -> e^x, log -> 10^x, root -> x squared. */
    var inverse by mutableStateOf(false)
        private set

    private var lastIntruderShot = 0L
    private val _wrongPin = kotlinx.coroutines.flow.MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val wrongPin: kotlinx.coroutines.flow.SharedFlow<Unit> = _wrongPin

    var history by mutableStateOf<List<HistoryEntry>>(emptyList())
        private set

    /** Live answer shown under the expression while typing (empty when there is nothing to calculate yet). */
    val preview: String by derivedStateOf { previewOf(expression) }

    init {
        viewModelScope.launch { settingsSnapshot = settings.settings.first() }
        viewModelScope.launch {
            history = withContext(Dispatchers.IO) { CalculatorHistory.load(app) }
        }
    }

    private fun hasOperator(e: String): Boolean {
        val t = e.trim()
        val body = if (t.startsWith("-")) t.drop(1) else t
        return body.any { it in "+-x/%()^!π√" || it.isLetter() }
    }

    private fun previewOf(e: String): String {
        var t = e.trim()
        if (t.isEmpty()) return ""
        while (t.isNotEmpty() && t.last() in "+-x/^(.") t = t.dropLast(1)
        if (t.isEmpty() || !hasOperator(t)) return ""
        return try { CalculatorEngine.evaluate(t, degrees) } catch (_: Throwable) { "" }
    }

    private fun addHistory(expr: String, value: String) {
        if (history.firstOrNull()?.let { it.expression == expr && it.result == value } == true) return
        val updated = (listOf(HistoryEntry(expr, value, System.currentTimeMillis())) + history).take(CalculatorHistory.MAX)
        history = updated
        viewModelScope.launch(Dispatchers.IO) { CalculatorHistory.save(getApplication<Application>(), updated) }
    }

    fun useHistory(entry: HistoryEntry) {
        error = null
        expression = entry.result
        result = ""
    }

    fun clearHistory() {
        history = emptyList()
        viewModelScope.launch(Dispatchers.IO) { CalculatorHistory.save(getApplication<Application>(), emptyList()) }
    }

    fun onDigit(d: String) {
        error = null
        val last = expression.lastOrNull()
        if (expression == "0" && d != ".") expression = d
        else if (last?.isDigit() != true && last != '.' && d == "." && last != null) {
            expression += "0."
        } else if (!(last == '.' && d == ".")) {
            expression += d
        }
    }

    fun onOperator(op: String) {
        error = null
        if (expression.isEmpty()) {
            if (op == "-") expression = "-"
            return
        }
        val last = expression.last()
        when {
            // right after "(" only a minus sign makes sense (a negative number)
            last == '(' -> if (op == "-") expression += op
            last in "+-x/^" -> {
                val head = expression.dropLast(1)
                expression = if (head.isEmpty() || head.last() == '(') {
                    if (op == "-") head + op else head
                } else {
                    head + op
                }
            }
            last != '.' -> expression += op
        }
    }

    // ------------------------------------------------------------- scientific keys

    fun toggleDegrees() { degrees = !degrees }

    fun toggleInverse() { inverse = !inverse }

    private fun endsWithValue(): Boolean {
        val last = expression.lastOrNull() ?: return false
        return last.isDigit() || last == ')' || last == '%' || last == '!' || last == 'π' || last == 'e'
    }

    /** sin, cos, tan, ln, log, sqrt (the Inv key switches them to the inverse versions). */
    fun onFunction(base: String) {
        error = null
        if (expression.lastOrNull() == '.') return
        if (inverse && base == "sqrt") {            // x squared
            if (endsWithValue()) expression += "^2"
            inverse = false
            return
        }
        var text = when {
            inverse && base == "sin" -> "sin⁻¹("
            inverse && base == "cos" -> "cos⁻¹("
            inverse && base == "tan" -> "tan⁻¹("
            inverse && base == "ln" -> "e^("
            inverse && base == "log" -> "10^("
            base == "sqrt" -> "√("
            else -> "$base("
        }
        // a number followed by 10^( would glue the digits together, so multiply explicitly
        if (text.startsWith("10") && expression.lastOrNull()?.isDigit() == true) text = "x$text"
        expression += text
        inverse = false
    }

    fun onConstant(symbol: String) {
        error = null
        if (expression.lastOrNull() == '.') return
        expression += symbol
    }

    fun onPower() {
        error = null
        if (endsWithValue()) expression += "^"
    }

    fun onFactorial() {
        error = null
        val last = expression.lastOrNull() ?: return
        if (last.isDigit() || last == ')') expression += "!"
    }

    /** Smart "( )" key: opens a bracket where one belongs, otherwise closes the last open one. */
    fun onParen() {
        error = null
        val e = expression
        val open = e.count { it == '(' }
        val close = e.count { it == ')' }
        val last = e.lastOrNull()
        expression = when {
            last == null || last in "+-x/(" -> e + "("
            last == '.' -> e
            open > close -> e + ")"
            else -> e + "x("   // nothing open: start a new group, e.g. 5 -> 5x(
        }
    }

    fun onPercent() {
        if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() == ')')) expression += "%"
    }

    fun onClear() {
        expression = ""
        result = ""
        error = null
    }

    private val functionStarts = listOf("sin⁻¹(", "cos⁻¹(", "tan⁻¹(", "sin(", "cos(", "tan(", "log(", "ln(", "√(")

    fun onDelete() {
        functionStarts.firstOrNull { expression.endsWith(it) }?.let {
            expression = expression.dropLast(it.length)
            error = null
            return
        }
        if (expression.isNotEmpty()) expression = expression.dropLast(1)
    }

    fun onEquals() {
        if (expression.isBlank()) return
        try {
            val expr = expression
            val value = CalculatorEngine.evaluate(expr, degrees)
            result = value
            // Only real calculations are saved. A plain number (like a PIN) never goes into the history.
            if (hasOperator(expr)) addHistory(expr.trim(), value)
            checkSecretCode(expr.trim())
            expression = value
        } catch (t: Throwable) {
            error = t.message ?: "Error"
        }
    }

    /** The vault opens when the entered expression exactly matches the secret PIN. */
    private fun checkSecretCode(candidate: String) {
        val s = settingsSnapshot ?: return
        if (!s.pinSet) return
        // Only PIN-shaped input is checked; normal sums skip the (slow) PIN hashing completely.
        if (candidate.length !in 4..12 || !candidate.all { it.isDigit() }) return
        viewModelScope.launch {
            // PBKDF2 is deliberately slow, so it must never run on the main thread.
            val ok = withContext(Dispatchers.Default) { settings.verifyPin(candidate, s) }
            if (ok) {
                SessionManager.unlock()
                security.recordUnlock()
                _unlockEvent.emit(Unit)
            } else {
                val now = System.currentTimeMillis()
                if (s.intruderEnabled && now - lastIntruderShot > 8_000L) {
                    // The screen owns the camera (needs a lifecycle); it also records the event.
                    lastIntruderShot = now
                    _wrongPin.emit(Unit)
                } else {
                    security.recordPinFail()
                }
            }
        }
    }
}
