package com.lumivault.calculator.ui.ads

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Ad requests are queued and sent one at a time with a gap between them, so many ads on one screen
 * never fire a burst of requests at once (a burst gets "no fill" / rate limited by the ad server).
 */
object AdThrottle {
    /** Lives as long as the process, so a request queued by an ad that scrolled away still completes. */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private const val GAP_MS = 1_500L
    private val mutex = Mutex()
    private var lastAt = 0L

    suspend fun acquire() {
        mutex.withLock {
            val wait = lastAt + GAP_MS - SystemClock.elapsedRealtime()
            if (wait > 0) delay(wait)
            lastAt = SystemClock.elapsedRealtime()
        }
    }
}
