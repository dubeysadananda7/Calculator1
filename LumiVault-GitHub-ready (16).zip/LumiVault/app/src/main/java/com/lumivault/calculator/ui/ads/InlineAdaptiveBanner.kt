package com.lumivault.calculator.ui.ads

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.google.android.gms.ads.AdSize

/**
 * Inline adaptive banner: sits inside scrolling content, takes the full width of its container and picks its
 * own height (never taller than [maxHeightDp]). Pass a [cache] + [cacheKey] when it lives in a lazy list so the
 * ad is not requested again each time it scrolls back into view.
 * Ad unit ids come from res/values/ads.xml (currently Google's test id).
 */
@Composable
fun InlineAdaptiveBanner(
    @StringRes unitIdRes: Int,
    modifier: Modifier = Modifier,
    maxHeightDp: Int = 120,
    cache: AdViewCache? = null,
    cacheKey: String? = null,
) {
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val widthDp = maxWidth.value.toInt()
        BannerSlot(
            unitIdRes = unitIdRes,
            adSize = AdSize.getInlineAdaptiveBannerAdSize(widthDp, maxHeightDp),
            cache = cache,
            cacheKey = cacheKey,
            cardStyle = true,
        )
    }
}

/** Anchored adaptive banner: a full-width banner fixed at the edge of the screen (it does not scroll away). */
@Composable
fun AnchoredAdaptiveBanner(@StringRes unitIdRes: Int, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val widthDp = maxWidth.value.toInt()
        BannerSlot(
            unitIdRes = unitIdRes,
            adSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, widthDp),
            cardStyle = false,
        )
    }
}
