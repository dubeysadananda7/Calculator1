package com.lumivault.calculator.ui.calculator

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import com.lumivault.calculator.security.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class CalculatorViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = (app as LumiVaultApp).settings
    private val security = (app as LumiVaultApp).security

    var expression by mutableStateOf("")
        private set
    var result by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private val _unlockEvent = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val unlockEvent: SharedFlow<Unit> = _unlockEvent

    var settingsSnapshot by mutableStateOf<VaultSettings?>(null)
        private set

    private var lastIntruderShot = 0L
    private val _wrongPin = kotlinx.coroutines.flow.MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val wrongPin: kotlinx.coroutines.flow.SharedFlow<Unit> = _wrongPin

    var history by mutableStateOf<List<HistoryEntry>>(emptyList())
        private set

    /** Live answer shown under the expression while typing (empty when there is nothing to calculate yet). */
    val preview: String by derivedStateOf { previewOf(expression) }

    init {
        viewModelScope.launch { settingsSnapshot = settings.settings.first() }
        viewModelScope.launch {
            history = withContext(Dispatchers.IO) { CalculatorHistory.load(app) }
        }
    }

    private fun hasOperator(e: String): Boolean {
        val t = e.trim()
        val body = if (t.startsWith("-")) t.drop(1) else t
        return body.any { it in "+-x/%" }
    }

    private fun previewOf(e: String): String {
        var t = e.trim()
        if (t.isEmpty()) return ""
        while (t.isNotEmpty() && t.last() in "+-x/(.") t = t.dropLast(1)
        if (t.isEmpty() || !hasOperator(t)) return ""
        return try { CalculatorEngine.evaluate(t) } catch (_: Throwable) { "" }
    }

    private fun addHistory(expr: String, value: String) {
        if (history.firstOrNull()?.let { it.expression == expr && it.result == value } == true) return
        val updated = (listOf(HistoryEntry(expr, value, System.currentTimeMillis())) + history).take(CalculatorHistory.MAX)
        history = updated
        viewModelScope.launch(Dispatchers.IO) { CalculatorHistory.save(getApplication<Application>(), updated) }
    }

    fun useHistory(entry: HistoryEntry) {
        error = null
        expression = entry.result
        result = ""
    }

    fun clearHistory() {
        history = emptyList()
        viewModelScope.launch(Dispatchers.IO) { CalculatorHistory.save(getApplication<Application>(), emptyList()) }
    }

    fun onDigit(d: String) {
        error = null
        val last = expression.lastOrNull()
        if (expression == "0" && d != ".") expression = d
        else if (last?.isDigit() != true && last != '.' && d == "." && last != null) {
            expression += "0."
        } else if (!(last == '.' && d == ".")) {
            expression += d
        }
    }

    fun onOperator(op: String) {
        error = null
        if (expression.isEmpty()) {
            if (op == "-") expression = "-"
            return
        }
        val last = expression.last()
        if (last in "+-x/(") {
            expression = expression.dropLast(1) + op
        } else if (last != '.') {
            expression += op
        }
    }

    fun onPercent() {
        if (expression.isNotEmpty() && expression.last().isDigit()) expression += "%"
    }

    fun onClear() {
        expression = ""
        result = ""
        error = null
    }

    fun onDelete() {
        if (expression.isNotEmpty()) expression = expression.dropLast(1)
    }

    fun onEquals() {
        if (expression.isBlank()) return
        try {
            val expr = expression
            val value = CalculatorEngine.evaluate(expr)
            result = value
            // Only real calculations are saved. A plain number (like a PIN) never goes into the history.
            if (hasOperator(expr)) addHistory(expr.trim(), value)
            checkSecretCode(expr.trim())
            expression = value
        } catch (t: Throwable) {
            error = t.message ?: "Error"
        }
    }

    /** The vault opens when the entered expression exactly matches the secret PIN. */
    private fun checkSecretCode(candidate: String) {
        val s = settingsSnapshot ?: return
        if (!s.pinSet) return
        // Only PIN-shaped input is checked; normal sums skip the (slow) PIN hashing completely.
        if (candidate.length !in 4..12 || !candidate.all { it.isDigit() }) return
        viewModelScope.launch {
            // PBKDF2 is deliberately slow, so it must never run on the main thread.
            val ok = withContext(Dispatchers.Default) { settings.verifyPin(candidate, s) }
            if (ok) {
                SessionManager.unlock()
                security.recordUnlock()
                _unlockEvent.emit(Unit)
            } else {
                val now = System.currentTimeMillis()
                if (s.intruderEnabled && now - lastIntruderShot > 8_000L) {
                    // The screen owns the camera (needs a lifecycle); it also records the event.
                    lastIntruderShot = now
                    _wrongPin.emit(Unit)
                } else {
                    security.recordPinFail()
                }
            }
        }
    }
}
