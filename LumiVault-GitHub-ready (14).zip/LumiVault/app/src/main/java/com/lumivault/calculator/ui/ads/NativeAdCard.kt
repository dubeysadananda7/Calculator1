package com.lumivault.calculator.ui.ads

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.lumivault.calculator.R

private const val TAG = "NativeAdCard"

/**
 * One AdMob native ad (with video support). Nothing is drawn until an ad has loaded,
 * so the space stays empty when the phone is offline or no ad is available.
 * The ad unit id comes from res/values/ads.xml (currently Google's test id).
 */
@Composable
fun NativeAdCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(Unit) {
        val loader = AdLoader.Builder(context, context.getString(R.string.admob_native_unit_id))
            .forNativeAd { ad ->
                nativeAd?.destroy()
                nativeAd = ad
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Native ad failed: ${error.code} ${error.message}")
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setVideoOptions(VideoOptions.Builder().setStartMuted(true).build())
                    .build()
            )
            .build()
        loader.loadAd(AdRequest.Builder().build())
        onDispose {
            nativeAd?.destroy()
            nativeAd = null
        }
    }

    nativeAd?.let { ad ->
        AndroidView(
            factory = { ctx ->
                LayoutInflater.from(ctx).inflate(R.layout.native_ad_view, null) as NativeAdView
            },
            update = { view -> bind(ad, view) },
            modifier = modifier.fillMaxWidth(),
        )
    }
}

private fun bind(ad: NativeAd, view: NativeAdView) {
    val media = view.findViewById<MediaView>(R.id.ad_media)
    val headline = view.findViewById<TextView>(R.id.ad_headline)
    val body = view.findViewById<TextView>(R.id.ad_body)
    val cta = view.findViewById<TextView>(R.id.ad_cta)
    val advertiser = view.findViewById<TextView>(R.id.ad_advertiser)

    view.mediaView = media
    view.headlineView = headline
    view.bodyView = body
    view.callToActionView = cta
    view.advertiserView = advertiser

    ad.mediaContent?.let { media.setMediaContent(it) }
    media.setImageScaleType(ImageView.ScaleType.CENTER_CROP)

    headline.text = ad.headline
    body.text = ad.body
    body.visibility = if (ad.body.isNullOrEmpty()) View.GONE else View.VISIBLE
    cta.text = ad.callToAction
    cta.visibility = if (ad.callToAction.isNullOrEmpty()) View.GONE else View.VISIBLE
    advertiser.text = ad.advertiser
    advertiser.visibility = if (ad.advertiser.isNullOrEmpty()) View.GONE else View.VISIBLE

    view.setNativeAd(ad)
}
