package com.lumivault.calculator

import android.app.Application
import com.lumivault.calculator.data.db.VaultDatabase
import com.lumivault.calculator.data.repo.NotesRepository
import com.lumivault.calculator.data.repo.SecurityRepository
import com.lumivault.calculator.data.repo.SettingsRepository
import com.lumivault.calculator.data.repo.VaultRepository
import com.lumivault.calculator.security.SessionManager

class LumiVaultApp : Application() {

    lateinit var settings: SettingsRepository
        private set
    lateinit var vault: VaultRepository
        private set
    lateinit var notes: NotesRepository
        private set
    lateinit var security: SecurityRepository
    lateinit var contacts: com.lumivault.calculator.data.repo.ContactsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = VaultDatabase.get(this)
        settings = SettingsRepository(this)
        vault = VaultRepository(this, db.vaultItemDao())
        notes = NotesRepository(db.noteDao())
        security = SecurityRepository(this, db.securityEventDao())
        contacts = com.lumivault.calculator.data.repo.ContactsRepository(this)

        // Decrypted previews must not outlive an unlocked session: wipe them at start and on every lock.
        SessionManager.onLock = { Thread { vault.clearPreviewCache() }.start() }
        Thread { vault.clearPreviewCache(); vault.clearCaptureCache() }.start()

        // Google Mobile Ads (test ids for now, see res/values/ads.xml)
        Thread { com.google.android.gms.ads.MobileAds.initialize(this) {} }.start()
    }
}
