package com.lumivault.calculator.ui.ads

import android.util.Log
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.lumivault.calculator.ui.components.Pal

private const val TAG = "InlineAdaptiveBanner"

/**
 * AdMob inline adaptive banner: it sits inside scrolling content, takes the full width of its
 * container and picks its own height (never taller than [maxHeightDp]).
 * Until an ad is loaded nothing is shown, and if loading fails the space collapses completely.
 * The ad unit id comes from res/values/ads.xml (currently Google's test id).
 */
@Composable
fun InlineAdaptiveBanner(
    @StringRes unitIdRes: Int,
    modifier: Modifier = Modifier,
    maxHeightDp: Int = 120,
) {
    val context = LocalContext.current
    var failed by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val widthDp = maxWidth.value.toInt()
        val adView = remember(widthDp, unitIdRes) {
            AdView(context).apply {
                setAdSize(AdSize.getInlineAdaptiveBannerAdSize(widthDp, maxHeightDp))
                adUnitId = context.getString(unitIdRes)
                adListener = object : AdListener() {
                    override fun onAdLoaded() { loaded = true }
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        Log.w(TAG, "Banner failed: ${error.code} ${error.message}")
                        failed = true
                    }
                }
                loadAd(AdRequest.Builder().build())
            }
        }
        DisposableEffect(adView) { onDispose { adView.destroy() } }

        if (!failed) {
            AndroidView(
                factory = { adView },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Pal.Card, RoundedCornerShape(18.dp))
                    .padding(vertical = if (loaded) 6.dp else 0.dp),
            )
        }
    }
}
