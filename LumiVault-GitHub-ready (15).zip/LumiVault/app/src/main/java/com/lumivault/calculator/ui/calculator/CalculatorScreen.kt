package com.lumivault.calculator.ui.calculator

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.material.icons.filled.UnfoldLess
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.IconButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumivault.calculator.LumiVaultApp

private val BgColor = Color(0xFF070707)
private val FnColor = Color(0xFF221F1E)     // AC, %, operators
private val DigitColor = Color(0xFF24252F)  // 0-9 and .
private val Accent = Color(0xFFFF6A00)      // =, backspace icon

@Composable
fun CalculatorScreen(app: LumiVaultApp, onUnlock: () -> Unit) {
    val vm: CalculatorViewModel = viewModel(
        factory = remember(app) {
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
        }
    )

    LaunchedEffect(Unit) {
        vm.unlockEvent.collect { onUnlock() }
    }

    // Wrong secret code: silent front-camera photo, stored encrypted inside the vault.
    val appContext = androidx.compose.ui.platform.LocalContext.current
    val lifecycleOwner = remember(appContext) {
        var c: android.content.Context = appContext
        var owner: androidx.lifecycle.LifecycleOwner? = null
        while (owner == null) {
            if (c is androidx.lifecycle.LifecycleOwner) owner = c
            else if (c is android.content.ContextWrapper) c = c.baseContext
            else break
        }
        owner
    }
    LaunchedEffect(Unit) {
        vm.wrongPin.collect {
            val owner = lifecycleOwner
            if (owner != null) {
                com.lumivault.calculator.security.IntruderCapture.captureAndRecord(appContext, owner, app.security)
            } else {
                app.security.recordPinFail()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .systemBarsPadding(),
    ) {
        // ---- Display ----
        var showHistory by remember { mutableStateOf(false) }
        var sciOpen by rememberSaveable { mutableStateOf(false) }
        BackHandler(enabled = showHistory) { showHistory = false }
        val shown = vm.expression.replace("x", "×").replace("/", "÷")
        val shownSize = when {
            shown.length <= 7 -> 68.sp
            shown.length <= 11 -> 52.sp
            else -> 38.sp
        }
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            if (showHistory) {
                HistoryPanel(
                    entries = vm.history,
                    onUse = { vm.useHistory(it); showHistory = false },
                    onClear = { vm.clearHistory() },
                    onClose = { showHistory = false },
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    if (shown.isNotEmpty()) {
                        Text(
                            shown,
                            fontSize = shownSize,
                            fontWeight = FontWeight.Light,
                            color = Color.White,
                            textAlign = TextAlign.End,
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    // Error, or the live answer while typing (no need to press "=").
                    val secondary = when {
                        vm.error != null -> vm.error!!
                        vm.preview.isNotEmpty() -> "= " + vm.preview
                        else -> ""
                    }
                    if (secondary.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            secondary,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Light,
                            color = if (vm.error != null) Color(0xFFFF8A80) else Color(0xFF8A8A8A),
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                IconButton(
                    onClick = { showHistory = true },
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                ) {
                    Icon(Icons.Filled.History, contentDescription = "History", tint = Color(0xFF9E9E9E))
                }
            }
        }

        // ---- Scientific panel switch (the two little arrows) ----
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { sciOpen = !sciOpen }) {
                Icon(
                    if (sciOpen) Icons.Filled.UnfoldLess else Icons.Filled.UnfoldMore,
                    contentDescription = if (sciOpen) "Hide scientific keys" else "Show scientific keys",
                    tint = Color(0xFF9E9E9E),
                )
            }
        }

        // ---- Keypad ----
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 20.dp),
        ) {
            val gap = 12.dp
            val size: Dp = (maxWidth - gap * 3) / 4
            // Opening the scientific panel makes every key a flatter pill, so everything still fits.
            val keyH by animateDpAsState(if (sciOpen) size * 0.62f else size, label = "keyHeight")
            val rowGap by animateDpAsState(if (sciOpen) 8.dp else gap, label = "rowGap")
            val inv = vm.inverse

            Column {
                AnimatedVisibility(
                    visible = sciOpen,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut(),
                ) {
                    Column(
                        modifier = Modifier.padding(bottom = rowGap),
                        verticalArrangement = Arrangement.spacedBy(rowGap),
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            Key(if (inv) "x²" else "√", width = size, height = keyH, bg = FnColor) { vm.onFunction("sqrt") }
                            Key("π", width = size, height = keyH, bg = FnColor) { vm.onConstant("π") }
                            Key("^", width = size, height = keyH, bg = FnColor) { vm.onPower() }
                            Key("!", width = size, height = keyH, bg = FnColor) { vm.onFactorial() }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            Key(if (vm.degrees) "Deg" else "Rad", width = size, height = keyH, bg = FnColor) { vm.toggleDegrees() }
                            Key(if (inv) "sin⁻¹" else "sin", width = size, height = keyH, bg = FnColor) { vm.onFunction("sin") }
                            Key(if (inv) "cos⁻¹" else "cos", width = size, height = keyH, bg = FnColor) { vm.onFunction("cos") }
                            Key(if (inv) "tan⁻¹" else "tan", width = size, height = keyH, bg = FnColor) { vm.onFunction("tan") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                            Key(
                                "Inv", width = size, height = keyH,
                                bg = if (inv) Color(0xFF4A2A10) else FnColor,
                                textColor = if (inv) Accent else Color.White,
                            ) { vm.toggleInverse() }
                            Key("e", width = size, height = keyH, bg = FnColor) { vm.onConstant("e") }
                            Key(if (inv) "eˣ" else "ln", width = size, height = keyH, bg = FnColor) { vm.onFunction("ln") }
                            Key(if (inv) "10ˣ" else "log", width = size, height = keyH, bg = FnColor) { vm.onFunction("log") }
                        }
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(rowGap)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("AC", width = size, height = keyH, bg = FnColor) { vm.onClear() }
                        Key("( )", width = size, height = keyH, bg = FnColor) { vm.onParen() }
                        Key("%", width = size, height = keyH, bg = FnColor) { vm.onPercent() }
                        Key("÷", width = size, height = keyH, bg = FnColor) { vm.onOperator("/") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("7", width = size, height = keyH) { vm.onDigit("7") }
                        Key("8", width = size, height = keyH) { vm.onDigit("8") }
                        Key("9", width = size, height = keyH) { vm.onDigit("9") }
                        Key("×", width = size, height = keyH, bg = FnColor) { vm.onOperator("x") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("4", width = size, height = keyH) { vm.onDigit("4") }
                        Key("5", width = size, height = keyH) { vm.onDigit("5") }
                        Key("6", width = size, height = keyH) { vm.onDigit("6") }
                        Key("−", width = size, height = keyH, bg = FnColor) { vm.onOperator("-") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("1", width = size, height = keyH) { vm.onDigit("1") }
                        Key("2", width = size, height = keyH) { vm.onDigit("2") }
                        Key("3", width = size, height = keyH) { vm.onDigit("3") }
                        Key("+", width = size, height = keyH, bg = FnColor) { vm.onOperator("+") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                        Key("0", width = size, height = keyH) { vm.onDigit("0") }
                        Key(".", width = size, height = keyH) { vm.onDigit(".") }
                        Key(icon = Icons.Outlined.Backspace, iconTint = Accent, width = size, height = keyH, bg = FnColor) { vm.onDelete() }
                        Key("=", width = size, height = keyH, bg = Accent) { vm.onEquals() }
                    }
                }
            }
        }
    }
}

@Composable
private fun Key(
    label: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = Color.White,
    width: Dp,
    height: Dp,
    bg: Color = DigitColor,
    textColor: Color = Color.White,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = CircleShape,                       // a full-round shape: circle when square, pill when flat
        color = bg,
        modifier = Modifier.size(width = width, height = height),
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (icon != null) {
                Icon(icon, contentDescription = "Delete", tint = iconTint, modifier = Modifier.size(height * 0.32f))
            } else {
                val text = label.orEmpty()
                val factor = when {
                    text.length >= 4 -> 0.30f
                    text.length >= 2 -> 0.38f
                    else -> 0.47f
                }
                Text(
                    text,
                    fontSize = (height.value * factor).sp,
                    fontWeight = FontWeight.Light,
                    color = textColor,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun HistoryPanel(
    entries: List<HistoryEntry>,
    onUse: (HistoryEntry) -> Unit,
    onClear: () -> Unit,
    onClose: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("History", color = Color(0xFF9E9E9E), fontSize = 18.sp, modifier = Modifier.weight(1f))
            if (entries.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Clear history", tint = Color(0xFF9E9E9E))
                }
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
            }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No calculations yet", color = Color(0xFF6E6E6E), fontSize = 16.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(entries) { e ->
                    Column(
                        modifier = Modifier.fillMaxWidth().clickable { onUse(e) },
                        horizontalAlignment = Alignment.End,
                    ) {
                        Text(
                            e.expression.replace("x", "×").replace("/", "÷"),
                            color = Color(0xFF8A8A8A),
                            fontSize = 18.sp,
                        )
                        Text("= " + e.result, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                    }
                }
            }
        }
    }
}
