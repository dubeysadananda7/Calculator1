# LumiVault ProGuard / R8 rules
-dontwarn javax.annotation.**
-dontwarn org.slf4j.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.checkerframework.**
-dontwarn kotlin.**

# Room
-keepclassmembers class * { @androidx.room.* *; }
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep class com.lumivault.calculator.data.db.** { *; }

# ViewModels are created by reflection (AndroidViewModelFactory)
-keep class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keep class * extends androidx.lifecycle.AndroidViewModel { <init>(android.app.Application); }

# Accessibility service + application class are referenced from the manifest
-keep class com.lumivault.calculator.service.** { *; }
-keep class com.lumivault.calculator.LumiVaultApp { *; }

# Enums are stored by name in the database
-keepclassmembers enum * { *; }
