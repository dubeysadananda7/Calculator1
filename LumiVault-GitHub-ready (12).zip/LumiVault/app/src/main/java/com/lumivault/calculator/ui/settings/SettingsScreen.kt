package com.lumivault.calculator.ui.settings

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.BuildConfig
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import com.lumivault.calculator.security.BiometricHelper
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.files.formatSize
import com.lumivault.calculator.ui.navigation.Routes
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val vaultApp = app as LumiVaultApp
    val settings = vaultApp.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, VaultSettings())
    val usedBytes = mutableStateOf(0L)

    init { refreshStorage() }

    fun refreshStorage() {
        usedBytes.value = vaultApp.vault.usedBytes()
    }

    fun setBiometric(v: Boolean) = viewModelScope.launch { vaultApp.settings.setBiometric(v) }
    fun setIntruder(v: Boolean) = viewModelScope.launch { vaultApp.settings.setIntruder(v) }
    fun setTheme(t: String) = viewModelScope.launch { vaultApp.settings.setTheme(t) }
    fun saveRecovery(q: String, a: String, email: String) = viewModelScope.launch {
        vaultApp.settings.setRecovery(q, a, email)
    }
    fun clearCache() {
        vaultApp.vault.clearPreviews()
        refreshStorage()
    }
}

@Composable
fun SettingsScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { SettingsViewModel(app) }
    val s by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var themeDialog by remember { mutableStateOf(false) }
    var recoveryDialog by remember { mutableStateOf(false) }

    val cameraPermission = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { /* granted or not; toggle still follows user choice */ }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        VaultTopBar(title = "Settings", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            SectionTitle("Security")
            SettingRow("Change secret PIN", "Update your vault access code") {
                nav.navigate(Routes.PIN_CHANGE)
            }
            SettingSwitch(
                title = "Fingerprint unlock",
                subtitle = if (BiometricHelper.canAuthenticate(context)) "Use biometrics to open the vault"
                else "Biometrics not available on this device",
                checked = s.biometricEnabled && BiometricHelper.canAuthenticate(context),
                enabled = BiometricHelper.canAuthenticate(context),
            ) { vm.setBiometric(it) }
            SettingSwitch(
                title = "Intruder selfie",
                subtitle = "Capture a front-camera photo after repeated wrong PINs (opt-in)",
                checked = s.intruderEnabled,
            ) { enabled ->
                if (enabled) {
                    com.lumivault.calculator.security.SessionManager.beginExternal()
                    cameraPermission.launch(android.Manifest.permission.CAMERA)
                }
                vm.setIntruder(enabled)
            }
            SettingRow(
                "Password recovery",
                if (s.recoveryQuestion.isEmpty()) "Set a security question and recovery email"
                else "Recovery configured",
            ) { recoveryDialog = true }

            Spacer(Modifier.height(18.dp))
            SectionTitle("Appearance")
            SettingRow("Theme", when (s.theme) { "LIGHT" -> "Light"; "DARK" -> "Dark"; else -> "System default" }) {
                themeDialog = true
            }

            Spacer(Modifier.height(18.dp))
            SectionTitle("Storage")
            SettingRow("Vault storage used", formatSize(vm.usedBytes.value)) { }
            SettingRow("Clear preview cache", "Frees temporary decrypted previews") { vm.clearCache() }

            Spacer(Modifier.height(18.dp))
            SectionTitle("About")
            SettingRow("Version", "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})") { }
            Text(
                "Calculator stores everything encrypted on-device. No account, no tracking, no ads.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 12.dp),
            )
            Spacer(Modifier.height(32.dp))
        }
    }

    if (themeDialog) {
        AlertDialog(
            onDismissRequest = { themeDialog = false },
            title = { Text("Theme") },
            text = {
                Column {
                    listOf("SYSTEM" to "System default", "LIGHT" to "Light", "DARK" to "Dark").forEach { (key, label) ->
                        TextButton(onClick = { vm.setTheme(key); themeDialog = false }) { Text(label) }
                    }
                }
            },
            confirmButton = {},
        )
    }

    if (recoveryDialog) {
        var q by remember { mutableStateOf(s.recoveryQuestion) }
        var a by remember { mutableStateOf("") }
        var email by remember { mutableStateOf(s.recoveryEmail) }
        AlertDialog(
            onDismissRequest = { recoveryDialog = false },
            title = { Text("Password recovery") },
            text = {
                Column {
                    OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Security question") })
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = a, onValueChange = { a = it }, label = { Text("Answer") })
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Recovery email") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.saveRecovery(q, a, email)
                    recoveryDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { recoveryDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
    )
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun SettingRow(title: String, subtitle: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text("›", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingSwitch(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
    HorizontalDivider(Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.surfaceVariant)
}
