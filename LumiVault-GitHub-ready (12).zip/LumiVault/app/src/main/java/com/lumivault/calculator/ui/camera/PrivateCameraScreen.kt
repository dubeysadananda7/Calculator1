package com.lumivault.calculator.ui.camera

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import com.lumivault.calculator.BuildConfig
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.components.AccentButton
import com.lumivault.calculator.ui.components.GradientChip
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import com.lumivault.calculator.ui.components.ToastBar
import com.lumivault.calculator.ui.navigation.Routes
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Private camera: the phone's camera app is asked to write the photo/video straight into the app's
 * private cache (never the gallery). It is then encrypted into the vault and the temporary file is deleted.
 */
@Composable
fun PrivateCameraScreen(app: LumiVaultApp, nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pending by remember { mutableStateOf<File?>(null) }
    var pendingType by remember { mutableStateOf(VaultItemType.PHOTO) }
    var wantType by remember { mutableStateOf(VaultItemType.PHOTO) }
    var toast by remember { mutableStateOf<String?>(null) }
    var photosSaved by remember { mutableStateOf(0) }
    var videosSaved by remember { mutableStateOf(0) }

    LaunchedEffect(toast) {
        if (toast != null) { delay(2500); toast = null }
    }

    fun uriFor(file: File) =
        FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)

    val onResult: (Boolean) -> Unit = { ok ->
        val file = pending
        val type = pendingType
        pending = null
        if (file != null) {
            if (!ok || !file.exists() || file.length() == 0L) {
                file.delete() // cancelled
            } else {
                scope.launch {
                    val r = app.vault.import(uriFor(file), type)
                    file.delete()
                    if (r.isSuccess) {
                        if (type == VaultItemType.PHOTO) photosSaved++ else videosSaved++
                        toast = "Saved privately in the vault"
                    } else {
                        toast = r.exceptionOrNull()?.message ?: "Could not save"
                    }
                }
            }
        }
    }

    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture(), onResult)
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo(), onResult)

    fun launchCapture(type: VaultItemType) {
        val dir = File(context.cacheDir, "capture").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, if (type == VaultItemType.PHOTO) "IMG_$stamp.jpg" else "VID_$stamp.mp4")
        pending = file
        pendingType = type
        SessionManager.beginExternal()
        try {
            if (type == VaultItemType.PHOTO) photoLauncher.launch(uriFor(file)) else videoLauncher.launch(uriFor(file))
        } catch (e: Exception) {
            pending = null
            toast = "No camera app found on this phone"
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchCapture(wantType) else toast = "Camera permission is needed"
    }

    fun start(type: VaultItemType) {
        wantType = type
        val ok = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (ok) launchCapture(type) else {
            SessionManager.beginExternal()
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(title = "Camera", onBack = { nav.popBackStack() })
            Column(Modifier.padding(horizontal = 16.dp)) {
                val shape = RoundedCornerShape(22.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
                        .border(1.dp, Pal.Border, shape)
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = Pal.OrangeHi)
                    Column(Modifier.padding(start = 14.dp)) {
                        Text("Private capture", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Photos and videos taken here are saved only inside the vault. They never appear in your gallery.",
                            color = Pal.Muted, fontSize = 13.sp,
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    CaptureCard("Photo", "Take a picture", Icons.Filled.CameraAlt,
                        Color(0xFFFF5A8A), Color(0xFFE91EC0), Modifier.weight(1f)) { start(VaultItemType.PHOTO) }
                    CaptureCard("Video", "Record a video", Icons.Filled.Videocam,
                        Color(0xFFFFA64D), Color(0xFFFF5A1F), Modifier.weight(1f)) { start(VaultItemType.VIDEO) }
                }
                if (photosSaved + videosSaved > 0) {
                    Spacer(Modifier.height(22.dp))
                    Text(
                        "Saved now: $photosSaved photo${if (photosSaved == 1) "" else "s"}, $videosSaved video${if (videosSaved == 1) "" else "s"}",
                        color = Pal.Muted, fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AccentButton("View photos", { nav.navigate(Routes.PHOTOS) })
                        AccentButton("View videos", { nav.navigate(Routes.VIDEOS) })
                    }
                }
            }
        }
        toast?.let {
            ToastBar(
                it,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp),
            )
        }
    }
}

@Composable
private fun CaptureCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    top: Color,
    bottom: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        modifier = modifier
            .height(190.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
            .border(1.dp, Pal.Border, shape)
            .clickable(onClick = onClick)
            .padding(22.dp),
    ) {
        GradientChip(icon, top, bottom, size = 62.dp)
        Spacer(Modifier.weight(1f))
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = Pal.Muted, fontSize = 14.sp)
    }
}
