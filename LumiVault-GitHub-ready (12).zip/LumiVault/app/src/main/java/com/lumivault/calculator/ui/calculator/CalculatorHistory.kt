package com.lumivault.calculator.ui.calculator

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEntry(val expression: String, val result: String, val time: Long)

/** Keeps the last calculations, like any normal calculator app. */
object CalculatorHistory {
    private const val KEY = "items"
    const val MAX = 100

    private fun prefs(c: Context) = c.getSharedPreferences("calc_history", Context.MODE_PRIVATE)

    fun load(c: Context): List<HistoryEntry> = runCatching {
        val arr = JSONArray(prefs(c).getString(KEY, "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryEntry(o.getString("e"), o.getString("r"), o.getLong("t"))
        }
    }.getOrDefault(emptyList())

    fun save(c: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.take(MAX).forEach {
            arr.put(JSONObject().put("e", it.expression).put("r", it.result).put("t", it.time))
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }
}
