package com.lumivault.calculator.ui.applock

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.lumivault.calculator.security.AppLockState
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.service.VaultAccessibilityService
import com.lumivault.calculator.ui.components.AccentButton
import com.lumivault.calculator.ui.components.Pal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppEntry(val pkg: String, val label: String, val icon: ImageBitmap?)

/** Every app that has a launcher icon (needs the <queries> entry in the manifest on Android 11+). */
suspend fun loadInstalledApps(context: Context): List<AppEntry> = withContext(Dispatchers.IO) {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { info ->
            AppEntry(
                pkg = info.activityInfo.packageName,
                label = info.loadLabel(pm).toString(),
                icon = runCatching { info.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull(),
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun isLockServiceEnabled(context: Context): Boolean {
    val enabled = Settings.Secure.getString(
        context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val full = ComponentName(context, VaultAccessibilityService::class.java).flattenToString()
    val short = ComponentName(context, VaultAccessibilityService::class.java).flattenToShortString()
    return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
}

fun openAccessibilitySettings(context: Context) {
    SessionManager.beginExternal()
    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Opens [pkg] from inside the vault without asking for the PIN a second time. */
fun launchApp(context: Context, pkg: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(pkg) ?: return
    AppLockState.allowOnce(pkg)
    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun ProtectionCard(enabled: Boolean, onOpenSettings: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
            .border(1.dp, if (enabled) Color(0x5531D07A) else Color(0x66FF6A00), shape)
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.foundation.layout.Box(
                Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (enabled) Color(0xFF31D07A) else Pal.Orange)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                if (enabled) "Protection is ON" else "Turn on protection",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
        Spacer(Modifier.height(8.dp))
        if (enabled) {
            Text(
                "Switched-on apps ask for your PIN when they are opened. They lock again as soon as you leave them.",
                color = Pal.Muted, fontSize = 14.sp,
            )
        } else {
            Text(
                "1. Tap the button, open “Calculator” and switch it on.\n" +
                    "2. If the switch is greyed out: Settings → Apps → Calculator → ⋮ → Allow restricted settings, then try again.",
                color = Pal.Muted, fontSize = 14.sp,
            )
            Spacer(Modifier.height(14.dp))
            AccentButton("Open accessibility settings", onOpenSettings)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Tip: set Calculator’s battery usage to “No restrictions” so Android doesn’t stop the lock in the background.",
            color = Pal.Muted, fontSize = 12.sp,
        )
    }
}

@Composable
fun AppRowCard(entry: AppEntry, checked: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.Card)
            .border(1.dp, Pal.Border, shape)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(entry, 44)
        Spacer(Modifier.width(14.dp))
        Text(
            entry.label,
            color = Color.White,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Pal.Orange,
                uncheckedThumbColor = Pal.Muted,
                uncheckedTrackColor = Pal.CardHi,
                uncheckedBorderColor = Pal.Border,
            ),
        )
    }
}

@Composable
fun AppIcon(entry: AppEntry, sizeDp: Int) {
    val m = Modifier.size(sizeDp.dp).clip(RoundedCornerShape((sizeDp * 0.24f).dp))
    if (entry.icon != null) {
        Image(bitmap = entry.icon, contentDescription = entry.label, modifier = m)
    } else {
        androidx.compose.foundation.layout.Box(m.background(Pal.CardHi))
    }
}

@Composable
fun AppTile(entry: AppEntry, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        AppIcon(entry, 58)
        Text(
            entry.label,
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}
