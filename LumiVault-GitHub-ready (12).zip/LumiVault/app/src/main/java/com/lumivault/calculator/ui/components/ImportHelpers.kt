package com.lumivault.calculator.ui.components

import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.lumivault.calculator.data.repo.MediaCleaner
import com.lumivault.calculator.security.SessionManager

/** Returns a function that deletes the given gallery originals (system confirmation dialog on Android 11+). */
@Composable
fun rememberOriginalsCleanup(): (List<Uri>) -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { }
    return remember(context, launcher) {
        { uris: List<Uri> ->
            // With "All files access" the originals are deleted silently; anything left goes through
            // the system delete request (silent too when "Media management" is allowed).
            val remaining = if (MediaCleaner.hasAllFilesAccess()) MediaCleaner.deleteDirect(context, uris) else uris
            if (remaining.isNotEmpty()) {
                val sender = MediaCleaner.deleteIntentSender(context, remaining)
                if (sender != null) {
                    SessionManager.beginExternal()
                    launcher.launch(IntentSenderRequest.Builder(sender).build())
                }
                else MediaCleaner.deleteLegacy(context, remaining)
            }
        }
    }
}

/** Asks for gallery read permission (needed to find & delete the originals), then runs [action]. */
@Composable
fun rememberMediaPermissionGate(action: () -> Unit): () -> Unit {
    val context = LocalContext.current
    val current by rememberUpdatedState(action)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        SessionManager.beginExternal()
        current()
    }
    return remember(context, launcher) {
        {
            val missing = MediaCleaner.requiredPermissions().filter {
                ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
            }
            SessionManager.beginExternal()
            if (missing.isEmpty()) current() else launcher.launch(missing.toTypedArray())
        }
    }
}
