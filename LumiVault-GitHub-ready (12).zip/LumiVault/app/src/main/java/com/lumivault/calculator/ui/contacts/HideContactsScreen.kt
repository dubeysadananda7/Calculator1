package com.lumivault.calculator.ui.contacts

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.PhoneContact
import com.lumivault.calculator.data.repo.PhoneContacts
import com.lumivault.calculator.data.repo.PrivateContact
import com.lumivault.calculator.security.SessionManager
import com.lumivault.calculator.ui.components.AccentBrush
import com.lumivault.calculator.ui.components.AccentButton
import com.lumivault.calculator.ui.components.AccentFab
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.CountChip
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import com.lumivault.calculator.ui.components.ToastBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ContactsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).contacts
    private val ctx: Application = app

    val contacts: StateFlow<List<PrivateContact>> = repo.contacts

    init { viewModelScope.launch { repo.load() } }

    suspend fun save(c: PrivateContact) = repo.upsert(c)

    suspend fun delete(id: String) = repo.delete(id)

    /** Saves the chosen phone contacts in the vault; optionally removes them from the phone. Returns (saved, removedFromPhone). */
    suspend fun importFromPhone(selected: List<PhoneContact>, removeFromPhone: Boolean): Pair<Int, Int> {
        repo.upsertAll(selected.map { PrivateContact(name = it.name, phones = it.phones, emails = it.emails) })
        val removed = if (removeFromPhone) withContext(Dispatchers.IO) {
            PhoneContacts.delete(ctx, selected.map { it.lookupKey })
        } else 0
        return selected.size to removed
    }

    /** Puts the contact back into the phone's Contacts app and removes it from the vault. */
    suspend fun restoreToPhone(c: PrivateContact): Result<Unit> = runCatching {
        withContext(Dispatchers.IO) { PhoneContacts.insert(ctx, c) }
        repo.delete(c.id)
    }
}

private val AvatarColors = listOf(
    Color(0xFF3D7BFF) to Color(0xFF1D34D6),
    Color(0xFFFF5A8A) to Color(0xFFE91EC0),
    Color(0xFF3FE6B4) to Color(0xFF1790EA),
    Color(0xFFFFA64D) to Color(0xFFFF5A1F),
    Color(0xFFA48BFF) to Color(0xFF6A4DE8),
)

private val ContactPermissions = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)

@Composable
fun HideContactsScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { ContactsViewModel(app) }
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var view by remember { mutableStateOf("list") }           // list | edit | import
    var editing by remember { mutableStateOf<PrivateContact?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    LaunchedEffect(toast) { if (toast != null) { delay(3000); toast = null } }
    BackHandler(enabled = view != "list") { view = "list" }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val action = pendingAction
        pendingAction = null
        if (res.values.all { it } && action != null) action() else toast = "Contacts permission is needed"
    }
    fun withContactsPermission(action: () -> Unit) {
        val ok = ContactPermissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
        if (ok) action() else {
            SessionManager.beginExternal()
            pendingAction = action
            permissionLauncher.launch(ContactPermissions)
        }
    }
    fun launchExternal(intent: Intent) {
        SessionManager.beginExternal()
        runCatching { context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast = "No app found for this action" }
    }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            when (view) {
                "edit" -> EditView(
                    contact = editing,
                    onBack = { view = "list" },
                    onSave = { c -> scope.launch { vm.save(c); view = "list"; toast = "Saved in the vault" } },
                    onDelete = { c -> scope.launch { vm.delete(c.id); view = "list"; toast = "Contact deleted" } },
                    onRestore = { c ->
                        withContactsPermission {
                            scope.launch {
                                vm.restoreToPhone(c)
                                    .onSuccess { view = "list"; toast = "Restored to your phone contacts" }
                                    .onFailure { toast = it.message ?: "Could not restore" }
                            }
                        }
                    },
                    onCall = { n -> launchExternal(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n)))) },
                    onMessage = { n -> launchExternal(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))) },
                )
                "import" -> ImportView(
                    onBack = { view = "list" },
                    onDone = { saved, removed, wanted ->
                        view = "list"
                        toast = when {
                            !wanted -> "$saved contact(s) saved in the vault"
                            removed >= saved -> "$saved contact(s) moved to the vault and removed from your phone"
                            else -> "$saved saved in the vault, but only $removed could be removed from the phone"
                        }
                    },
                    vm = vm,
                )
                else -> ListView(
                    contacts = contacts,
                    onBack = { nav.popBackStack() },
                    onOpen = { editing = it; view = "edit" },
                    onCall = { c -> c.phones.firstOrNull()?.let { launchExternal(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(it)))) } },
                    onImport = { withContactsPermission { view = "import" } },
                )
            }
        }
        if (view == "list") {
            AccentFab(
                icon = Icons.Filled.Add,
                contentDescription = "New contact",
                onClick = { editing = null; view = "edit" },
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(24.dp),
            )
        }
        toast?.let {
            ToastBar(it, modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 16.dp))
        }
    }
}

@Composable
private fun Avatar(name: String, size: Int = 48) {
    val (a, b) = AvatarColors[(name.hashCode() and 0x7fffffff) % AvatarColors.size]
    Box(
        modifier = Modifier.size(size.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(a, b))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "?",
            color = Color.White, fontSize = (size * 0.42f).sp, fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun ListView(
    contacts: List<PrivateContact>,
    onBack: () -> Unit,
    onOpen: (PrivateContact) -> Unit,
    onCall: (PrivateContact) -> Unit,
    onImport: () -> Unit,
) {
    ScreenHeader(
        title = "Hide contacts",
        onBack = onBack,
        actions = { if (contacts.isNotEmpty()) CountChip("${contacts.size} hidden") },
    )
    if (contacts.isEmpty()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Filled.Person, contentDescription = null, tint = Pal.Muted, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(14.dp))
            Text("No hidden contacts yet", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Move contacts out of your phone’s Contacts app into the vault, or tap + to add a private one.",
                color = Pal.Muted, fontSize = 14.sp,
            )
            Spacer(Modifier.height(20.dp))
            AccentButton("Import from phone", onImport)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { AccentButton("Import from phone", onImport) }
        items(contacts, key = { it.id }) { c ->
            val shape = RoundedCornerShape(22.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
                    .border(1.dp, Pal.Border, shape)
                    .clickable { onOpen(c) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(c.name)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name.ifEmpty { "No name" }, color = Color.White, fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(c.phones.firstOrNull() ?: c.emails.firstOrNull() ?: "", color = Pal.Muted, fontSize = 14.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (c.phones.isNotEmpty()) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Pal.CardHi).clickable { onCall(c) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Call, contentDescription = "Call", tint = Pal.OrangeHi, modifier = Modifier.size(20.dp)) }
                }
            }
        }
    }
}

@Composable
private fun FieldBox(label: String, value: String, onChange: (String) -> Unit, keyboard: KeyboardType, singleLine: Boolean) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Pal.Card)
            .border(1.dp, Pal.Border, shape)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(label, color = Pal.Muted, fontSize = 12.sp)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            minLines = if (singleLine) 1 else 2,
            textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Pal.Orange),
            keyboardOptions = KeyboardOptions(keyboardType = keyboard),
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        )
    }
}

@Composable
private fun ColumnScope.EditView(
    contact: PrivateContact?,
    onBack: () -> Unit,
    onSave: (PrivateContact) -> Unit,
    onDelete: (PrivateContact) -> Unit,
    onRestore: (PrivateContact) -> Unit,
    onCall: (String) -> Unit,
    onMessage: (String) -> Unit,
) {
    var name by remember(contact?.id) { mutableStateOf(contact?.name ?: "") }
    var phones by remember(contact?.id) { mutableStateOf(contact?.phones?.joinToString("\n") ?: "") }
    var emails by remember(contact?.id) { mutableStateOf(contact?.emails?.joinToString("\n") ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    fun lines(s: String) = s.split('\n', ',').map { it.trim() }.filter { it.isNotEmpty() }
    fun build() = PrivateContact(
        id = contact?.id ?: java.util.UUID.randomUUID().toString(),
        name = name.trim(),
        phones = lines(phones),
        emails = lines(emails),
    )
    val canSave = name.isNotBlank() || phones.isNotBlank()

    ScreenHeader(title = if (contact == null) "New contact" else "Edit contact", onBack = onBack)
    Column(
        modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        FieldBox("Name", name, { name = it }, KeyboardType.Text, true)
        FieldBox("Phone numbers (one per line)", phones, { phones = it }, KeyboardType.Phone, false)
        FieldBox("Emails (one per line)", emails, { emails = it }, KeyboardType.Email, false)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (canSave) AccentButton("Save", { onSave(build()) })
            lines(phones).firstOrNull()?.let { n ->
                Text("Call", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Pal.CardHi).clickable { onCall(n) }
                        .padding(horizontal = 22.dp, vertical = 12.dp))
                Text("Message", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Pal.CardHi).clickable { onMessage(n) }
                        .padding(horizontal = 22.dp, vertical = 12.dp))
            }
        }
        if (contact != null) {
            Spacer(Modifier.height(6.dp))
            Text("Restore to phone contacts", color = Pal.OrangeHi, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onRestore(build()) }.padding(vertical = 8.dp))
            Text("Delete contact", color = Color(0xFFFF8A80), fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { confirmDelete = true }.padding(vertical = 8.dp))
        }
        Spacer(Modifier.height(40.dp))
    }
    if (confirmDelete && contact != null) {
        ConfirmDialog(
            title = "Delete contact?",
            text = "This permanently deletes it from the vault.",
            confirmLabel = "Delete",
            onConfirm = { confirmDelete = false; onDelete(contact) },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
private fun ColumnScope.ImportView(
    onBack: () -> Unit,
    onDone: (saved: Int, removed: Int, wanted: Boolean) -> Unit,
    vm: ContactsViewModel,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val phone by produceState<List<PhoneContact>?>(initialValue = null) { value = PhoneContacts.load(context) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var remove by remember { mutableStateOf(true) }
    var confirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val list = phone
    val shown = list?.filter {
        query.isBlank() || it.name.contains(query, ignoreCase = true) || it.phones.any { p -> p.contains(query) }
    }.orEmpty()

    ScreenHeader(
        title = "Import contacts",
        onBack = onBack,
        actions = {
            if (!list.isNullOrEmpty()) {
                Text(
                    if (selected.size == shown.size && shown.isNotEmpty()) "Clear" else "Select all",
                    color = Pal.OrangeHi, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Pal.CardHi)
                        .clickable {
                            selected = if (selected.size == shown.size) emptySet() else shown.map { it.id }.toSet()
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        },
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(50))
            .background(Pal.Card)
            .border(1.dp, Pal.Border, RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = Pal.Muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Pal.Orange),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                if (query.isEmpty()) Text("Search contacts", color = Pal.Muted, fontSize = 16.sp)
                inner()
            },
        )
    }

    Box(Modifier.weight(1f).fillMaxWidth()) {
        when {
            list == null -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Pal.Orange)
            list.isEmpty() -> Text("No contacts found on this phone.", color = Pal.Muted, modifier = Modifier.align(Alignment.Center))
            else -> LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(shown, key = { it.id }) { pc ->
                    val isSel = pc.id in selected
                    val shape = RoundedCornerShape(18.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(Pal.Card)
                            .border(1.dp, if (isSel) Pal.Orange else Pal.Border, shape)
                            .clickable { selected = if (isSel) selected - pc.id else selected + pc.id }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(pc.name, 42)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pc.name, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(pc.phones.firstOrNull() ?: pc.emails.firstOrNull() ?: "", color = Pal.Muted, fontSize = 13.sp, maxLines = 1)
                        }
                        Box(
                            Modifier.size(24.dp).clip(CircleShape).background(if (isSel) Pal.Orange else Pal.CardHi),
                            contentAlignment = Alignment.Center,
                        ) { if (isSel) Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Pal.Card)
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Also remove them from the phone’s Contacts", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(
                checked = remove,
                onCheckedChange = { remove = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White, checkedTrackColor = Pal.Orange,
                    uncheckedThumbColor = Pal.Muted, uncheckedTrackColor = Pal.CardHi, uncheckedBorderColor = Pal.Border,
                ),
            )
        }
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(50))
                .background(if (selected.isEmpty() || busy) SolidColor(Pal.CardHi) else AccentBrush)
                .clickable(enabled = selected.isNotEmpty() && !busy) {
                    if (remove) {
                        confirm = true
                    } else {
                        busy = true
                        val chosen = list.orEmpty().filter { it.id in selected }
                        scope.launch {
                            val (saved, removed) = vm.importFromPhone(chosen, false)
                            busy = false
                            onDone(saved, removed, false)
                        }
                    }
                }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (selected.isEmpty()) "Select contacts" else "Move ${selected.size} to vault",
                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }

    if (confirm) {
        ConfirmDialog(
            title = "Move to the vault?",
            text = "The ${selected.size} selected contact(s) will be deleted from your phone’s Contacts app. " +
                "If your contacts sync with a Google or Mi account, they will be removed there too. " +
                "They stay safely in the vault, and you can restore them any time.",
            confirmLabel = "Move",
            onConfirm = {
                confirm = false
                busy = true
                val chosen = list.orEmpty().filter { it.id in selected }
                scope.launch {
                    val (saved, removed) = vm.importFromPhone(chosen, true)
                    busy = false
                    onDone(saved, removed, true)
                }
            },
            onDismiss = { confirm = false },
        )
    }
}
