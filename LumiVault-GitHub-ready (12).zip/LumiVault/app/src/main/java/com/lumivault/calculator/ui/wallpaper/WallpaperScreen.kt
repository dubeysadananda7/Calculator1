package com.lumivault.calculator.ui.wallpaper

import android.app.Application
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import com.lumivault.calculator.ui.components.ToastBar
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WallpaperViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = (app as LumiVaultApp).settings

    val selected = settings.settings.map { it.wallpaper }
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    fun select(id: String) = viewModelScope.launch { settings.setWallpaper(id) }
}

@Composable
fun WallpaperScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { WallpaperViewModel(app) }
    val selected by vm.selected.collectAsStateWithLifecycle()
    var toast by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(toast) {
        if (toast != null) { delay(1800); toast = null }
    }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(
                title = "Wallpaper",
                onBack = { nav.popBackStack() },
                actions = {
                    Text(
                        "Default",
                        color = if (selected.isEmpty()) Pal.Orange else Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Pal.CardHi)
                            .clickable { vm.select(""); toast = "Default wallpaper applied" }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                },
            )
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(Wallpapers.categories, key = { it.name }) { cat ->
                    Column {
                        Text(
                            cat.name,
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 12.dp, bottom = 10.dp),
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            cat.items.forEach { wp ->
                                WallpaperTile(
                                    wp = wp,
                                    isSelected = wp.id == selected,
                                    modifier = Modifier.weight(1f),
                                ) { vm.select(wp.id); toast = "Wallpaper applied" }
                            }
                        }
                    }
                }
            }
        }
        toast?.let {
            ToastBar(
                it,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp),
            )
        }
    }
}

@Composable
private fun WallpaperTile(wp: WallpaperItem, isSelected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .aspectRatio(216f / 468f)
            .clip(shape)
            .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Pal.Orange else Pal.Border, shape)
            .clickable(onClick = onClick),
    ) {
        Image(
            painter = painterResource(wp.thumb),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        if (isSelected) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(Pal.Orange),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Check, contentDescription = "Selected", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }
    }
}
