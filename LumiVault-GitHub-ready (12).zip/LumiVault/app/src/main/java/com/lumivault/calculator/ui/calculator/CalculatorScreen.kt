package com.lumivault.calculator.ui.calculator

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.IconButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backspace
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lumivault.calculator.LumiVaultApp

private val BgColor = Color(0xFF070707)
private val FnColor = Color(0xFF221F1E)     // AC, %, operators
private val DigitColor = Color(0xFF24252F)  // 0-9 and .
private val Accent = Color(0xFFFF6A00)      // =, backspace icon

@Composable
fun CalculatorScreen(app: LumiVaultApp, onUnlock: () -> Unit) {
    val vm: CalculatorViewModel = viewModel(
        factory = remember(app) {
            androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.getInstance(app)
        }
    )

    LaunchedEffect(Unit) {
        vm.unlockEvent.collect { onUnlock() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .systemBarsPadding(),
    ) {
        // ---- Display ----
        var showHistory by remember { mutableStateOf(false) }
        BackHandler(enabled = showHistory) { showHistory = false }
        val shown = vm.expression.replace("x", "×").replace("/", "÷")
        val shownSize = when {
            shown.length <= 7 -> 68.sp
            shown.length <= 11 -> 52.sp
            else -> 38.sp
        }
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            if (showHistory) {
                HistoryPanel(
                    entries = vm.history,
                    onUse = { vm.useHistory(it); showHistory = false },
                    onClear = { vm.clearHistory() },
                    onClose = { showHistory = false },
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Bottom,
                ) {
                    if (shown.isNotEmpty()) {
                        Text(
                            shown,
                            fontSize = shownSize,
                            fontWeight = FontWeight.Light,
                            color = Color.White,
                            textAlign = TextAlign.End,
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    // Error, or the live answer while typing (no need to press "=").
                    val secondary = when {
                        vm.error != null -> vm.error!!
                        vm.preview.isNotEmpty() -> "= " + vm.preview
                        else -> ""
                    }
                    if (secondary.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            secondary,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Light,
                            color = if (vm.error != null) Color(0xFFFF8A80) else Color(0xFF8A8A8A),
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                IconButton(
                    onClick = { showHistory = true },
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                ) {
                    Icon(Icons.Filled.History, contentDescription = "History", tint = Color(0xFF9E9E9E))
                }
            }
        }

        // ---- Keypad ----
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 20.dp),
        ) {
            val gap = 12.dp
            val size: Dp = (maxWidth - gap * 3) / 4

            Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key(icon = Icons.Outlined.Backspace, iconTint = Accent, size = size, bg = FnColor) { vm.onDelete() }
                    Key("AC", size = size, bg = FnColor) { vm.onClear() }
                    Key("%", size = size, bg = FnColor) { vm.onPercent() }
                    Key("÷", size = size, bg = FnColor) { vm.onOperator("/") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("7", size = size) { vm.onDigit("7") }
                    Key("8", size = size) { vm.onDigit("8") }
                    Key("9", size = size) { vm.onDigit("9") }
                    Key("×", size = size, bg = FnColor) { vm.onOperator("x") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("4", size = size) { vm.onDigit("4") }
                    Key("5", size = size) { vm.onDigit("5") }
                    Key("6", size = size) { vm.onDigit("6") }
                    Key("−", size = size, bg = FnColor) { vm.onOperator("-") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("1", size = size) { vm.onDigit("1") }
                    Key("2", size = size) { vm.onDigit("2") }
                    Key("3", size = size) { vm.onDigit("3") }
                    Key("+", size = size, bg = FnColor) { vm.onOperator("+") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    Key("0", size = size) { vm.onDigit("0") }
                    Key(".", size = size) { vm.onDigit(".") }
                    Key("=", size = size, wide = true, bg = Accent) { vm.onEquals() }
                }
            }
        }
    }
}

@Composable
private fun Key(
    label: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = Color.White,
    size: Dp,
    wide: Boolean = false,
    bg: Color = DigitColor,
    onClick: () -> Unit,
) {
    val gap = 12.dp
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = bg,
        modifier = if (wide) Modifier.size(width = size * 2 + gap, height = size) else Modifier.size(size),
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (icon != null) {
                Icon(icon, contentDescription = "Delete", tint = iconTint)
            } else {
                Text(
                    label.orEmpty(),
                    fontSize = if (label == "AC") 34.sp else 40.sp,
                    fontWeight = FontWeight.Light,
                    color = Color.White,
                )
            }
        }
    }
}

@Composable
private fun HistoryPanel(
    entries: List<HistoryEntry>,
    onUse: (HistoryEntry) -> Unit,
    onClear: () -> Unit,
    onClose: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("History", color = Color(0xFF9E9E9E), fontSize = 18.sp, modifier = Modifier.weight(1f))
            if (entries.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Clear history", tint = Color(0xFF9E9E9E))
                }
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
            }
        }
        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No calculations yet", color = Color(0xFF6E6E6E), fontSize = 16.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                items(entries) { e ->
                    Column(
                        modifier = Modifier.fillMaxWidth().clickable { onUse(e) },
                        horizontalAlignment = Alignment.End,
                    ) {
                        Text(
                            e.expression.replace("x", "×").replace("/", "÷"),
                            color = Color(0xFF8A8A8A),
                            fontSize = 18.sp,
                        )
                        Text("= " + e.result, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                    }
                }
            }
        }
    }
}
