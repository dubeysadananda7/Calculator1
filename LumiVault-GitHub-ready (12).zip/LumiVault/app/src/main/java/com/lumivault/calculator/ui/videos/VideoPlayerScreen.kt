package com.lumivault.calculator.ui.videos

import android.net.Uri
import android.view.View
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ThumbButton
import com.lumivault.calculator.ui.components.ToastBar
import java.io.File
import kotlinx.coroutines.launch

@Composable
fun VideoPlayerScreen(app: LumiVaultApp, itemId: String, nav: NavHostController) {
    val repo = app.vault
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val item by produceState<VaultItemEntity?>(initialValue = null, itemId) {
        value = repo.byId(itemId)
    }
    val file by produceState<File?>(initialValue = null, item?.id) {
        val current = item ?: return@produceState
        value = repo.playableFileForPlayback(current)
    }

    val player = remember(file) {
        file?.let {
            ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.fromFile(it)))
                prepare()
                playWhenReady = true
            }
        }
    }

    // Release the player and wipe the temporary decrypted copy when they are replaced or the screen closes.
    DisposableEffect(player) { onDispose { player?.release() } }
    DisposableEffect(file) { onDispose { file?.delete() } }

    var controlsVisible by remember { mutableStateOf(true) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    setControllerVisibilityListener(
                        PlayerView.ControllerVisibilityListener { v -> controlsVisible = v == View.VISIBLE }
                    )
                }
            },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize(),
        )
        if (file == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Pal.Orange)

        if (controlsVisible) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ThumbButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onClick = { nav.popBackStack() }, size = 42.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item?.displayName ?: "Video",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text("Private video", color = Pal.Muted, fontSize = 13.sp)
                }
                if (item != null) {
                    ThumbButton(Icons.Default.Restore, "Restore to gallery", onClick = { confirmRestore = true },
                        size = 42.dp, tint = Pal.OrangeHi)
                    Spacer(Modifier.width(8.dp))
                    ThumbButton(Icons.Default.DeleteOutline, "Delete", onClick = { confirmDelete = true },
                        size = 42.dp, tint = Color(0xFFFF8A80))
                }
            }
        }

        toast?.let {
            ToastBar(it, modifier = Modifier.align(Alignment.Center))
        }
    }

    val current = item
    if (confirmRestore && current != null) {
        ConfirmDialog(
            title = "Restore to gallery?",
            text = "\"${current.displayName}\" will be moved back to your phone gallery and removed from the vault.",
            confirmLabel = "Restore",
            onConfirm = {
                confirmRestore = false
                scope.launch {
                    repo.exportToGallery(current)
                        .onSuccess { nav.popBackStack() }
                        .onFailure { toast = it.message ?: "Restore failed" }
                }
            },
            onDismiss = { confirmRestore = false },
        )
    }
    if (confirmDelete && current != null) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "You can restore it later from the recycle bin.",
            confirmLabel = "Move",
            onConfirm = {
                confirmDelete = false
                scope.launch {
                    repo.softDelete(current.id)
                    nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
