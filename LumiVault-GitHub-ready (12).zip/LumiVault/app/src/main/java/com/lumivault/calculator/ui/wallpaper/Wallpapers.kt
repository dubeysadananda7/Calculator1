package com.lumivault.calculator.ui.wallpaper

import com.lumivault.calculator.R

class WallpaperItem(val id: String, val full: Int, val thumb: Int)

class WallpaperCategory(val name: String, val items: List<WallpaperItem>)

/** 10 categories x 3 wallpapers = 30. */
object Wallpapers {
    val categories: List<WallpaperCategory> = listOf(
        WallpaperCategory("Bikes", listOf(
            WallpaperItem("bike_1", R.drawable.wp_bike_1, R.drawable.wpt_bike_1),
            WallpaperItem("bike_2", R.drawable.wp_bike_2, R.drawable.wpt_bike_2),
            WallpaperItem("bike_3", R.drawable.wp_bike_3, R.drawable.wpt_bike_3),
        )),
        WallpaperCategory("Cars", listOf(
            WallpaperItem("car_1", R.drawable.wp_car_1, R.drawable.wpt_car_1),
            WallpaperItem("car_2", R.drawable.wp_car_2, R.drawable.wpt_car_2),
            WallpaperItem("car_3", R.drawable.wp_car_3, R.drawable.wpt_car_3),
        )),
        WallpaperCategory("Nature", listOf(
            WallpaperItem("nature_1", R.drawable.wp_nature_1, R.drawable.wpt_nature_1),
            WallpaperItem("nature_2", R.drawable.wp_nature_2, R.drawable.wpt_nature_2),
            WallpaperItem("nature_3", R.drawable.wp_nature_3, R.drawable.wpt_nature_3),
        )),
        WallpaperCategory("Technology", listOf(
            WallpaperItem("tech_1", R.drawable.wp_tech_1, R.drawable.wpt_tech_1),
            WallpaperItem("tech_2", R.drawable.wp_tech_2, R.drawable.wpt_tech_2),
            WallpaperItem("tech_3", R.drawable.wp_tech_3, R.drawable.wpt_tech_3),
        )),
        WallpaperCategory("Earth", listOf(
            WallpaperItem("earth_1", R.drawable.wp_earth_1, R.drawable.wpt_earth_1),
            WallpaperItem("earth_2", R.drawable.wp_earth_2, R.drawable.wpt_earth_2),
            WallpaperItem("earth_3", R.drawable.wp_earth_3, R.drawable.wpt_earth_3),
        )),
        WallpaperCategory("Space", listOf(
            WallpaperItem("space_1", R.drawable.wp_space_1, R.drawable.wpt_space_1),
            WallpaperItem("space_2", R.drawable.wp_space_2, R.drawable.wpt_space_2),
            WallpaperItem("space_3", R.drawable.wp_space_3, R.drawable.wpt_space_3),
        )),
        WallpaperCategory("Mountains", listOf(
            WallpaperItem("mount_1", R.drawable.wp_mount_1, R.drawable.wpt_mount_1),
            WallpaperItem("mount_2", R.drawable.wp_mount_2, R.drawable.wpt_mount_2),
            WallpaperItem("mount_3", R.drawable.wp_mount_3, R.drawable.wpt_mount_3),
        )),
        WallpaperCategory("Ocean", listOf(
            WallpaperItem("ocean_1", R.drawable.wp_ocean_1, R.drawable.wpt_ocean_1),
            WallpaperItem("ocean_2", R.drawable.wp_ocean_2, R.drawable.wpt_ocean_2),
            WallpaperItem("ocean_3", R.drawable.wp_ocean_3, R.drawable.wpt_ocean_3),
        )),
        WallpaperCategory("City", listOf(
            WallpaperItem("city_1", R.drawable.wp_city_1, R.drawable.wpt_city_1),
            WallpaperItem("city_2", R.drawable.wp_city_2, R.drawable.wpt_city_2),
            WallpaperItem("city_3", R.drawable.wp_city_3, R.drawable.wpt_city_3),
        )),
        WallpaperCategory("Abstract", listOf(
            WallpaperItem("abs_1", R.drawable.wp_abs_1, R.drawable.wpt_abs_1),
            WallpaperItem("abs_2", R.drawable.wp_abs_2, R.drawable.wpt_abs_2),
            WallpaperItem("abs_3", R.drawable.wp_abs_3, R.drawable.wpt_abs_3),
        )),
    )

    private val all: List<WallpaperItem> = categories.flatMap { it.items }

    fun byId(id: String?): WallpaperItem? = all.firstOrNull { it.id == id }
}
