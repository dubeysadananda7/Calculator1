package com.lumivault.calculator.security

/** Lets the vault open a protected app without asking for the PIN again (the user is already inside the vault). */
object AppLockState {
    @Volatile private var allowedPkg: String? = null
    @Volatile private var until: Long = 0L

    fun allowOnce(pkg: String) {
        allowedPkg = pkg
        until = System.currentTimeMillis() + 15_000L
    }

    fun consume(pkg: String): Boolean {
        val ok = allowedPkg == pkg && System.currentTimeMillis() < until
        if (ok) allowedPkg = null
        return ok
    }
}
