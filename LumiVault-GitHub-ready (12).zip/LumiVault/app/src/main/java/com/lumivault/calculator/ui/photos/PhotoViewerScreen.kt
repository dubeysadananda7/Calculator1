package com.lumivault.calculator.ui.photos

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.ActionPill
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.PillAction
import com.lumivault.calculator.ui.components.ThumbButton
import com.lumivault.calculator.ui.components.ToastBar
import java.io.File

@Composable
fun PhotoViewerScreen(app: LumiVaultApp, itemId: String, nav: NavHostController) {
    val vm = remember(app) { PhotosViewModel(app) }
    val photos by vm.photos.collectAsStateWithLifecycle()
    val startIndex = photos.indexOfFirst { it.id == itemId }.coerceAtLeast(0)
    val pager = rememberPagerState(initialPage = startIndex) { photos.size }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    var controls by remember { mutableStateOf(true) }
    var toast by remember { mutableStateOf<String?>(null) }
    val current = photos.getOrNull(pager.currentPage)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        if (photos.isEmpty()) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = Pal.Orange)
        } else {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                val item = photos[page]
                val file by produceState<File?>(initialValue = null, item.id) {
                    value = vm.preview(item)
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { controls = !controls },
                    contentAlignment = Alignment.Center,
                ) {
                    file?.let {
                        AsyncImage(
                            model = it,
                            contentDescription = item.displayName,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit,
                        )
                    } ?: CircularProgressIndicator(color = Pal.Orange)
                }
            }
        }

        if (controls) {
            // ---- top bar with a soft dark fade ----
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ThumbButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onClick = { nav.popBackStack() }, size = 42.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        current?.displayName ?: "Photo",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (photos.isNotEmpty()) {
                        Text("${pager.currentPage + 1} / ${photos.size}", color = Pal.Muted, fontSize = 13.sp)
                    }
                }
            }

            // ---- bottom action bar ----
            if (current != null) {
                ActionPill(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 20.dp),
                ) {
                    PillAction(Icons.Default.Restore, "Restore", Pal.OrangeHi) { confirmRestore = true }
                    PillAction(Icons.Default.DeleteOutline, "Delete", Color(0xFFFF8A80)) { confirmDelete = true }
                }
            }
        }

        toast?.let {
            ToastBar(
                it,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 110.dp),
            )
        }
    }

    if (confirmRestore && current != null) {
        ConfirmDialog(
            title = "Restore to gallery?",
            text = "\"${current.displayName}\" will be moved back to your phone gallery and removed from the vault.",
            confirmLabel = "Restore",
            onConfirm = {
                confirmRestore = false
                vm.restoreToGallery(current) { msg ->
                    toast = msg
                    if (msg.startsWith("Restored") && photos.size <= 1) nav.popBackStack()
                }
            },
            onDismiss = { confirmRestore = false },
        )
    }

    if (confirmDelete && current != null) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "You can restore it later from the recycle bin.",
            confirmLabel = "Move",
            onConfirm = {
                vm.delete(current)
                confirmDelete = false
                nav.popBackStack()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
