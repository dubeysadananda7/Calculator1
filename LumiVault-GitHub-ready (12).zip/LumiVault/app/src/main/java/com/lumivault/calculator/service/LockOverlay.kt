package com.lumivault.calculator.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Full-screen PIN prompt drawn on top of a protected app (accessibility overlay window).
 * Built from plain views so it works inside a service without an Activity.
 */
class LockOverlay(
    private val context: Context,
    private val onSubmit: (String) -> Unit,
    private val onCancel: () -> Unit,
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: FrameLayout? = null
    private var dots: TextView? = null
    private var message: TextView? = null
    private val pin = StringBuilder()

    var pkg: String? = null
        private set
    val isShowing: Boolean get() = root != null

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    fun show(pkgName: String, label: String, icon: Drawable?) {
        if (root != null) hide()
        pkg = pkgName
        pin.clear()

        val frame = object : FrameLayout(context) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) onCancel()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        frame.setBackgroundColor(0xFF070707.toInt())
        frame.isFocusable = true
        frame.isFocusableInTouchMode = true
        frame.setPadding(0, dp(24), 0, dp(24))

        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }

        val iconView = ImageView(context).apply {
            setImageDrawable(icon)
            layoutParams = LinearLayout.LayoutParams(dp(68), dp(68))
        }
        val title = TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        val subtitle = TextView(context).apply {
            text = "Enter your PIN to open"
            setTextColor(0xFF8C8F99.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(10))
        }
        val dotsView = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 30f
            letterSpacing = 0.3f
            gravity = Gravity.CENTER
            minHeight = dp(48)
        }
        val msgView = TextView(context).apply {
            setTextColor(0xFFFF8A80.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            minHeight = dp(22)
        }

        val grid = GridLayout(context).apply {
            columnCount = 3
            rowCount = 4
        }
        fun key(text: String, bg: Int, action: () -> Unit) {
            val v = TextView(context).apply {
                this.text = text
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                textSize = 26f
                background = circle(bg)
                isClickable = true
                setOnClickListener { action() }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = dp(76); height = dp(76)
                setMargins(dp(9), dp(9), dp(9), dp(9))
            }
            grid.addView(v, lp)
        }
        val dark = 0xFF24252F.toInt()
        for (n in 1..9) key(n.toString(), dark) { add(n.toString()) }
        key("⌫", 0xFF221F1E.toInt()) { back() }
        key("0", dark) { add("0") }
        key("✓", 0xFFFF6A00.toInt()) { submit() }

        val cancel = TextView(context).apply {
            text = "Cancel"
            setTextColor(0xFF8C8F99.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(18), dp(24), dp(8))
            setOnClickListener { onCancel() }
        }

        column.addView(iconView)
        column.addView(title)
        column.addView(subtitle)
        column.addView(dotsView)
        column.addView(msgView)
        column.addView(grid)
        column.addView(cancel)
        frame.addView(
            column,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            )
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.OPAQUE,
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        runCatching {
            wm.addView(frame, lp)
            root = frame
            dots = dotsView
            message = msgView
            frame.requestFocus()
        }
        updateDots()
    }

    fun showError(text: String) {
        pin.clear()
        updateDots()
        message?.text = text
    }

    fun hide() {
        root?.let { v -> runCatching { wm.removeView(v) } }
        root = null
        dots = null
        message = null
        pkg = null
        pin.clear()
    }

    private fun add(d: String) {
        if (pin.length < 12) pin.append(d)
        message?.text = ""
        updateDots()
    }

    private fun back() {
        if (pin.isNotEmpty()) pin.deleteCharAt(pin.length - 1)
        message?.text = ""
        updateDots()
    }

    private fun submit() {
        if (pin.length < 4) {
            message?.text = "Enter at least 4 digits"
            return
        }
        onSubmit(pin.toString())
    }

    private fun updateDots() {
        dots?.text = if (pin.isEmpty()) " " else "●".repeat(pin.length)
    }
}
