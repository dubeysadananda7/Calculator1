package com.lumivault.calculator.ui.files

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.ui.components.GradientChip
import com.lumivault.calculator.ui.components.Pal

private val CardShape = RoundedCornerShape(28.dp)

private fun Modifier.premiumCard(): Modifier = this
    .clip(CardShape)
    .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
    .border(1.dp, Pal.Border, CardShape)

@Composable
internal fun FileManagerHome(
    all: List<VaultItemEntity>,
    onAll: () -> Unit,
    onPhotos: () -> Unit,
    onVideos: () -> Unit,
    onAudio: () -> Unit,
    onDocs: () -> Unit,
) {
    fun count(t: VaultItemType) = all.count { it.type == t.name }
    val total = all.sumOf { it.sizeBytes }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(10.dp))

        // ---- All files ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .premiumCard()
                .clickable(onClick = onAll)
                .padding(horizontal = 24.dp, vertical = 26.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GradientChip(Icons.Filled.Folder, Color(0xFFF2604B), Color(0xFFD62F22), size = 68.dp)
            Spacer(Modifier.width(22.dp))
            Column {
                Text("All files", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "${formatSize(total)}  |  ${all.size} ${if (all.size == 1) "file" else "files"}",
                    color = Pal.Muted,
                    fontSize = 17.sp,
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CategoryCard("Photos", count(VaultItemType.PHOTO), Icons.Filled.PhotoLibrary,
                Color(0xFFFF5A8A), Color(0xFFE91EC0), Modifier.weight(1f), onPhotos)
            CategoryCard("Videos", count(VaultItemType.VIDEO), Icons.Filled.Videocam,
                Color(0xFFFFA64D), Color(0xFFFF5A1F), Modifier.weight(1f), onVideos)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            CategoryCard("Audio", count(VaultItemType.AUDIO), Icons.Filled.MusicNote,
                Color(0xFFF2604B), Color(0xFFD62F22), Modifier.weight(1f), onAudio)
            CategoryCard("Documents", count(VaultItemType.DOCUMENT), Icons.Filled.Description,
                Color(0xFF3AC3FF), Color(0xFF1B5CF2), Modifier.weight(1f), onDocs)
        }
        Spacer(Modifier.height(130.dp))
    }
}

@Composable
private fun CategoryCard(
    label: String,
    count: Int,
    icon: ImageVector,
    top: Color,
    bottom: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .height(176.dp)
            .premiumCard()
            .clickable(onClick = onClick)
            .padding(24.dp),
    ) {
        GradientChip(icon, top, bottom, size = 58.dp)
        Spacer(Modifier.weight(1f))
        Text(label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(2.dp))
        Text(count.toString(), color = Pal.Muted, fontSize = 18.sp)
    }
}
