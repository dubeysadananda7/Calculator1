package com.lumivault.calculator.ui.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.Note
import com.lumivault.calculator.ui.components.AccentFab
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun NoteEditScreen(app: LumiVaultApp, noteId: String?, nav: NavHostController) {
    val repo = app.notes
    val scope = rememberCoroutineScope()
    val isNew = noteId == null || noteId == "new"

    val all by produceState<List<Note>>(initialValue = emptyList()) {
        value = repo.notes.first()
    }
    val note: Note? = if (isNew) null else all.find { it.id == noteId }

    var title by remember(note?.id) { mutableStateOf(note?.title ?: "") }
    var body by remember(note?.id) { mutableStateOf(note?.body ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    fun saveAndExit() {
        scope.launch {
            // Don't store a completely empty new note.
            if (!(isNew && title.isBlank() && body.isBlank())) {
                repo.save(if (isNew) null else noteId, title, body)
            }
            nav.popBackStack()
        }
    }

    val cardShape = RoundedCornerShape(28.dp)

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            ScreenHeader(
                title = if (isNew) "New note" else "Edit note",
                onBack = { saveAndExit() },
                actions = {
                    if (!isNew) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color(0xFFFF8A80))
                        }
                    }
                },
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 96.dp)
                    .clip(cardShape)
                    .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
                    .border(1.dp, Pal.Border, cardShape)
                    .padding(horizontal = 22.dp, vertical = 20.dp),
            ) {
                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(Pal.Orange),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        if (title.isEmpty()) Text("Title", color = Pal.Muted, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                        inner()
                    },
                )
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.Border))
                Spacer(Modifier.height(14.dp))
                Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    BasicTextField(
                        value = body,
                        onValueChange = { body = it },
                        textStyle = TextStyle(color = Color(0xFFE6E7EB), fontSize = 18.sp, lineHeight = 27.sp),
                        cursorBrush = SolidColor(Pal.Orange),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            if (body.isEmpty()) Text("Start writing…", color = Pal.Muted, fontSize = 18.sp)
                            inner()
                        },
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Pal.Muted, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (note != null) "Encrypted • " + timeLabel(note.updatedAt) else "Encrypted on this device",
                        color = Pal.Muted,
                        fontSize = 13.sp,
                    )
                }
            }
        }
        AccentFab(
            icon = Icons.Default.Check,
            contentDescription = "Save",
            onClick = { saveAndExit() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .imePadding()
                .padding(24.dp),
        )
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete note?",
            text = "This permanently deletes the note. It cannot be restored.",
            confirmLabel = "Delete",
            onConfirm = {
                scope.launch {
                    noteId?.let { repo.delete(it) }
                    confirmDelete = false
                    nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
