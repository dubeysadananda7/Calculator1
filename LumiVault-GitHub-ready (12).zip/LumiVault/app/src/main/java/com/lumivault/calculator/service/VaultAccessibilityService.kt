package com.lumivault.calculator.service

import android.accessibilityservice.AccessibilityService
import android.graphics.drawable.Drawable
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.VaultSettings
import com.lumivault.calculator.security.AppLockState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * App lock: when a locked (or hidden) app comes to the foreground, a PIN screen is drawn on top of it.
 * The app stays unlocked until the user leaves it, then it asks for the PIN again.
 * Limitations: it cannot protect against uninstall, safe mode, or the service being switched off.
 */
class VaultAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @Volatile private var protectedApps: Set<String> = emptySet()
    @Volatile private var snapshot: VaultSettings? = null

    private var overlay: LockOverlay? = null
    private var currentPkg: String? = null
    private var unlockedPkg: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val app = application as LumiVaultApp
        overlay = LockOverlay(this, ::submit, ::cancel)
        scope.launch {
            app.settings.settings.collect { s ->
                snapshot = s
                protectedApps = s.lockedApps + s.hiddenApps
            }
        }
    }

    private fun isIgnored(pkg: String): Boolean {
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == "android") return true
        if (pkg.endsWith(".permissioncontroller")) return true
        val ime = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')
        return pkg == ime
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (isIgnored(pkg)) return

        // Moving to a different app means the previously unlocked one is locked again.
        if (pkg != currentPkg) {
            if (currentPkg != null && currentPkg == unlockedPkg) unlockedPkg = null
            currentPkg = pkg
        }

        val ov = overlay ?: return
        if (pkg in protectedApps && pkg != unlockedPkg) {
            // Opened from inside the vault: no second PIN prompt.
            if (AppLockState.consume(pkg)) {
                unlockedPkg = pkg
                ov.hide()
                return
            }
            if (!ov.isShowing || ov.pkg != pkg) ov.show(pkg, labelOf(pkg), iconOf(pkg))
        } else if (ov.isShowing) {
            ov.hide()
        }
    }

    private fun labelOf(pkg: String): String = runCatching {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    private fun iconOf(pkg: String): Drawable? = runCatching { packageManager.getApplicationIcon(pkg) }.getOrNull()

    private fun submit(pin: String) {
        val s = snapshot ?: return
        val app = application as LumiVaultApp
        scope.launch {
            val ok = withContext(Dispatchers.Default) { app.settings.verifyPin(pin, s) }
            val ov = overlay ?: return@launch
            if (ok) {
                unlockedPkg = ov.pkg
                ov.hide()
            } else {
                ov.showError("Wrong PIN")
                runCatching { app.security.recordPinFail() }
            }
        }
    }

    private fun cancel() {
        overlay?.hide()
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        overlay?.hide()
        scope.cancel()
        super.onDestroy()
    }
}
