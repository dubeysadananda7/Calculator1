package com.lumivault.calculator.data.repo

import android.content.Context
import com.lumivault.calculator.security.CryptoManager
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class PrivateContact(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phones: List<String> = emptyList(),
    val emails: List<String> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),
)

/** Contacts hidden in the vault. Everything is stored in one AES-GCM encrypted file (Android Keystore key). */
class ContactsRepository(private val context: Context) {

    private val file: File get() = File(context.filesDir, "vault/contacts.enc")
    private val mutex = Mutex()
    private val _contacts = MutableStateFlow<List<PrivateContact>>(emptyList())
    val contacts: StateFlow<List<PrivateContact>> = _contacts

    suspend fun load() = withContext(Dispatchers.IO) {
        mutex.withLock { _contacts.value = sorted(readAll()) }
    }

    suspend fun upsert(c: PrivateContact) = upsertAll(listOf(c))

    suspend fun upsertAll(list: List<PrivateContact>) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val map = LinkedHashMap<String, PrivateContact>()
            readAll().forEach { map[it.id] = it }
            list.forEach { map[it.id] = it }
            val out = sorted(map.values.toList())
            writeAll(out)
            _contacts.value = out
        }
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val out = readAll().filter { it.id != id }
            writeAll(out)
            _contacts.value = sorted(out)
        }
    }

    private fun sorted(list: List<PrivateContact>) = list.sortedBy { it.name.lowercase() }

    private fun readAll(): List<PrivateContact> = runCatching {
        if (!file.exists()) return@runCatching emptyList<PrivateContact>()
        val arr = JSONArray(String(CryptoManager.decrypt(file.readBytes()), Charsets.UTF_8))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            PrivateContact(
                id = o.getString("id"),
                name = o.optString("name"),
                phones = o.optJSONArray("phones")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty(),
                emails = o.optJSONArray("emails")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty(),
                updatedAt = o.optLong("t"),
            )
        }
    }.getOrDefault(emptyList())

    private fun writeAll(list: List<PrivateContact>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("phones", JSONArray(c.phones))
                    .put("emails", JSONArray(c.emails))
                    .put("t", c.updatedAt)
            )
        }
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "contacts.tmp")
        tmp.writeBytes(CryptoManager.encrypt(arr.toString().toByteArray(Charsets.UTF_8)))
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }
}
