package com.lumivault.calculator.ui.applock

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.CountChip
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.dp

class AppLockViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = (app as LumiVaultApp).settings

    val lockedApps = settings.settings.map { it.lockedApps }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    fun setLocked(pkg: String, locked: Boolean) =
        viewModelScope.launch { settings.setAppLocked(pkg, locked) }
}

@Composable
fun AppLockScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { AppLockViewModel(app) }
    val locked by vm.lockedApps.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val apps by produceState<List<AppEntry>?>(initialValue = null) { value = loadInstalledApps(context) }
    var enabled by remember { mutableStateOf(isLockServiceEnabled(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { enabled = isLockServiceEnabled(context) }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(
                title = "App lock",
                onBack = { nav.popBackStack() },
                actions = { if (locked.isNotEmpty()) CountChip("${locked.size} locked") },
            )
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item { ProtectionCard(enabled) { openAccessibilitySettings(context) } }
                val list = apps
                if (list == null) {
                    item {
                        Box(Modifier.fillMaxSize().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Pal.Orange)
                        }
                    }
                } else {
                    items(list, key = { it.pkg }) { entry ->
                        AppRowCard(entry, checked = locked.contains(entry.pkg)) { vm.setLocked(entry.pkg, it) }
                    }
                }
            }
        }
    }
}
