package com.lumivault.calculator.ui.files

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color
import com.lumivault.calculator.ui.components.AccentFab
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.BuildConfig
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.db.VaultItemEntity
import com.lumivault.calculator.data.db.VaultItemType
import com.lumivault.calculator.ui.components.ConfirmDialog
import com.lumivault.calculator.data.repo.MediaCleaner
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.rememberMediaPermissionGate
import com.lumivault.calculator.ui.components.rememberOriginalsCleanup
import com.lumivault.calculator.ui.components.VaultTopBar
import com.lumivault.calculator.ui.navigation.Routes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val CATEGORIES = listOf("All", "Photos", "Videos", "Audio", "Documents", "Other")

private fun typeOf(mime: String?): VaultItemType = when {
    mime == null -> VaultItemType.OTHER
    mime.startsWith("image/") -> VaultItemType.PHOTO
    mime.startsWith("video/") -> VaultItemType.VIDEO
    mime.startsWith("audio/") -> VaultItemType.AUDIO
    mime == "application/pdf" || mime.contains("text/") ||
        mime.contains("document") || mime.contains("sheet") || mime.contains("presentation") -> VaultItemType.DOCUMENT
    else -> VaultItemType.OTHER
}

private fun iconFor(item: VaultItemEntity): ImageVector = when (item.type) {
    VaultItemType.PHOTO.name -> Icons.Default.BrokenImage
    VaultItemType.VIDEO.name -> Icons.Default.Movie
    VaultItemType.AUDIO.name -> Icons.Default.AudioFile
    VaultItemType.DOCUMENT.name -> Icons.Default.Description
    else -> Icons.Default.InsertDriveFile
}

class FilesViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as LumiVaultApp).vault
    val category = MutableStateFlow("All")

    val all: StateFlow<List<VaultItemEntity>> =
        repo.active().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val items: StateFlow<List<VaultItemEntity>> =
        combine(repo.active(), category) { all, cat ->
            when (cat) {
                "Photos" -> all.filter { it.type == VaultItemType.PHOTO.name }
                "Videos" -> all.filter { it.type == VaultItemType.VIDEO.name }
                "Audio" -> all.filter { it.type == VaultItemType.AUDIO.name }
                "Documents" -> all.filter { it.type == VaultItemType.DOCUMENT.name }
                "Other" -> all.filter { it.type == VaultItemType.OTHER.name }
                else -> all
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun import(uris: List<Uri>, onError: (String) -> Unit, onCleanup: (List<Uri>) -> Unit) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val originals = mutableListOf<Uri>()
            var failedCleanup = 0
            for (uri in uris) {
                val mime = context.contentResolver.getType(uri)
                val type = typeOf(mime)
                val isMedia = type == VaultItemType.PHOTO || type == VaultItemType.VIDEO || type == VaultItemType.AUDIO
                val mediaUri = if (isMedia) MediaCleaner.toMediaUri(context, uri, type) else null
                val r = repo.import(uri, type)
                if (r.isSuccess) {
                    when {
                        mediaUri != null -> originals.add(mediaUri)
                        isMedia -> failedCleanup++
                        else -> if (!withContext(Dispatchers.IO) { MediaCleaner.deleteDocument(context, uri) }) failedCleanup++
                    }
                } else onError(r.exceptionOrNull()?.message ?: "Import failed")
            }
            if (failedCleanup > 0) {
                onError("Hidden, but $failedCleanup original file(s) could not be removed automatically. Delete them from your file manager.")
            }
            if (originals.isNotEmpty()) onCleanup(originals)
        }
    }

    fun restoreToGallery(item: VaultItemEntity, onResult: (String) -> Unit) = viewModelScope.launch {
        repo.exportToGallery(item)
            .onSuccess { onResult("Restored (Pictures / Movies / Music / Download, folder \"Restored\")") }
            .onFailure { onResult(it.message ?: "Restore failed") }
    }

    fun delete(item: VaultItemEntity) = viewModelScope.launch { repo.softDelete(item.id) }

    fun openExternal(item: VaultItemEntity) = viewModelScope.launch(Dispatchers.IO) {
        val file = repo.decryptedFile(item)
        val context = getApplication<Application>()
        val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, item.mimeType ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        com.lumivault.calculator.security.SessionManager.beginExternal()
        runCatching { context.startActivity(intent) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { FilesViewModel(app) }
    val items by vm.items.collectAsStateWithLifecycle()
    val all by vm.all.collectAsStateWithLifecycle()
    var section by rememberSaveable { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val cleanup = rememberOriginalsCleanup()

    val importer = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.import(uris, { error = it }, cleanup) }
    val launchImporter = rememberMediaPermissionGate { importer.launch(arrayOf("*/*")) }

    LaunchedEffect(section) { vm.category.value = section ?: "All" }
    BackHandler(enabled = section != null) { section = null }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            val current = section
            ScreenHeader(
                title = when (current) {
                    null -> "File manager"
                    "All" -> "All files"
                    else -> current ?: ""
                },
                onBack = { if (current != null) section = null else nav.popBackStack() },
            )
            if (current == null) {
                FileManagerHome(
                    all = all,
                    onAll = { section = "All" },
                    onPhotos = { nav.navigate(Routes.PHOTOS) },
                    onVideos = { nav.navigate(Routes.VIDEOS) },
                    onAudio = { section = "Audio" },
                    onDocs = { section = "Documents" },
                )
            } else if (items.isEmpty()) {
                EmptyState(Icons.Default.Folder, "No files here", "Tap + to import documents, audio, or other files")
            } else {
                LazyColumn(contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
                    items(items, key = { it.id }) { item ->
                        FileRow(item = item, onOpen = {
                            when (item.type) {
                                VaultItemType.PHOTO.name -> nav.navigate(Routes.photoViewer(item.id))
                                VaultItemType.VIDEO.name -> nav.navigate(Routes.videoPlayer(item.id))
                                else -> vm.openExternal(item)
                            }
                        }, onDelete = { vm.delete(item) }, onRestore = { vm.restoreToGallery(item) { error = it } })
                    }
                }
            }
        }
        AccentFab(
            icon = Icons.Default.Add,
            contentDescription = "Import",
            onClick = launchImporter,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(24.dp),
        )
        error?.let {
            Text(it, color = Color(0xFFFF8A80),
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp))
        }
    }
}

@Composable
private fun FileRow(item: VaultItemEntity, onOpen: () -> Unit, onDelete: () -> Unit, onRestore: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var confirmRestore by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onOpen),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Pal.Card),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(iconFor(item), contentDescription = null, tint = Pal.Orange)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.displayName, style = MaterialTheme.typography.bodyLarge)
                Text(
                    "${item.type.lowercase().replaceFirstChar { it.uppercase() }} · ${formatSize(item.sizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Restore to gallery / downloads") }, onClick = { menu = false; confirmRestore = true })
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; confirmDelete = true })
                }
            }
        }
    }
    if (confirmRestore) {
        ConfirmDialog(
            title = "Restore file?",
            text = "\"${item.displayName}\" will be moved back to your phone and removed from the vault.",
            confirmLabel = "Restore",
            onConfirm = { onRestore(); confirmRestore = false },
            onDismiss = { confirmRestore = false },
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "Move to recycle bin?",
            text = "\"${item.displayName}\" will be moved to the recycle bin.",
            confirmLabel = "Move",
            onConfirm = { onDelete(); confirmDelete = false },
            onDismiss = { confirmDelete = false },
        )
    }
}

internal fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.1f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
