package com.lumivault.calculator.security

import androidx.compose.runtime.mutableStateOf

/** In-memory vault session. Cleared on process death; auto-lock re-locks in the background. */
object SessionManager {
    val unlocked = mutableStateOf(false)
    @Volatile private var lastInteraction: Long = System.currentTimeMillis()

    fun touch() { lastInteraction = System.currentTimeMillis() }

    fun unlock() {
        unlocked.value = true
        touch()
    }

    @Volatile var onLock: (() -> Unit)? = null

    // Set right before the app opens a system screen (photo picker, permission dialog, another app…).
    // While it is active, leaving the app does NOT lock the vault, so the user's flow isn't interrupted.
    @Volatile private var externalSince: Long = 0L
    fun beginExternal() { externalSince = System.currentTimeMillis() }
    fun endExternal() { externalSince = 0L }
    fun isExternalActive(): Boolean =
        externalSince != 0L && System.currentTimeMillis() - externalSince < 120_000L

    fun lock() {
        unlocked.value = false
        onLock?.invoke()
    }

    fun isStale(autoLockMinutes: Int): Boolean =
        unlocked.value && System.currentTimeMillis() - lastInteraction > autoLockMinutes * 60_000L
}
