package com.lumivault.calculator.ui.notes

import android.app.Application
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.data.repo.Note
import com.lumivault.calculator.data.repo.NotesRepository
import com.lumivault.calculator.ui.components.AccentFab
import com.lumivault.calculator.ui.components.EmptyState
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.navigation.Routes
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotesViewModel(app: Application) : AndroidViewModel(app) {
    private val repo: NotesRepository = (app as LumiVaultApp).notes
    val notes: StateFlow<List<Note>> = repo.notes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // One-time welcome note, shown the first time the vault's Notes are opened.
        val prefs = app.getSharedPreferences("setup", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("notes_seeded", false)) {
            prefs.edit().putBoolean("notes_seeded", true).apply()
            viewModelScope.launch {
                repo.save(
                    null,
                    "🎉 Welcome to Notes!",
                    "Jot down anything here—ideas, memories, secrets. Everything is encrypted and only visible after you unlock the vault.",
                )
            }
        }
    }

    fun delete(id: String) = viewModelScope.launch { repo.delete(id) }
}

private val Accents = listOf(
    Color(0xFFFF8F3D) to Color(0xFFFF6A00),
    Color(0xFFFF6FA8) to Color(0xFFE91E8C),
    Color(0xFF5CC8FF) to Color(0xFF1B6CF2),
    Color(0xFF5BE38B) to Color(0xFF0FA34A),
    Color(0xFFA48BFF) to Color(0xFF6A4DE8),
)

private fun startOfDay(ts: Long): Long = Calendar.getInstance().apply {
    timeInMillis = ts
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun dayLabel(ts: Long): String {
    val days = ((startOfDay(System.currentTimeMillis()) - startOfDay(ts)) / 86_400_000L).toInt()
    return when (days) {
        0 -> "Today"
        1 -> "Yesterday"
        else -> SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ts))
    }
}

internal fun timeLabel(ts: Long): String =
    dayLabel(ts) + " • " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ts))

@Composable
fun NotesScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { NotesViewModel(app) }
    val notes by vm.notes.collectAsStateWithLifecycle()

    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var newestFirst by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }

    val shown = notes
        .filter {
            query.isBlank() || it.title.contains(query, ignoreCase = true) || it.body.contains(query, ignoreCase = true)
        }
        .let { list -> if (newestFirst) list.sortedByDescending { it.updatedAt } else list.sortedBy { it.updatedAt } }
    val grouped = shown.groupBy { dayLabel(it.updatedAt) }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = {
                    if (searching) { searching = false; query = "" } else nav.popBackStack()
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                if (searching) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
                        cursorBrush = SolidColor(Pal.Orange),
                        modifier = Modifier.weight(1f).padding(start = 8.dp),
                        decorationBox = { inner ->
                            if (query.isEmpty()) Text("Search notes", color = Pal.Muted, fontSize = 20.sp)
                            inner()
                        },
                    )
                } else {
                    Text(
                        "Notes",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f).padding(start = 8.dp),
                    )
                    IconButton(onClick = { searching = true }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = Color.White)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(if (newestFirst) "Oldest first" else "Newest first") },
                            onClick = { newestFirst = !newestFirst; menu = false },
                        )
                    }
                }
            }

            if (shown.isEmpty()) {
                EmptyState(
                    Icons.Filled.Notes,
                    if (query.isBlank()) "No notes yet" else "No matching notes",
                    if (query.isBlank()) "Tap the pencil to write your first private note" else "Try a different word",
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 130.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    grouped.forEach { (day, list) ->
                        item(key = "h_$day") {
                            Text(
                                day,
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp),
                            )
                        }
                        items(list, key = { it.id }) { note ->
                            NoteCard(note) { nav.navigate(Routes.noteEdit(note.id)) }
                        }
                    }
                }
            }
        }
        AccentFab(
            icon = Icons.Filled.Edit,
            contentDescription = "New note",
            onClick = { nav.navigate(Routes.noteEdit(null)) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(24.dp),
        )
    }
}

@Composable
private fun NoteCard(note: Note, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val (hi, lo) = Accents[abs(note.id.hashCode()) % Accents.size]
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
            .border(1.dp, Pal.Border, shape)
            .clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .width(6.dp)
                .fillMaxHeight()
                .background(Brush.verticalGradient(listOf(hi, lo)))
        )
        Column(Modifier.weight(1f).padding(horizontal = 20.dp, vertical = 18.dp)) {
            Text(
                note.title.ifEmpty { "Untitled" },
                color = Color.White,
                fontSize = 21.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                note.body.replace("\n", " "),
                color = Pal.Muted,
                fontSize = 17.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.CalendarToday, contentDescription = null, tint = Pal.Muted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(timeLabel(note.updatedAt), color = Pal.Muted, fontSize = 15.sp)
            }
        }
    }
}
