package com.lumivault.calculator.data.repo

import android.content.ContentProviderOperation
import android.content.Context
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PhoneContact(
    val id: Long,
    val lookupKey: String,
    val name: String,
    val phones: List<String>,
    val emails: List<String>,
)

/** Reads, removes and re-creates contacts in the phone's own Contacts app. */
object PhoneContacts {

    suspend fun load(ctx: Context): List<PhoneContact> = withContext(Dispatchers.IO) {
        val r = ctx.contentResolver
        val phones = HashMap<Long, MutableList<String>>()
        val emails = HashMap<Long, MutableList<String>>()

        r.query(Phone.CONTENT_URI, arrayOf(Phone.CONTACT_ID, Phone.NUMBER), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(1)?.trim().orEmpty()
                if (n.isEmpty()) continue
                val l = phones.getOrPut(c.getLong(0)) { mutableListOf() }
                if (!l.contains(n)) l.add(n)
            }
        }
        r.query(Email.CONTENT_URI, arrayOf(Email.CONTACT_ID, Email.ADDRESS), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val a = c.getString(1)?.trim().orEmpty()
                if (a.isEmpty()) continue
                val l = emails.getOrPut(c.getLong(0)) { mutableListOf() }
                if (!l.contains(a)) l.add(a)
            }
        }

        val out = mutableListOf<PhoneContact>()
        r.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.LOOKUP_KEY,
                ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
            ),
            null, null,
            "${ContactsContract.Contacts.DISPLAY_NAME_PRIMARY} COLLATE NOCASE ASC",
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val key = c.getString(1) ?: continue
                val name = c.getString(2)?.trim().orEmpty()
                val p = phones[id].orEmpty()
                if (name.isEmpty() && p.isEmpty()) continue
                out.add(PhoneContact(id, key, name.ifEmpty { p.first() }, p, emails[id].orEmpty()))
            }
        }
        out
    }

    /** Deletes the contacts from the phone. Returns how many were removed. */
    fun delete(ctx: Context, lookupKeys: List<String>): Int {
        var removed = 0
        for (k in lookupKeys) {
            val uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, k)
            removed += runCatching { ctx.contentResolver.delete(uri, null, null) }.getOrDefault(0).coerceAtMost(1)
        }
        return removed
    }

    fun insert(ctx: Context, c: PrivateContact) {
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build()
        )
        ops.add(
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
                .withValue(StructuredName.DISPLAY_NAME, c.name)
                .build()
        )
        c.phones.forEach { n ->
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
                    .withValue(Phone.NUMBER, n)
                    .withValue(Phone.TYPE, Phone.TYPE_MOBILE)
                    .build()
            )
        }
        c.emails.forEach { a ->
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, Email.CONTENT_ITEM_TYPE)
                    .withValue(Email.ADDRESS, a)
                    .withValue(Email.TYPE, Email.TYPE_HOME)
                    .build()
            )
        }
        ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
    }
}
