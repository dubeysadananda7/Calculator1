package com.lumivault.calculator.ui.applock

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.lumivault.calculator.LumiVaultApp
import com.lumivault.calculator.ui.components.CountChip
import com.lumivault.calculator.ui.components.Pal
import com.lumivault.calculator.ui.components.ScreenHeader
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HideAppsViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = (app as LumiVaultApp).settings

    val hiddenApps = settings.settings.map { it.hiddenApps }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    fun setHidden(pkg: String, hidden: Boolean) =
        viewModelScope.launch { settings.setAppHidden(pkg, hidden) }
}

@Composable
fun HideAppsScreen(app: LumiVaultApp, nav: NavHostController) {
    val vm = remember(app) { HideAppsViewModel(app) }
    val hidden by vm.hiddenApps.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val apps by produceState<List<AppEntry>?>(initialValue = null) { value = loadInstalledApps(context) }
    var enabled by remember { mutableStateOf(isLockServiceEnabled(context)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { enabled = isLockServiceEnabled(context) }

    Box(Modifier.fillMaxSize().background(Pal.Bg)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            ScreenHeader(
                title = "Hide apps",
                onBack = { nav.popBackStack() },
                actions = { if (hidden.isNotEmpty()) CountChip("${hidden.size} hidden") },
            )
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item { ProtectionCard(enabled) { openAccessibilitySettings(context) } }
                item { InfoCard() }

                val list = apps
                if (list == null) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Pal.Orange)
                        }
                    }
                } else {
                    val mine = list.filter { it.pkg in hidden }
                    if (mine.isNotEmpty()) {
                        item { Section("Open from here") }
                        items(mine.chunked(4), key = { row -> row.first().pkg }) { row ->
                            Row(Modifier.fillMaxWidth()) {
                                row.forEach { e ->
                                    AppTile(e, Modifier.weight(1f)) { launchApp(context, e.pkg) }
                                }
                                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                    item { Section("All apps") }
                    items(list, key = { "all_" + it.pkg }) { entry ->
                        AppRowCard(entry, checked = entry.pkg in hidden) { vm.setHidden(entry.pkg, it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title,
        color = Color.White,
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 10.dp, bottom = 2.dp),
    )
}

@Composable
private fun InfoCard() {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Pal.CardHi, Pal.Card)))
            .border(1.dp, Pal.Border, shape)
            .padding(18.dp),
    ) {
        Text("How hiding works", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.padding(top = 6.dp))
        Text(
            "Apps you switch on here are protected with your PIN, and you can open them from the “Open from here” row " +
                "without typing it again. Android doesn’t let one app remove another app’s icon, so to also take the icon off " +
                "the home screen use your phone’s own option (Xiaomi: Settings → Home screen → Hide apps; Android 15: Private space).",
            color = Pal.Muted,
            fontSize = 13.sp,
        )
    }
}
